/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.conf;

import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by klayer3 on 01/02/2025.
 */
//@Configuration
//@EnableCaching
//@Slf4j
public class CaffeineCacheConfig {

    //@Bean FIXME PROVA
    public CacheManager cacheManager() {
        CaffeineCacheManager caffeineCacheManager = new CaffeineCacheManager();
        caffeineCacheManager.setCaffeine(Caffeine.newBuilder()
                .expireAfterWrite(5, TimeUnit.MINUTES)
                .maximumSize(100));
        caffeineCacheManager.setCacheNames(List.of(
                Caches.FirebaseToken,
                Caches.AuthToken,
                Caches.TokenLogin,
                Caches.User
        ));
//        caffeineCacheManager.set;
        return caffeineCacheManager;
    }

//    @Scheduled(fixedRate = 30000, initialDelay = 60000 )
//    public void evictAllCaches() {
//        log.info("evicting all caches");
//        cacheManager.getCacheNames().forEach(cacheName -> cacheManager.getCache(cacheName).clear());
//    }

    public interface Caches {
        String FirebaseToken = "FirebaseToken";
        String AuthToken = "AuthToken";
        String TokenLogin = "TokenLogin";
        String User="User";

    }
}
