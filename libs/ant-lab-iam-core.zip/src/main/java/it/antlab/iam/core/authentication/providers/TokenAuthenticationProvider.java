/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.authentication.providers;

import it.antlab.iam.core.authentication.TokenAuthentication;
import it.antlab.iam.core.conf.CacheConfig;
import it.antlab.iam.core.dto.JwtRef;
import it.antlab.iam.core.dto.UserResult;
import it.antlab.iam.core.service.JwtService;
import it.antlab.iam.core.service.UserResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.UUID;


/**
 * Created by klayer3 on 21/03/22.
 */
@Component
public class TokenAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private UserResultService userResultService;

    @Autowired
    private JwtService jwtService;

    @Override
    @Cacheable(value= CacheConfig.Caches.AuthToken, key="#authentication?.token")
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        try {
            final String token = Objects.toString(authentication.getCredentials());

            UserResult userResult = getUserResult(token);
            if (userResult != null) {
                return new TokenAuthentication(
                        token,
                        userResult,
                        userResult.getAuthorities()
                );
            }
        } catch (AuthenticationException ex){
            throw ex;
        } catch (Exception e){
            throw new BadCredentialsException(e.getMessage());
        }

        return null;
    }

    private UserResult getUserResult(String token) {
        if( jwtService.isValid(token)){
            JwtRef jwtRef = jwtService.getRef(token);
            return this.userResultService.findByIdVerifyTokenExists(UUID.fromString(jwtRef.getSub()), jwtRef.getJti() ,token);
        }
        return null;
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(TokenAuthentication.class);
    }
}
