/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.repository;

import it.antlab.iam.core.model.UserRole;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/**
 * Created by klayer3 on 23/03/22.
 */
@org.springframework.stereotype.Repository
public interface UserRoleRepository extends Repository<UserRole, UUID> {
    UserRole findByUserIdAndRoleId(UUID userId, String RoleId);

    @Modifying
    @Transactional
    @Query("update UserRole st set st.obsolete = true where st.obsolete = false and st.userId = :userId")
    Number setAllObsoleteByUserId(UUID userId);

    List<UserRole> findByUserId(UUID userId);
}
