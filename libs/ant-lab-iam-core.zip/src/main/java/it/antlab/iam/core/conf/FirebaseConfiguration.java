/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.conf;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.ListUsersPage;
import it.antlab.iam.core.conf.properties.FirebaseProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by klayer3 on 21/03/22.
 */
@Configuration
@Slf4j
//staccare in modulo apposito
public class FirebaseConfiguration {

    @Autowired
    private FirebaseProperties firebaseProperties;

    @PostConstruct
    public void initialize() throws IOException {

        if( firebaseProperties.isEnabled()) {

            log.info("Initializing iam.FirebaseConfiguration...");

            log.info("Retrieving iam.conf.firebase.serviceAccountKey ...");
            Assert.isTrue(StringUtils.isNotEmpty(firebaseProperties.getServiceAccountKey()), "invalid serviceAccount");

            InputStream serviceAccount = new ByteArrayInputStream(firebaseProperties.getServiceAccountKey().getBytes());

            log.info("Preparing Firebase configuration options...");
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                   // .setDatabaseUrl(firebaseProperties.getFirebaseDatabaseUrl())
                    .build();

            try {
                //brutto necessario in fase di test

                FirebaseApp.getInstance().delete();
            } catch (Exception e) {
            }

            //FIXME potremmo averne una per provider!!!
            FirebaseApp.initializeApp(options);

            log.info("firebase app {} initialized",FirebaseApp.getInstance().toString());

            if( StringUtils.isNotBlank(firebaseProperties.getFirebaseDatabaseUrl())) {
                log.info("FirebaseConfiguration initialized. Firebase URL: {}", firebaseProperties.getFirebaseDatabaseUrl());
            }


//            try {
//                FirebaseAuth.getInstance().verifyIdToken()
//                FirebaseAuth.getInstance().createCustomToken(UUID.randomUUID().toString(),
//                        Map.of(
//                                "roles", List.of("a","b","C"),
//                                    "iam_username", "admin",
//                                   "altro_come_te_pare", "vai"
//                        ));
//            }catch (Exception e){
//                log.error(ExceptionUtils.getStackTrace(e));
//            }
            //saveFirebaseUsers();

            //StorageClient.getInstance(FirebaseApp.getInstance()).storage.list().iterateAll().iterator().next().get("localize.json")
            //StorageClient.getInstance(FirebaseApp.getInstance()).bucket("firebase-project.appspot.com").list();
        }else {
            log.info("FirebaseConfiguration is not enabled");
        }

    }

    private static void saveFirebaseUsers() {
        try {
           // UserRecord userRecord = FirebaseAuth.getInstance().getUserByEmail("riccardo.mohamed@gmail.con");

            boolean hasNext = true;
            String nextPageToken = null;
            Set<String> users = new LinkedHashSet<>();
            users.add("email,email_verified,has_password");
            do {
                ListUsersPage listUsersPage = FirebaseAuth.getInstance().listUsers(nextPageToken, 500);

                listUsersPage.getValues().forEach( user -> {
                    users.add(user.getEmail() + "," + user.isEmailVerified()+","+user.getPasswordSalt()+","+user.getPasswordHash());
//                    if(Objects.equals(user.getEmail(), userRecord.getEmail())){
//                        System.out.println(user);
//                    }
                });
                hasNext = listUsersPage.hasNextPage();
                nextPageToken = listUsersPage.getNextPageToken();

            }while (hasNext);

            //FileUtils.writeStringToFile(new File("/home/klayer3/firebase_users.csv"), StringUtils.join(users, "\n"));
            users.forEach( u -> {log.info(u);});

            log.info("end check users size {}", users.size());

        } catch (Exception e){
            log.info("Error listing users: {} ,{} " , e.getMessage(), ExceptionUtils.getStackTrace(e));
        }
    }
}
