/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.model.base;

import io.nettuno.dynacrud.base.IgnoreTextSearch;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import java.time.LocalDateTime;

/**
 * Created by klayer3 on 16/07/20.
 */
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@DynamicUpdate
@DynamicInsert
public class AuditingEntity implements Obsoletable {
    @Column(name = "created_date", nullable = false, updatable = false)
    @IgnoreTextSearch
    @CreatedDate
    private LocalDateTime dateCreated;

    @Column(name = "obsolete", nullable = false)
    private boolean obsolete = false;

    @Column(name = "modified_date")
    @LastModifiedDate
    @IgnoreTextSearch
    private LocalDateTime modifiedDate;

    @Column(name = "created_by", nullable = false, updatable = false)
    @CreatedBy
    @IgnoreTextSearch
    private String createdBy;

    @Column(name = "modified_by")
    @LastModifiedBy
    @IgnoreTextSearch
    private String modifiedBy;

    public boolean isNotObsolete() {
        return !isObsolete();
    }

}
