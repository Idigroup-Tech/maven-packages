/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.conf;

import io.nettuno.dynacrud.base.Context;

import it.antlab.iam.core.conf.properties.InitializationProperties;
import it.antlab.iam.core.enums.IAMRoleContext;
import it.antlab.iam.core.enums.IAMRoles;
import it.antlab.iam.core.enums.IAMUserType;
import it.antlab.iam.core.model.Role;
import it.antlab.iam.core.model.User;
import it.antlab.iam.core.model.UserRole;
import it.antlab.iam.core.service.RoleService;
import it.antlab.iam.core.service.UserRoleService;
import it.antlab.iam.core.service.UserService;
import it.antlab.utils.nassert.NAssert;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.descriptor.web.ContextService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 22/03/22.
 */
@Configuration
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class InitializationConfiguration {
    
    @Autowired
    private InitializationProperties initializationProperties;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    @Lazy
    private PasswordEncoder passwordEncoder;

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserRoleService userRoleService;


    @Autowired
    // context caricato  per inizializzazione migliorare in dynacrud
    private Context context;
    
    @PostConstruct
    private void init( ){
        log.info("Initializing configuration...");
        initRoles();
        initAdminUser();
    }

    private void initAdminUser() {

        log.info("Initializing admin user...");
        final String admin_user = StringUtils.trim(initializationProperties.getAdminUsername());
        if(StringUtils.isNotEmpty(admin_user)){


            User admin = userService.findByUsername(admin_user);
            if( admin == null){
                log.info("create admin user");
                String adminPwd = StringUtils.trim(initializationProperties.getAdminPassword());
                NAssert.state(StringUtils.isNotEmpty(adminPwd), "init/invalid_admin_password");
                admin = new User();
                admin.setUsername(admin_user);
                admin.setSecret(passwordEncoder.encode(adminPwd));
                admin.setUserType(IAMUserType.BASIC);
                admin.setObsolete(false);
                admin = userService.insert(admin);
            }

            for ( Role r : getAdminRoles()){
                log.info("adding roles to admin user");
                UserRole userRole = new UserRole();
                userRole.setUserId(admin.getId());
                userRole.setRoleId(r.getId());
                userRoleService.insert(userRole);
            }
        }
    }

    private void initRoles(){
        log.info("Initializing roles ...");
        Set<String> allRoles = new HashSet<>();
        allRoles.addAll(ObjectUtils.firstNonNull(initializationProperties.getRoles(), List.of(IAMRoles.IAM_ADMIN.name())));
        allRoles.addAll(ObjectUtils.firstNonNull(initializationProperties.getAdminRoles(), List.of(IAMRoles.IAM_ADMIN.name())));
        //allRoles.add(IAMRoles.IAM_ADMIN.name()); -> FIXME rivedere role e contexts cambiamo le properties.... dobiamo avere contesto e ruoli



        log.info("allRoles: {}", allRoles);
        allRoles.stream().filter( s -> StringUtils.isNotEmpty(StringUtils.trim(s))).map( s -> StringUtils.upperCase(StringUtils.trim(s))).forEach( roleId -> {
            Role role = roleService.read(roleId);
            if ( role == null){

                role = new Role();
                role.setId(roleId);
                role.setDescription(roleId);
                log.info("adding role: {}", roleId);
                roleService.insert(role);
            }
        });
    }

    private List<Role> getAdminRoles() {

        return ObjectUtils.firstNonNull(initializationProperties.getAdminRoles(), initializationProperties.getRoles(), List.of(IAMRoles.IAM_ADMIN.name()))
                .stream()
                .filter( r -> StringUtils.isNotEmpty(StringUtils.trim(r)))
                .map( r -> roleService.read(StringUtils.upperCase(StringUtils.trim(r))))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

    }

}
