/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.authentication.providers;

import com.google.firebase.auth.AuthErrorCode;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;
import it.antlab.iam.core.authentication.TokenAuthentication;
import it.antlab.iam.core.conf.CacheConfig;
import it.antlab.iam.core.dto.ProviderUser;
import it.antlab.iam.core.dto.UserResult;
import it.antlab.iam.core.model.Provider;
import it.antlab.iam.core.service.ProviderService;
import it.antlab.iam.core.service.UserResultService;
import it.antlab.utils.concurrency.LockUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.DependsOn;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.PostConstruct;
import java.util.Objects;
import java.util.Optional;

/**
 * Created by klayer3 on 20/03/22.
 */
@Component
@DependsOn("dynacrudContext")
public class FirebaseAuthenticationProvider implements AuthenticationProvider {
    //https://firebase.google.com/docs/auth/admin/errors
    //private AuthErrorCode invalidIdTokenErrorCode ="INVALID_ID_TOKEN";
    // valutare la gestione
    public static String providerId = "firebase";

    @Autowired
    private UserResultService userResultService;

    @Autowired
    private ProviderService providerService;

    @PostConstruct
    private void init(){

        Optional.ofNullable(providerService.read(providerId)).orElseGet( () -> {
            Provider provider = new Provider();
            provider.setId(providerId);
            provider.setDescription(providerId);
            return providerService.insert(provider);
        });

    }

    @Override
    @Cacheable(value = CacheConfig.Caches.FirebaseToken, key = "#authentication?.token")
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        final String lockErrorMessage= "authentication from "+providerId+ " provider is taking too long, please try again";

            final String token = Objects.toString(authentication.getCredentials());
            try {
                return LockUtils.getInstance().lock(
                        () -> {
                            try{
                            UserResult userResult = userResultService.getUser(getProviderUser(token), true);
                            return new TokenAuthentication(
                                    token,
                                    userResult,
                                    userResult.getAuthorities()
                            );
                            }catch (FirebaseAuthException authException){
                                if( Objects.equals(authException.getAuthErrorCode(), AuthErrorCode.INVALID_ID_TOKEN) ) {
                                    // non è un idTokenFirebase comunque non mi arrabbio!
                                    return null;
                                } else if ( Objects.equals(authException.getAuthErrorCode(), AuthErrorCode.EXPIRED_ID_TOKEN)) {
                                    throw new CredentialsExpiredException(authException.getMessage(), authException);
                                }
                                throw new BadCredentialsException(authException.getMessage(), authException.getCause());
                            }
                        },
                        token
                );
            }catch (LockUtils.LockException ex){
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, lockErrorMessage);
            }

    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(TokenAuthentication.class);
    }

    private ProviderUser getProviderUser(String idToken) throws FirebaseAuthException {
        if (StringUtils.isEmpty(idToken)) {
            throw new BadCredentialsException("idToken is blank");
        }

        FirebaseToken firebaseToken = FirebaseAuth.getInstance().verifyIdToken(idToken, false);

        return ProviderUser.builder()
                .providerId(this.providerId)
                .providerUserId(firebaseToken.getUid())
                .name(firebaseToken.getName())
                .issuer(firebaseToken.getIssuer())
                .email(firebaseToken.getEmail())
                .picture(firebaseToken.getPicture())
                .claims(firebaseToken.getClaims())
                .emailVerified(firebaseToken.isEmailVerified())
                .build();
    }
}
