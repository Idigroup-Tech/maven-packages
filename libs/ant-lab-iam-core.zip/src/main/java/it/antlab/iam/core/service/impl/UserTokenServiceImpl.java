/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service.impl;


import it.antlab.iam.core.enums.IAMUserType;
import it.antlab.iam.core.model.User;
import it.antlab.iam.core.model.UserToken;
import it.antlab.iam.core.repository.UserTokenRepository;
import it.antlab.iam.core.service.AuthService;
import it.antlab.iam.core.service.UserResultService;
import it.antlab.iam.core.service.UserService;
import it.antlab.iam.core.service.UserTokenService;
import it.antlab.iam.core.service.base.ObsoleteDeletionService;
import it.antlab.utils.nassert.NAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Created by klayer3 on 23/03/22.
 */
@Service
public class UserTokenServiceImpl extends ObsoleteDeletionService<UserToken> implements UserTokenService  {

    @Autowired
    private UserTokenRepository userTokenRepository;

    @Autowired
    private UserResultService userResultService;

    @Autowired
    private AuthService authResultService;

    @Autowired
    private UserService userService;

    @Override
    public List<UserToken> getTokens(UUID userId) {
        return userTokenRepository.findAllByUserId(userId);
    }

    @Override
    @Transactional
    public UserToken deleteToken(UUID userId, UUID tokenId) {
        UserToken token = this.read(tokenId);
        NAssert.state(token!= null, "iam/invalid-token-id");
        NAssert.state(Objects.equals(token.getUserId(), userId), "iam/invalid-token-owner");
        return this.delete(tokenId);
    }

    @Override
    @Transactional
    public UserToken generateToken(UUID userId, Long durationSeconds) {
        User user = userService.read(userId);

        //FIXME RAGIONIAMO SU API KEY e secret ... dobbiamo rivedere per performance e per sicurezza... api key ci garantisce controllo il token deve essere potremmo anche aggiungere semplicemente il apisecret ed andare a controllare anche questo elemento?
        //direi di si! ricordiamoci il discroso di BCRIPT e ragioniamoci
        NAssert.state( user != null, new ResponseStatusException(HttpStatus.NOT_FOUND, "user not found!"));
        NAssert.state(IAMUserType.APPLICATION.equals(user.getUserType()), "iam/invalid-user-type", "must be APPLICATION");
        NAssert.state(Stream.of(!user.isObsolete(), user.isEnabled(), !user.isLocked()).allMatch(b -> b), "iam/user-not-active" );
        UUID tokenId = UUID.randomUUID();
        String token =  authResultService.generateToken(userResultService.findById(userId), tokenId, durationSeconds) ;
        UserToken userToken = new UserToken();
        userToken.setUserId(userId);
        userToken.setToken(token);
        userToken.setId(tokenId);
        return this.insert(userToken);

    }
}
