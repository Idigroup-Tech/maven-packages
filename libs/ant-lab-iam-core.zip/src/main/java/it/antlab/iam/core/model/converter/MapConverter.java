package it.antlab.iam.core.model.converter;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import it.antlab.utils.nassert.NAssertException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.AttributeConverter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by klayer3 on 18/06/25
 */
public class MapConverter implements AttributeConverter<Map, String> {

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public String convertToDatabaseColumn(Map values) {
        String mapJson = null;
        try {
            if(values != null) {
                mapJson = objectMapper.writeValueAsString(values);
            }
        } catch (final JsonProcessingException e) {
            throw NAssertException.builder("map_serialization/invalid_values").message(e.getMessage()).build();
        }

        return mapJson;
    }

    @Override
    public Map convertToEntityAttribute(String dbData) {
        Map ret = new HashMap();
        try {
            if(StringUtils.isNotBlank(dbData)) {
                ret = objectMapper.readValue(dbData, Map.class);
            }
        } catch (final IOException e) {
            throw NAssertException.builder("map_deserialization/invalid_values").message(e.getMessage()).build();
        }
        return ret;
    }
}
