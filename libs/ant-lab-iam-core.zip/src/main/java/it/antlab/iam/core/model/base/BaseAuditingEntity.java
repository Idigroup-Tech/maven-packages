/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.model.base;



import io.nettuno.dynacrud.base.Entity;
import lombok.Getter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.beans.Transient;
import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

/**
 * Created by klayer3 on 15/07/2020.
 */
@MappedSuperclass
@DynamicUpdate
@DynamicInsert
public class BaseAuditingEntity extends AuditingEntity implements Entity<UUID> {
    @NotNull
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(
            name = "UUID",
            strategy = "org.hibernate.id.UUIDGenerator"
    )
    @Column(name = "id", updatable = false, nullable = false)
    @Type(type = "uuid-char")
    private UUID id;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @Transient
    public boolean equals(Object obj) {

        return obj != null
                && this.getClass().isAssignableFrom(obj.getClass())
                && this.getId() != null
                && Objects.equals(this.getId(), ((Entity<Serializable>) obj).getId());
    }

    @Transient
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return getClass().getSimpleName()+"{" +
                "id=" + id +
                "} ";
    }

    @javax.persistence.Transient
    @Getter
    private boolean createdNow = false;

    @PostPersist
    private void setCreatedNow(){
        this.createdNow = true;
    }




}
