/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service;

import it.antlab.iam.core.model.UserToken;

import java.util.List;
import java.util.UUID;

/**
 * Created by klayer3 on 23/03/22.
 */
public interface UserTokenService {
    List<UserToken> getTokens(UUID userId);

    UserToken deleteToken(UUID userId, UUID tokenId);

    UserToken generateToken(UUID userId, Long durationSeconds);
}

