/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service.impl;


import it.antlab.iam.core.dto.ProviderUser;
import it.antlab.iam.core.dto.UserResult;
import it.antlab.iam.core.enums.IAMUserType;
import it.antlab.iam.core.model.Provider;
import it.antlab.iam.core.model.User;
import it.antlab.iam.core.model.UserProvider;
import it.antlab.iam.core.repository.ProviderRepository;
import it.antlab.iam.core.service.UserProviderService;
import it.antlab.iam.core.service.UserResultService;
import it.antlab.iam.core.service.UserService;
import it.antlab.utils.nassert.NAssert;
import it.antlab.utils.nassert.NAssertException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 21/03/22.
 */
@Service
@Slf4j
public class UserResultServiceImpl implements UserResultService {

    @Autowired
    private ProviderRepository providerRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private UserProviderService userProviderService;

    @Override
    @Transactional(readOnly = true)
    public UserResult findById(UUID id) {
        User user = userService.read(id);
        if(user != null){
            return toUserResult(user, false);
        }
        return null;
    }

    @Override
    @Transactional(readOnly = true)
    public UserResult findByIdVerifyTokenExists(UUID userId, String tokenId, String token) {
        log.info("Trying to find user with userId {}, tokenId {}, token {}", userId, tokenId, token);
        User user = userService.read(userId);

        if( user != null){
            if( StringUtils.isNotEmpty(user.getSecret()) ){
                return toUserResult(user, false);
            } else if( StringUtils.isNotEmpty(tokenId)) {
                // controllo il token solo per le utenze che non hanno password
                return toUserResult(user, !userService.isValidToken(userId, UUID.fromString(tokenId), token));
            } else {
                //FIXME K3 potremmo gestire il tipo di autenticazione // qui passa per utenti con provider
                return toUserResult(user, false);
            }
        }
        return null;
    }

    private UserResult toUserResult(User user, boolean isExpiredToken) {
        UserResult result = null;
        if( user != null) {
            boolean isNotObsolete = !user.isObsolete();
            result = new UserResult(
                    user.getUsername(),
                    ObjectUtils.firstNonNull(user.getSecret(), user.getUsername()),
                    isNotObsolete && user.isEnabled(),
                    isNotObsolete,
                    isNotObsolete && !isExpiredToken,
                    isNotObsolete && !user.isLocked(),
                    user.getRoles().stream().map(r -> new SimpleGrantedAuthority(r.getId())).collect(Collectors.toList())
            );
            result.setId(user.getId());
            if(!isExpiredToken && isNotObsolete && !user.isLocked() && user.isEnabled()) {
                result.setCustomData(userService.getCustomData(user.getId()));
            }
        }
        return result;
    }

    @Override
    @Transactional
    public UserResult getUser(ProviderUser providerUser, boolean createOnMissing) {
        log.info("getUser by providerUser {}, createOnMissing {}", providerUser, createOnMissing);
        Provider provider = providerRepository.findById(providerUser.getProviderId()).orElseThrow(() -> NAssertException.builder("iam/unknown_provider").message("Provider not found with the given id").build());
        NAssert.state(!provider.isObsolete(), "iam/provider_not_enabled","Provider is not enabled");
        NAssert.state(StringUtils.isNotEmpty(providerUser.getProviderUserId()), "iam/invalid_provider_user_id","Provider userId required!");
        UserProvider userProvider = userProviderService.getByProviderIdAndProviderUserId(provider.getId(), providerUser.getProviderUserId());
        UUID userId = null;
        boolean createdNow= false;

        if( userProvider == null){
            if( createOnMissing){
                userId = createUser(providerUser).getId();
                createdNow= true;
            }  else {
                return null;
            }
        } else {
            userId = userProvider.getUserId();
        }

        UserResult result = userId != null ? findById(userId) : null;
        if( result != null){
            result.setCreatedNow(createdNow);
            //fixme potremmo salvare il dato ... sulla custom_data
            result.setEmailVerified(providerUser.isEmailVerified());
        }

        return result;
    }

    //FIXME K3 da spostare?
    private User createUser(ProviderUser providerUser){

        log.info("createUser by providerUser {}", providerUser);
        // Creiamo il nuovo utente
        User user = new User();
        user.setUsername(ObjectUtils.firstNonNull(providerUser.getEmail(), providerUser.getName(), providerUser.getProviderId()+"_"+providerUser.getProviderUserId()));
        user.setSecret(null);
        user.setUserType(IAMUserType.PROVIDER);
        user = userService.insert(user);
        UserProvider userProvider = new UserProvider();
        userProvider.setProviderId(providerUser.getProviderId());
        userProvider.setUserId(user.getId());
        userProvider.setEmail(providerUser.getEmail());
        userProvider.setProviderUserId(providerUser.getProviderUserId());
        userProvider.setDisplayName(ObjectUtils.firstNonNull(providerUser.getName(), providerUser.getEmail(), providerUser.getProviderUserId()));
        userProviderService.insert(userProvider);
        return user;

    }

    @Override
    @Transactional(readOnly = true)
    public UserResult loadUserByUsername(String username) throws UsernameNotFoundException {
        UserResult result = toUserResult(userService.findByUsername(username), false);
        NAssert.state(result != null, new UsernameNotFoundException(""));
        return result;
    }
}
