/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service.impl;

import it.antlab.iam.core.model.UserProvider;
import it.antlab.iam.core.repository.UserProviderRepository;
import it.antlab.iam.core.service.UserProviderService;
import it.antlab.iam.core.service.base.ObsoleteDeletionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

/**
 * Created by klayer3 on 23/03/22.
 */
@Service
public class UserProviderServiceImpl extends ObsoleteDeletionService<UserProvider> implements UserProviderService {
    @Autowired
    private UserProviderRepository userProviderRepository;

    @Override
    public UserProvider getByProviderIdAndProviderUserId(String providerId, String providerUserId) {
        return userProviderRepository.getByProviderIdAndProviderUserId(providerId, providerUserId);
    }

    @Override
    public UserProvider getByProviderIdAndUserId(String providerId, UUID userId) {
        return userProviderRepository.getByProviderIdAndUserId(providerId, userId);
    }

    @Override
    public List<UserProvider> getProvidersForUser(UUID id) {
        return userProviderRepository.getAllByUserId(id);
    }
}
