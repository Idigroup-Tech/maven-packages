/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service.impl;


import it.antlab.iam.core.dto.AuthResult;
import it.antlab.iam.core.dto.JwtRef;
import it.antlab.iam.core.dto.UserResult;
import it.antlab.iam.core.service.AuthService;
import it.antlab.iam.core.service.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 23/03/22.
 */
@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private JwtService jwtService;

    @Override
    public Optional<UserResult> getCurrentUser(){
        return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
                //.filter(a -> !AnonymousAuthenticationToken.class.isAssignableFrom(a.getClass()))
                .map(a -> (UserResult) a.getPrincipal());
    }

    @Override
    public AuthResult getAuthResult(Authentication authentication, String context) {
        AuthResult authResult = new AuthResult();
        UserResult userResult = (UserResult) authentication.getPrincipal();

        authResult.setAccessToken(
                generateToken(userResult, null, null ));
        authResult.setType(context);

        return authResult;
    }

    @Override
    public String generateToken(UserResult userResult, UUID tokenId, Long durationInSeconds){

        Collection<GrantedAuthority> authorities = Optional.ofNullable( userResult.getAuthorities()).orElse(Collections.emptyList());
        Map claims = new HashMap<>();
        if( userResult.getCustomData() != null){
            claims.putAll(userResult.getCustomData());
        }
        return jwtService.createJwt(
                JwtRef.builder()
                        .sub(userResult.getId().toString())
                        .emailVerified(userResult.isEmailVerified())
                        .jti(tokenId != null ? tokenId.toString() : null)
                        .name(userResult.getUsername())
                        .roles(authorities.stream().map( a -> a.getAuthority()).collect(Collectors.toList()))
                        .allClaims(claims)
                        .build(), durationInSeconds );

    }
}
