package it.antlab.iam.core.model;


import it.antlab.iam.core.model.base.AuditingEntity;
import it.antlab.iam.core.model.converter.MapConverter;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Map;
import java.util.UUID;

/**
 * Created by klayer3 on 18/06/25
 */
@Entity
@Table(name = "iam_user_claims")
@Getter
@Setter
public class UserClaim extends AuditingEntity {
    @Id
    @Type(type = "uuid-char")
    private UUID userId;

    @Column(name ="claims_data")
    @Convert(converter = MapConverter.class)
    private Map<String, Object> claims;
}
