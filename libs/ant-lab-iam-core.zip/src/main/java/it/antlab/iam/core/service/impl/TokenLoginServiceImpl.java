/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service.impl;


import it.antlab.iam.core.authentication.TokenAuthentication;
import it.antlab.iam.core.dto.AuthResult;
import it.antlab.iam.core.dto.AuthTokenRequest;
import it.antlab.iam.core.service.AuthService;
import it.antlab.iam.core.service.TokenLoginService;
import it.antlab.utils.nassert.NAssert;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/**
 * Created by klayer3 on 22/03/22.
 */
@Service
@Slf4j
public class TokenLoginServiceImpl implements TokenLoginService {
    @Autowired
    @Lazy
    private AuthenticationManager authenticationManager;

    @Autowired
    private AuthService authResultService;

    @Override
    public AuthResult login(AuthTokenRequest authRequest) {
        // Facciamo un provide
        try {
            log.info("Authenticating user by token...") ;
            Authentication authentication = this.authenticationManager.authenticate(new TokenAuthentication(authRequest.getToken()));
            NAssert.state(isAuthenticated(authentication), "iam/invalid-token-login");
            return authResultService.getAuthResult(authentication, "token-login");
        } catch (ProviderNotFoundException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    protected boolean isAuthenticated(Authentication authentication) {
        return authentication != null && !(authentication instanceof AnonymousAuthenticationToken) && authentication.isAuthenticated();
    }
}
