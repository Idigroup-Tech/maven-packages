/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import it.antlab.iam.core.model.base.AuditingEntity;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Objects;
import java.util.UUID;

/**
 * Created by klayer3 on 21/03/22.
 */
@Entity
@Table(
        name = "iam_user_token",
        indexes = @Index(name = "idx_user_token_user", columnList = "user_id")
)
@Getter
@Setter
// interna per api key
public class UserToken extends AuditingEntity implements io.nettuno.dynacrud.base.Entity<UUID> {

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    @Type(type = "uuid-char")
    // lo stacca l'applicazione non hibernate
    private UUID id;

    @Column(name = "user_id", nullable = false)
    @Type(type = "uuid-char")
    private UUID userId;

    @Column(name = "token", nullable = false, length = 1000)
    @JsonIgnore
    private String token; //FIXME BCRIPT

    @Override
    public boolean equals(Object o) {
        if (o == null || !UserToken.class.isAssignableFrom(o.getClass())) return false;
        UserToken item = (UserToken) o;
        return Objects.equals(id, item.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
