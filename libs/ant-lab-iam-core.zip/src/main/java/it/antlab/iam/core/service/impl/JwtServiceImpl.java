/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service.impl;


import io.jsonwebtoken.*;
import io.jsonwebtoken.impl.DefaultClaims;
import it.antlab.iam.core.conf.properties.JwtProperties;
import it.antlab.iam.core.dto.JwtRef;
import it.antlab.iam.core.service.JwtService;
import it.antlab.utils.nassert.NAssert;
import it.antlab.utils.nassert.NAssertException;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.Objects;

/**
 * Created by klayer3 on 21/03/22.
 */
@Service
public class JwtServiceImpl implements JwtService {

    @Autowired
    private JwtProperties jwtPropeties;

    private String secretKey;

    @PostConstruct
    private void init(){
        this.secretKey =  Base64.getEncoder().encodeToString(jwtPropeties.getSecret().getBytes());
    }

    @Override
    public boolean isValid(String token) throws CredentialsExpiredException {
        try {
            /*

               parseClaimsJws:
UnsupportedJwtException – if the claimsJws argument does not represent an Claims JWS
MalformedJwtException – if the claimsJws string is not a valid JWS
SignatureException – if the claimsJws JWS signature validation fails
ExpiredJwtException – if the specified JWT is a Claims JWT and the Claims has an expiration time before the time this method is invoked.
IllegalArgumentException – if the claimsJws string is null or empty or only whitespace
             */

            Claims claims = Jwts.parser().setSigningKey(this.secretKey).parseClaimsJws(token).getBody();
            NAssert.state(Objects.equals(claims.getIssuer(), jwtPropeties.getIssuer()), "iam/invalid_issuer");
            return true;
        } catch (ExpiredJwtException e) {
            throw  new CredentialsExpiredException("iam/token_expired");
        }
        catch (NAssertException | IllegalArgumentException | UnsupportedJwtException | MalformedJwtException | SignatureException ex){
            return false;
        }
    }

    @Override
    public JwtRef getRef(String token) {
      if(isValid(token)) {
          Claims claims = Jwts.parser().setSigningKey(this.secretKey).parseClaimsJws(token).getBody();
          return JwtRef.builder()
                  .aud(claims.getAudience())
                  .iss(claims.getIssuer())
                  .jti(claims.getId())
                  .sub(claims.getSubject())
                  .roles((Collection<String>) claims.get("roles"))
                  .name(Objects.toString(claims.get("name")))
                  .build();
      } else {
          return null;
      }
    }

    @Override
    public String createJwt(JwtRef jwtRef, Long expiration) {

        NAssert.state(jwtRef != null && StringUtils.isNotEmpty(StringUtils.trim(jwtRef.getSub())), "iam/jwt-sub-required");
        Claims claims = jwtRef.getAllClaims() != null ? new DefaultClaims(jwtRef.getAllClaims()) : Jwts.claims();
        claims.setSubject(jwtRef.getSub());
        claims.setAudience(ObjectUtils.firstNonNull(jwtRef.getAud(), claims.getAudience()) );
        claims.setId(ObjectUtils.firstNonNull(jwtRef.getJti(), claims.getId()) );
        claims.setIssuer(ObjectUtils.firstNonNull(jwtRef.getIss(), jwtPropeties.getIssuer()));
        claims.put("roles", jwtRef.getRoles());
        claims.put("name", jwtRef.getName());
        claims.put("emailVerified", jwtRef.isEmailVerified());

        expiration = expiration != null ? expiration : jwtPropeties.getDurationInSeconds();
        NAssert.state(expiration != null && expiration > 0L, "iam/invalid-token-expiration");

        Date now = new Date();
        Date validity = new Date(System.currentTimeMillis() + expiration * 1000L);

        return Jwts.builder().setClaims(claims).setIssuedAt(now).setExpiration(validity).signWith(SignatureAlgorithm.HS256, this.secretKey).compact();
    }
}
