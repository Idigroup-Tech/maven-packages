/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.conf;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Objects;

/**
 * Created by klayer3 on 21/05/22.
 */
@Configuration
@EnableCaching
@Slf4j
public class CacheConfig {


    private final CacheManager cacheManager;

    {
        cacheManager =new ConcurrentMapCacheManager(/*Caches.FirebaseToken, Caches.AuthToken, Caches.TokenLogin, Caches.User*/);
    }


    @Bean
    public CacheManager cacheManager() {
        return cacheManager;
    }

    @Scheduled(fixedRate = 30000, initialDelay = 60000 )
    public void evictAllCaches() {
        log.info("evicting all caches");
        cacheManager.getCacheNames().stream().map(cacheManager::getCache).filter(Objects::nonNull).forEach(Cache::clear);
    }

    public interface Caches {
        String FirebaseToken = "FirebaseToken";
        String AuthToken = "AuthToken";
        String TokenLogin = "TokenLogin";
        String User="User";

    }
}
