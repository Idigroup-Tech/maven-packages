/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.model;


import it.antlab.iam.core.model.base.AuditingEntity;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.UUID;

/**
 * Created by klayer3 on 16/08/24
 */
@Entity
@Table(
        name = "iam_sso_trx"
)
@Getter
@Setter
public class SSOTransaction extends AuditingEntity {
    @Id
    @Column(name = "id", updatable = false, nullable = false)
    @Type(type = "uuid-char")
    // lo stacca l'applicazione non hibernate
    private UUID id;

    @Column(name = "user_id", nullable = false)
    @Type(type = "uuid-char")
    @NonNull
    private UUID userId;

    @Column(name = "trx_hash", nullable = false, length = 255 )
    private String trxHash; //FIXME BCRIPT

    @Version
    @Column(name = "version")
    private int version = 0;

    @PrePersist
    private void prePersist() {
        this.id = UUID.randomUUID();
        this.trxHash = DigestUtils.sha256Hex(id +"_" + RandomStringUtils.random(12)+ "_"+ userId);
    }



    //potremmo aggiungere

}
