/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service;


import it.antlab.iam.core.model.SSOTransaction;
import it.antlab.iam.core.repository.SSOTransactionRepository;


import it.antlab.utils.nassert.NAssert;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

/**
 * Created by klayer3 on 16/08/24
 */
@Service
public class SSOService {

    @Value("${application.sso.config.transaction.durationMinutes:30}")
    private int transactionDurationMinutes = 0;

    @Value("${application.sso.config.transaction.testMode:false}")
    private boolean testMode = false;

    @Value("${application.sso.config.transaction.expiration.check.enabled:true}")
    private boolean expirationEnabled = true;
    @Value("${application.sso.config.transaction.obsolete.check.enabled:true}")
    private boolean obsoleteEnabled = true;

    @Value("${application.sso.config.transaction.obsolete.on.new.enabled:true}")
    private boolean obsoleteOnNewEnabled = false;

    private final SSOTransactionRepository ssoTransactionRepository;

    public SSOService(SSOTransactionRepository ssoTransactionRepository) {
        this.ssoTransactionRepository = ssoTransactionRepository;
    }

    @Transactional
    public String createTransaction(UUID userId){
        //FIXME SCOPE o OTP -> LOGIN -> RESET PASSWORD ->
        SSOTransaction ssoTransaction = new SSOTransaction();
        //Fixme potremmo aggiornare dei contatori e farlo riscattare n volte configurabile alla creazioe della transaction: SSOTransaction.availableTimes
        ssoTransaction.setUserId(userId);
        if(!testMode) {
           if(obsoleteOnNewEnabled) ssoTransactionRepository.setAllObsoleteByUserId(userId);
        }
        return ssoTransactionRepository.save(ssoTransaction).getTrxHash();
    }

    @Transactional
    public UUID consumeTransaction(String trxHash){
        //Fixme potremmo aggiornare dei contatori e farlo riscattare n volte configurabile alla creazioe della transaction: SSOTransaction.availableTimes
        SSOTransaction  ssoTransaction = ssoTransactionRepository.findOneByTrxHash(trxHash).orElse(null);
        NAssert.state(ssoTransaction != null, "sso-transaction/invalid-trx-hash");
        NAssert.state(!ssoTransaction.isObsolete(), "sso-transaction/obsolete-trx-hash");
        if(!testMode) {
            if(expirationEnabled) NAssert.state(ChronoUnit.MINUTES.between(ssoTransaction.getDateCreated(), LocalDateTime.now()) <= transactionDurationMinutes, "sso-transaction/expired-trx-hash");
            if(obsoleteEnabled) ssoTransaction.setObsolete(true);
        }
        return ssoTransactionRepository.save(ssoTransaction).getUserId();
    }


}
