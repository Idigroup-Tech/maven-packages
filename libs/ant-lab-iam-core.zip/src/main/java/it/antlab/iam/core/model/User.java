/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.nettuno.dynacrud.base.IgnoreSearch;
import it.antlab.iam.core.enums.IAMUserType;
import it.antlab.iam.core.model.base.BaseAuditingEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by klayer3 on 21/03/22.
 */
@Entity
@Table(name = "iam_user",
        uniqueConstraints = @UniqueConstraint(name = "uidx_user_username", columnNames= {"username"}))
@Getter
@Setter
//FIXME user extra su Resource
public class User extends BaseAuditingEntity {
    @Column(name = "username", nullable = false)
    @NotNull
    private String username;

    @Column(name = "secret")
    @IgnoreSearch
    @JsonIgnore
    private String secret;

    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private IAMUserType userType;

    @ManyToMany(cascade = CascadeType.REMOVE)
    @JoinTable(
            name = "iam_user_role",
            joinColumns = { @JoinColumn(name = "user_id") },
            inverseJoinColumns = { @JoinColumn(name = "role_id") }
    )
    @JsonIgnore
    @IgnoreSearch
    private List<Role> roles = new ArrayList<>();

    @Column(name = "locked", nullable = false)
    private boolean locked= false;

    @Column(name = "enabled", nullable = false)
    private boolean enabled = true;

    /*
     DA gestire in futuro
    @Column(name = "credentialsExpired", nullable = false)
    private boolean credentialsExpired = false;

    @Column(name = "expired", nullable = false)
    private boolean expired = false;

     */



    @Override
    public String toString() {
        return "User{" +
                "id=" + getId() +
                ",username='" + username + '\'' +
                '}';
    }
}
