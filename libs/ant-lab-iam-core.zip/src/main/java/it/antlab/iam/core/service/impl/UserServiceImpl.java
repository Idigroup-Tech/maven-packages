/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.service.impl;


import com.google.firebase.auth.*;
import it.antlab.iam.core.dto.AddUserByProviderResult;
import it.antlab.iam.core.enums.IAMUserType;
import it.antlab.iam.core.model.User;
import it.antlab.iam.core.model.UserClaim;
import it.antlab.iam.core.model.UserProvider;
import it.antlab.iam.core.model.UserToken;
import it.antlab.iam.core.repository.*;
import it.antlab.iam.core.service.ProviderService;
import it.antlab.iam.core.service.UserProviderService;
import it.antlab.iam.core.service.UserService;
import it.antlab.iam.core.service.base.ObsoleteDeletionService;
import it.antlab.utils.nassert.NAssert;
import it.antlab.utils.nassert.NAssertException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.io.Serializable;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;


/**
 * Created by klayer3 on 21/03/22.
 */
@Service("UserCrudService")
@Slf4j
public class UserServiceImpl extends ObsoleteDeletionService<User> implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserTokenRepository userTokenRepository;

    @Autowired
    private ProviderService providerService;

    @Autowired
    private UserProviderService userProviderService;

    @Autowired
    private UserClaimRepository userClaimRepository;

    @Autowired
    private SSOTransactionRepository ssoTransactionRepository;

    @Autowired
    private UserProviderRepository userProviderRepository;

    @Autowired
    private UserTokenRepository tokenRepository;

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Value("${application.iam.firebase.enableUserCreation:true}")
    private boolean enableFirebaseUserCreation;

    @Value("${application.default.auth.provider}")
    private String defaultAuthProvider = "firebase";

    public User findByUsername(String username) {
        return this.userRepository.findByUsername(username);
    }

    @Override
    public boolean  isValidToken(UUID userId, UUID tokenID, String token) {
        UserToken userToken =  userTokenRepository.findById(tokenID);
        if( userToken != null){
            return Objects.equals(userToken.getUserId(), userId) && Objects.equals(userToken.getToken(), token);
        }
        return false;
    }

    @Override
    public Map<String, Object> getCustomData(UUID userId) {
        NAssert.state(read(userId) != null ,"iam/invalid-user-id");
        return userClaimRepository.findById(userId).filter(UserClaim::isNotObsolete).map(UserClaim::getClaims).orElse(null);
    }


    @Override
    public void saveCustomData(UUID userId, Map<String, Object> customData) {
        if( customData != null){
            UserClaim claim = userClaimRepository.findById(userId).orElse(new UserClaim());
            claim.setClaims(customData);
            claim.setUserId(userId);
            claim.setObsolete(false);
            userClaimRepository.save(claim);
        } else {
            //FIXME prima lo eliminavamo ora lo metto obsolete o lo eliminaimo?
            userClaimRepository.findById(userId).ifPresent(userClaim -> {
                userClaim.markAsObsolete();
                userClaimRepository.save(userClaim);
            } );
        }
    }

    @Override
    public AddUserByProviderResult insert(UserProvider userProvider, String callbackUrl, boolean needPwdReset, boolean needEmailVerification, String fakePwd) {
        try {
            final AddUserByProviderResult user = getUser(userProvider, callbackUrl, needPwdReset, needEmailVerification, fakePwd);
            return user;
        }catch (FirebaseAuthException authException){
            throw NAssertException.builder("iam/error-creation-user-by-provider").message(String.format("%s %s %s",FirebaseAuthException.class.getSimpleName(), authException.getAuthErrorCode(), authException.getMessage())).cause(authException).build();
        }
    }

    @Override
    public String getResetPasswordLink(UUID userId, String providerId, String callbackUrl) {
        log.info("getResetPasswordLink({}, {}, {})", userId, providerId, callbackUrl);
        UserRecord existingFirebaseUser = getUserRecord(userId, providerId);

        try {
            String resetPasswordLink = null;
            if(StringUtils.isNotBlank(callbackUrl)) {
                resetPasswordLink = FirebaseAuth.getInstance().generatePasswordResetLink(existingFirebaseUser.getEmail(), ActionCodeSettings.builder().setUrl(callbackUrl).build());
            } else {
                resetPasswordLink = FirebaseAuth.getInstance().generatePasswordResetLink(existingFirebaseUser.getEmail());
            }
            log.info("getResetPasswordLink {} : {}", userId, resetPasswordLink);
            return resetPasswordLink;
        }catch (FirebaseAuthException authException){
            throw NAssertException.builder("iam/unable-to-generate-reset-password-link").message(authException.getMessage()).cause(authException).build();
        }
    }

    @Override
    public void resetProviderPassword(UUID userId, String providerId, String newPassword) {
        log.info("resetProviderPassword userId {} providerId {}", userId, providerId);
        NAssert.state(StringUtils.isNotBlank(newPassword), "iam/reset-password-invalid", "Password must not be blank.");
        UserRecord providerUser = getUserRecord(userId, providerId);

        try {
            UserRecord updatedUser = FirebaseAuth.getInstance().updateUser(providerUser.updateRequest().setPassword(newPassword));
        }catch (FirebaseAuthException authException){
            throw NAssertException.builder("iam/unable-to-reset-provider-password").message(authException.getMessage()).cause(authException).build();
        }
    }

    @Override
    public String getEmailVerificationLink(UUID userId, String providerId, String callbackUrl) {
        UserRecord existingFirebaseUser = getUserRecord(userId, providerId);

        try {
            if(StringUtils.isNotBlank(callbackUrl)) {
                return FirebaseAuth.getInstance().generateEmailVerificationLink(existingFirebaseUser.getEmail(), ActionCodeSettings.builder().setUrl(callbackUrl).build());
            }
            return FirebaseAuth.getInstance().generateEmailVerificationLink(existingFirebaseUser.getEmail());
        }catch (FirebaseAuthException authException){
            throw NAssertException.builder("iam/unable-to-generate-email-verification-link").message(authException.getMessage()).cause(authException).build();
        }
    }

    private UserRecord getUserRecord(UUID userId, String inputProviderId) {
        final String providerId = getProviderIdOrDefault(inputProviderId);
        User user = read(userId);
        NAssert.state(user != null, "iam/user-not-found");
        UserProvider userProvider= userProviderService.getByProviderIdAndUserId(providerId, userId);
        NAssert.state(userProvider != null, "iam/user-provider-not-found");
        UserRecord existingFirebaseUser;
        try {
            existingFirebaseUser = FirebaseAuth.getInstance().getUser(userProvider.getProviderUserId());
        }catch (FirebaseAuthException authException){
            throw NAssertException.builder("iam/unable-to-retrieve-provider-user").message(authException.getMessage()).cause(authException).build();
        }
        return existingFirebaseUser;
    }

    private String getProviderIdOrDefault(String inputProviderId) {
        return StringUtils.defaultIfBlank(inputProviderId, defaultAuthProvider);
    }

    @Override
    public String getCustomToken(UUID id, String provideId) {
        //FIXME USARE getProviderIdOrDefault
        User user = read(id);
        NAssert.state(user != null && user.isEnabled() && !user.isObsolete() && !user.isLocked(), new ResponseStatusException(HttpStatus.FORBIDDEN, "invalid user state"));
        UserProvider userProvider = userProviderService.getByProviderIdAndUserId(provideId, id);
        NAssert.state(userProvider != null && !userProvider.isObsolete(), new ResponseStatusException(HttpStatus.FORBIDDEN, "user is not allowed for provider:" +provideId));
        try {
            return FirebaseAuth.getInstance().createCustomToken(userProvider.getProviderUserId());
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY, e.getMessage());
        }
    }

    private AddUserByProviderResult getUser(UserProvider userProviderInput, String callbackUrl, boolean needPwdReset, boolean needEmailVerification, String password) throws FirebaseAuthException {
        AddUserByProviderResult ret = new AddUserByProviderResult();
        User user = null;
        // FIXME k3 dovremmo gestire il passaggio di uno per volta a parità di email
        UserRecord existingFirebaseUser;
        try {
            existingFirebaseUser = FirebaseAuth.getInstance().getUserByEmail(userProviderInput.getEmail());
        }catch (FirebaseAuthException authException){
            if(!AuthErrorCode.USER_NOT_FOUND.equals(authException.getAuthErrorCode())) {
                throw authException;

            }
            existingFirebaseUser = null;
        }
        NAssert.state(providerService.read(userProviderInput.getProviderId())!= null, "iam/invalid-provider-id");

        //FIXME K3 potrebbe esistere lo user come utente non di provider. Questo caso però sarebbe anomalo ed andrebbe analizzato. Quindi lascio che salti
        if (existingFirebaseUser != null) {
           ret.setProviderUserExists(true);
           UserProvider userProvider = userProviderService.getByProviderIdAndProviderUserId(userProviderInput.getProviderId(), existingFirebaseUser.getUid());
           if( userProvider != null){
               ret.setUserExists(true);
               user = read(userProvider.getUserId());
               NAssert.state(user != null,  new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "iam/user-provider-found-without-user"));
           }
        }

        if(user == null){
            final UserRecord firebaseUser;
            if( existingFirebaseUser != null){
                firebaseUser = existingFirebaseUser;
            } else {
                NAssert.state(enableFirebaseUserCreation, "iam/firebase-user-creation-not-enabled", "please call create the firebase user manually");
                UserRecord.CreateRequest createRequest = new UserRecord.CreateRequest();
                createRequest.setDisplayName(ObjectUtils.firstNonNull(userProviderInput.getEmail(), userProviderInput.getDisplayName()));
                createRequest.setEmail(userProviderInput.getEmail());
                createRequest.setEmailVerified(needEmailVerification ? Boolean.FALSE : Boolean.TRUE);
                createRequest.setDisabled(false);
                createRequest.setPassword(Optional.ofNullable(password).filter( p -> StringUtils.isNotBlank(p)).orElseGet(() -> RandomStringUtils.random(10, "AbcdefgHilmnoPqrStUvz@.-Ueq#")));
                firebaseUser = FirebaseAuth.getInstance().createUser(createRequest);
                ret.setNeedPasswordReset(needPwdReset);
                if(needPwdReset) {
                    if (StringUtils.isNotBlank(callbackUrl)) {
                        ret.setPasswordResetLink(FirebaseAuth.getInstance().generatePasswordResetLink(userProviderInput.getEmail(), ActionCodeSettings.builder().setUrl(callbackUrl).build()));
                    } else {
                        ret.setPasswordResetLink(FirebaseAuth.getInstance().generatePasswordResetLink(userProviderInput.getEmail()));
                    }
                }
            }

            user = new User();
            user.setUsername(userProviderInput.getEmail());
            user.setUserType(IAMUserType.PROVIDER);
            user = insert(user);
            final UserProvider userProvider = new UserProvider();
            userProvider.setUserId(user.getId());
            userProvider.setProviderId(userProviderInput.getProviderId());
            userProvider.setProviderUserId(firebaseUser.getUid());
            userProvider.setEmail(userProviderInput.getEmail());
            userProvider.setDisplayName(ObjectUtils.firstNonNull(userProviderInput.getDisplayName(), firebaseUser.getDisplayName(), userProviderInput.getEmail(), firebaseUser.getEmail(), firebaseUser.getUid() ));
            userProviderService.insert(userProvider);
        }

        ret.setUserId(user.getId());
        return ret;
    }


    @Override
    @Transactional
    public User delete(Serializable id) {
        User user = read(id);
        if( user != null){
            log.info("deleting user {}",user.getId());
            user.markAsObsolete();
            user.setEnabled(false);
            //vecchia email su password per eventuale recupero.... dati
            user.setSecret(user.getId().toString());
            //cancelliamo i dati
            userProviderRepository.getAllByUserId(user.getId()).forEach(this::removeUserProvider);
            ssoTransactionRepository.setAllObsoleteByUserId(user.getId());
            tokenRepository.setAllObsoleteByUserId(user.getId());
            userRoleRepository.setAllObsoleteByUserId(user.getId());
            user.setUsername(user.getId().toString());
            return this.getRepository().save(user);
        }
        return null;
    }

    private void removeUserProvider(UserProvider userProvider) {
        if( userProvider != null){
            log.info("deleting user provider for userId {} providerId {}", userProvider.getUserId(), userProvider.getProviderId());
            NAssert.state(StringUtils.equals("firebase",userProvider.getProviderId()), "user-provider/unknown-provider", userProvider.getProviderId()+" is not handled");

            try {
                UserRecord existingFirebaseUser = FirebaseAuth.getInstance().getUser(userProvider.getProviderUserId());
                if( existingFirebaseUser != null){
                    log.info("deleting user provider for userId {} providerId {} providerUserId {}", userProvider.getUserId(), userProvider.getProviderId(), existingFirebaseUser.getUid());
                    FirebaseAuth.getInstance().deleteUser(existingFirebaseUser.getUid());
                }
            }catch (FirebaseAuthException authException){

                if(!AuthErrorCode.USER_NOT_FOUND.equals(authException.getAuthErrorCode())) {
                    log.error("deleting user provider fail {} for userId {} providerId {} providerUserId {}", authException.getMessage(), userProvider.getUserId(), userProvider.getProviderId(), userProvider.getProviderUserId());
                    throw new RuntimeException(authException.getMessage(), authException);
                }

            }
            userProvider.setObsolete(true);
            userProviderRepository.save(userProvider);
        }
    }


}
