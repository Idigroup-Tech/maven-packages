/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * Created by klayer3 on 21/03/22.
 */
@Setter
@Getter
@Builder
public class ProviderUser {
    private String providerId;
    private String name;
    private String providerUserId;
    private String email;
    private String issuer;
    private String picture;
    private boolean emailVerified;
    private String tenant;
    private Map<String, Object> claims;

    @Override
    public String toString() {
        return "ProviderUser{" +
                "providerUserId='" + providerUserId + '\'' +
                ", providerId='" + providerId + '\'' +
                '}';
    }
}
