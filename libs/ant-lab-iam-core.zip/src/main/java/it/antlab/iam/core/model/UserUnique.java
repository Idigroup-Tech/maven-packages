/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.model;

/**
 * Created by klayer3 on 21/03/22.
 */
//pensata per gestire altri modi di individuare l'utente o di conventirlo in dialoghi esterni... potrebbe bastare anche lo //FIXME user extra su Resource ragionaci
public class UserUnique {
    // FIXME K3 FORSE meglio UserAlias
    // DOBBIAMO CAPIRE SE tenerlo qui forse meglio esterno per motivi di sicurezza
}
