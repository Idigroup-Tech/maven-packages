package it.antlab.iam.core.repository;

import it.antlab.iam.core.model.UserClaim;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface UserClaimRepository extends JpaRepository<UserClaim, UUID> {
}