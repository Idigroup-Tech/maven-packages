/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.core.test;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.nettuno.dynacrud.model.dto.response.ResponseDTO;
import it.antlab.iam.core.IAMTestApplication;
import it.antlab.iam.core.conf.properties.InitializationProperties;
import it.antlab.iam.core.conf.properties.JwtProperties;
import it.antlab.iam.core.dto.AuthRequest;
import it.antlab.iam.core.dto.AuthResult;
import it.antlab.iam.core.dto.AuthTokenRequest;
import it.antlab.iam.core.dto.JwtRef;
import it.antlab.iam.core.enums.IAMRoles;
import it.antlab.iam.core.model.UserRole;
import it.antlab.iam.core.model.UserToken;
import it.antlab.iam.core.service.JwtService;
import it.antlab.utils.nassert.NAssert;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by klayer3 on 24/03/22.
 */
//FIXME RIVEDERE
@SpringBootTest(classes = IAMTestApplication.class)
@AutoConfigureMockMvc
public class UserTest {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private InitializationProperties initializationProperties;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private JwtProperties jwtProperties;


    @Test
    @SneakyThrows
    public void login()  {
        AuthResult ret = getAuthResult();
        NAssert.state(ret != null && StringUtils.isNotEmpty(ret.getAccessToken()) && Objects.equals("basic-login", ret.getType()), "fail");
    }

    private AuthResult getAuthResult() {
        AuthRequest request = new AuthRequest();
        request.setUsername(initializationProperties.getAdminUsername());
        request.setPassword(initializationProperties.getAdminPassword());
        AuthResult ret = login(request);
        return ret;
    }

    @Test
    @SneakyThrows
    public void loginByToken()  {
        AuthResult ret = getAuthResult();
        NAssert.state(ret != null && StringUtils.isNotEmpty(ret.getAccessToken()) && Objects.equals("basic-login", ret.getType()), "fail");

        AuthTokenRequest authTokenRequest = new AuthTokenRequest();
        authTokenRequest.setToken(ret.getAccessToken());

        AuthResult authResult = loginByToken(authTokenRequest);
        NAssert.state(authResult != null && StringUtils.isNotEmpty(authResult.getAccessToken()) && Objects.equals("token-login", authResult.getType()), "fail");
    }

    @Test
    public void testJwt(){
        AuthRequest request = new AuthRequest();
        request.setUsername(initializationProperties.getAdminUsername());
        request.setPassword(initializationProperties.getAdminPassword());
        AuthResult ret = login(request);
        NAssert.state(ret != null, "fail");
        JwtRef jwtRef = jwtService.getRef(ret.getAccessToken());
        NAssert.state(jwtRef.getName().equals(request.getUsername()), "wrong_name");
        NAssert.state(jwtRef.getRoles().contains(IAMRoles.IAM_ADMIN.name()), "wrong_roles");
    }

    @Test
    @SneakyThrows
    public void userCreateWithPassword(){
        getTestUser();
    }

    @Test
    @SneakyThrows
    public void editPassword(){

        UserEditPasswordDTO editPasswordDTO= new UserEditPasswordDTO();
        editPasswordDTO.setNewPassword("adminNewPassword");
        editPasswordDTO.setCurrentPassword("test");

        AuthResult authResult = getAuthResult();
        UserDTO test = getTestUser();
        String userID = test.getId().toString();


        MvcResult result= mvc.perform(patch("/users/{userId}/password", userID)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(editPasswordDTO))
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        UserDTO user = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserDTO>>() {}).getData();

        AuthRequest authRequest = new AuthRequest();
        authRequest.setPassword(editPasswordDTO.getNewPassword());
        authRequest.setUsername(test.getUsername());
        AuthResult newLogin = login(authRequest);

        NAssert.state(newLogin!= null, "invalidLogin");
        NAssert.state(Objects.equals(userID, jwtService.getRef(newLogin.getAccessToken()).getSub()), "fail");

    }

    @Test
    @SneakyThrows
    public void editCustomData(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser();

        Map<String,?> customData= Map.of("newCustomData", "newCustomData");
        MvcResult result= mvc.perform(put("/users/{userId}/custom-data", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customData))
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        UserDTO ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserDTO>>() {}).getData();

        NAssert.state(!Objects.equals(objectMapper.writeValueAsString(ret.getCustomData()), objectMapper.writeValueAsString(testUser.getCustomData())), "wrong_old_custom_data");
        NAssert.state(Objects.equals(objectMapper.writeValueAsString(ret.getCustomData()), objectMapper.writeValueAsString(customData)), "wrong_custom_data");
    }

    @Test
    @SneakyThrows
    public void patchCustomData(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser();

        Map<String,?> customData= Map.of("newCustomData", "newCustomData");


        MvcResult result= mvc.perform(patch("/users/{userId}/custom-data", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customData))
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        UserDTO ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserDTO>>() {}).getData();

        Map allCustomData = new HashMap<>();
        allCustomData.putAll(testUser.getCustomData());
        allCustomData.putAll(customData);

        NAssert.state(!Objects.equals(objectMapper.writeValueAsString(ret.getCustomData()), objectMapper.writeValueAsString(testUser.getCustomData())), "wrong_old_custom_data");
        NAssert.state(Objects.equals(objectMapper.writeValueAsString(ret.getCustomData()), objectMapper.writeValueAsString(allCustomData)), "wrong_custom_data");
    }

    @Test
    @SneakyThrows
    public void createTokenFail(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser();
        MvcResult result= mvc.perform(post("/users/{userId}/tokens", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().is4xxClientError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        ErrorResponse ret = objectMapper.readValue( result.getResponse().getContentAsString(), ErrorResponse.class);
        NAssert.state(Objects.equals(ret.getCode(),"iam/generate-token-on-user-with-secret"), "fail");

    }

    @Test
    @SneakyThrows
    public void createToken(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);
        createToken(authResult, testUser);
    }



    @Test
    @SneakyThrows
    public void readTokens(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);
        UserTokenCreatedDTO token = createToken(authResult, testUser);

        List<UserToken> ret = getUserTokens(authResult, testUser);
        NAssert.state(ret.stream().anyMatch( ut -> Objects.equals(ut.getId(), token.getDetails().getId())), "fail");
    }

    @Test
    @SneakyThrows
    public void deleteToken(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);
        UserTokenCreatedDTO token = createToken(authResult, testUser);

        MvcResult result= mvc.perform(delete("/users/{userId}/tokens/{tokenId}", testUser.getId(), token.getDetails().getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        UserToken deleteResult = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserToken>>() {}).getData();
        NAssert.state(deleteResult != null && deleteResult.isObsolete(), "fail" );
        NAssert.state(Objects.equals(deleteResult.getUserId(), testUser.getId()), "fail");
        NAssert.state(Objects.equals(deleteResult.getId(), token.getDetails().getId()), "fail");
        UserToken deletedToken = getUserTokens(authResult, testUser).stream().filter( ut -> Objects.equals(ut.getId(), deleteResult.getId())).findFirst().orElse(null);
        NAssert.state(deletedToken != null && deletedToken.isObsolete() && Objects.equals(deletedToken, deleteResult), "fail");
    }

    @Test
    @SneakyThrows
    public void readUsers(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);

        List<UserDTO> results = readUsers(authResult);
        NAssert.state(results.stream().anyMatch( res -> Objects.equals(res, testUser)), "fail");
    }



    @Test
    @SneakyThrows
    public void deleteUser(){

        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);

        MvcResult result= mvc.perform(delete("/users/{userId}", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        UserDTO deleteResult = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserDTO>>() {}).getData();
        NAssert.state(deleteResult != null && deleteResult.isObsolete(), "fail" );
        NAssert.state(Objects.equals(deleteResult, testUser), "fail");
        UserDTO deletedFromList = readUsers(authResult).stream().filter( ut -> Objects.equals(ut.getId(), deleteResult.getId())).findFirst().orElse(null);
        NAssert.state(deletedFromList != null && deletedFromList.isObsolete() && Objects.equals(deletedFromList, deleteResult), "fail");
    }

    @Test
    @SneakyThrows
    public void roleAdd(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);
        UserRole userRole = new UserRole();
        userRole.setUserId(testUser.getId());
        userRole.setRoleId(IAMRoles.IAM_ADMIN.name());
        MvcResult result= mvc.perform(post("/user-roles")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userRole))
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        UserRole ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserRole>>() {}).getData();

        NAssert.state(Objects.equals(userRole.getRoleId(), ret.getRoleId()), "fail");
        NAssert.state(Objects.equals(userRole.getUserId(), ret.getUserId()), "fail");
        NAssert.state(ret.getId() != null && !ret.isObsolete(), "fail");


    }

    @Test
    @SneakyThrows
    public void roleDelete(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);
        UserRole userRole = new UserRole();
        userRole.setUserId(testUser.getId());
        userRole.setRoleId(IAMRoles.IAM_ADMIN.name());
        MvcResult result= mvc.perform(post("/user-roles")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userRole))
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        UserRole ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserRole>>() {}).getData();

        NAssert.state(Objects.equals(userRole.getRoleId(), ret.getRoleId()), "fail");
        NAssert.state(Objects.equals(userRole.getUserId(), ret.getUserId()), "fail");
        NAssert.state(ret.getId() != null && !ret.isObsolete(), "fail");

        MvcResult deleteRes= mvc.perform(delete("/user-roles/{roleId}", ret.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();


        UserRole deleteResult = objectMapper.readValue( deleteRes.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserRole>>() {}).getData();

        NAssert.state(Objects.equals(userRole.getRoleId(), deleteResult.getRoleId()), "fail");
        NAssert.state(Objects.equals(userRole.getUserId(), deleteResult.getUserId()), "fail");
        NAssert.state(deleteResult.getId() != null && deleteResult.isObsolete(), "fail");
        NAssert.state(Objects.equals(deleteResult, ret), "fail");

    }

    @Test
    @SneakyThrows
    public void readSingleUser(){
        AuthResult authResult =  getAuthResult();
        UserDTO testUser = getTestUser(false);
        MvcResult result= mvc.perform(get("/users/{userId}", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        UserDTO results = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserDTO>>() {}).getData();
        NAssert.state(Objects.equals(testUser, results), "fail");
        
    }

    private List<UserDTO> readUsers(AuthResult authResult) throws Exception {
        MvcResult result= mvc.perform(get("/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        List<UserDTO> results = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<List<UserDTO>>>() {}).getData();
        return results;
    }

    private List<UserToken> getUserTokens(AuthResult authResult, UserDTO testUser) throws Exception {
        MvcResult result= mvc.perform(get("/users/{userId}/tokens", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        List<UserToken> ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<List<UserToken>>>() {}).getData();
        NAssert.state(ret != null && !ret.isEmpty(), "fail" );
        NAssert.state(ret.stream().allMatch( ut -> Objects.equals(ut.getUserId(), testUser.getId())), "fail");
        return ret;
    }


    private UserTokenCreatedDTO createToken(AuthResult authResult, UserDTO testUser) throws Exception {
        MvcResult result= mvc.perform(post("/users/{userId}/tokens", testUser.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + authResult.getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();
        UserTokenCreatedDTO ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserTokenCreatedDTO>>() {}).getData();

        NAssert.state(Objects.equals(jwtService.getRef(ret.getToken()).getSub(), testUser.getId().toString()), "fail");
        NAssert.state(Objects.equals(testUser.getId(),ret.getDetails().getUserId()), "fail");
        return ret;
    }
    private UserDTO getTestUser(){
        return getTestUser(true);
    }

    @SneakyThrows
    private UserDTO getTestUser(boolean setPassword) {
        UserAdd userAddDTO = new UserAdd();

        if(setPassword) {
            userAddDTO.setPassword("test");
        }
        userAddDTO.setUsername("test_"+new Random().nextInt());
        userAddDTO.setRoles(initializationProperties.getRoles());
        userAddDTO.setCustomData(Map.of("testData", "testData"));

        MvcResult result= mvc.perform(post("/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userAddDTO))
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + getAuthResult().getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        UserDTO ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserDTO>>() {}).getData();

        NAssert.state(ret!= null, "invalidLogin");
        if(setPassword) {
            NAssert.state(StringUtils.isEmpty(ret.getPassword()), "password_exposed");
            NAssert.state(ret.isHasPassword(), "need_password");
        }
        NAssert.state(Objects.equals(ret.getUsername(), userAddDTO.getUsername()), "wrong_username");
        NAssert.state(Objects.equals(StringUtils.join(ret.getRoles().toArray()), StringUtils.join(userAddDTO.getRoles().toArray())), "wrong_profiles");
        NAssert.state(Objects.equals(objectMapper.writeValueAsString(ret.getCustomData()), objectMapper.writeValueAsString(userAddDTO.getCustomData())), "wrong_custom_data");
        return ret;
    }


    @SneakyThrows
    private AuthResult loginByToken(AuthTokenRequest authRequest) {

        MvcResult result= mvc.perform(post("/token/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(authRequest)))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        AuthResult ret = objectMapper.readValue( result.getResponse().getContentAsString(), AuthResult.class);

        NAssert.state(ret!= null, "invalidLogin");
        return ret;
    }

    @SneakyThrows
    private AuthResult login(AuthRequest authRequest) {

        MvcResult result= mvc.perform(post("/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(authRequest)))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        AuthResult ret = objectMapper.readValue( result.getResponse().getContentAsString(), AuthResult.class);

        NAssert.state(ret!= null, "invalidLogin");
        return ret;
    }

    @Test
    @SneakyThrows
    public void createUserByProviderSuccess(){
       createUserByProvider();
    }

    @Test
    @SneakyThrows
    public void getExistingUserByProviderSuccess() {
      UserDTO ret = createUserByProvider();
      UserDTO ret2 = createUserByProvider();
      NAssert.state(ret.equals(ret2), "fail");
    }

    @Test
    @SneakyThrows
    public void getEmailVerification(){
        UserDTO userDTO = createUserByProvider();
        UserProviderDTO providerDTO = userDTO.getProviders().get(0);
        MvcResult result= mvc.perform(patch("/users/{userId}/email-verification-link/{providerId}", userDTO.getId(), providerDTO.getProviderId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + getAuthResult().getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        String ret = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<String>>() {}).getData();

        NAssert.state(ret!= null, "invalidLogin");

    }

    @SneakyThrows
    private UserDTO createUserByProvider(){
        AddUserByProvider userAddDTO = new AddUserByProvider();
        userAddDTO.setEmail("dev.klayer3@gmail.com");
        userAddDTO.setDisplayName("klayer3 test");
        userAddDTO.setProviderId("firebase");
        userAddDTO.setRoles(initializationProperties.getAdminRoles());
        userAddDTO.setCustomData(Map.of("test", "test"));


        MvcResult result= mvc.perform(post("/users/user-by-provider")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(userAddDTO))
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + getAuthResult().getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        AddUserByProviderResult userByProviderResult = objectMapper.readValue( result.getResponse().getContentAsString(), new TypeReference<ResponseDTO<AddUserByProviderResult>>() {}).getData();
        MvcResult resultUser= mvc.perform(get("/users/{userId}", userByProviderResult.getUserId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(jwtProperties.getHeader(), jwtProperties.getHeaderValuePrefix() + getAuthResult().getAccessToken())
                )
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andReturn();

        UserDTO ret = objectMapper.readValue( resultUser.getResponse().getContentAsString(), new TypeReference<ResponseDTO<UserDTO>>() {}).getData();

        NAssert.state(ret!= null, "invalidLogin");

        NAssert.state(Objects.equals(ret.getUsername(), userAddDTO.getEmail()), "wrong_username");
        NAssert.state(Objects.equals(StringUtils.join(ret.getRoles().toArray()), StringUtils.join(userAddDTO.getRoles().toArray())), "wrong_profiles");
        NAssert.state(Objects.equals(objectMapper.writeValueAsString(ret.getCustomData()), objectMapper.writeValueAsString(userAddDTO.getCustomData())), "wrong_custom_data");

        return ret;
    }


}
