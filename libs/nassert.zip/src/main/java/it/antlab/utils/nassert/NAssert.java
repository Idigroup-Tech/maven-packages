/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.utils.nassert;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by klayer3 on 25/05/25.
 */
public abstract class NAssert {

    @Deprecated//??
    public static <T extends Throwable> void state(boolean expression, Class<T> type) throws T {
       if(!expression){
           T throwable = null;
           try {
               throwable = type.getConstructor().newInstance();
           } catch ( Exception e) {
               throw NAssertException.builder(type.getSimpleName()).message(e.getMessage()).cause(e).build();
           }
           throw throwable;
       }
    }

    public static <T extends Throwable> void state(boolean expression, T throwable) throws T {
        if(!expression){
            NAssert.state( throwable != null, "null_throwable_arg", "Throwable argument is null");
            throw throwable;
        }
    }

    public static void state(boolean expression, String code) throws NAssertException {

        state(expression, code, null, null);

    }

    public static void state(boolean expression, String code, String message) throws NAssertException {

        state(expression, code, message, null);

    }

    public static void state(boolean expression, String code, String message, Throwable cause) throws NAssertException {

        internalState(StringUtils.isNotEmpty(StringUtils.trim(code)), "code_required", "Code required using NAssert", cause);
        internalState(expression, code, message, cause);

    }

    private static void internalState(boolean expression, String code, String message, Throwable cause){
        if(!expression){
            throw NAssertException.builder(code).message(message).cause(cause).build();
        }

    }

}
