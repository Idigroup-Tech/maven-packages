///*
// *
// *  * Copyright 2023–2025 Riccardo Mohamed
// *  * Email: riccardo.mohamed@gmail.com
// *  *
// *  * Licensed under the Apache License, Version 2.0 (the "License");
// *  * you may not use this file except in compliance with the License.
// *  * You may obtain a copy of the License at
// *  *
// *  *     http://www.apache.org/licenses/LICENSE-2.0
// *  *
// *  * Unless required by applicable law or agreed to in writing, software
// *  * distributed under the License is distributed on an "AS IS" BASIS,
// *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// *  * See the License for the specific language governing permissions and
// *  * limitations under the License.
// *
// */
//
//package io.nettuno.utils.concurrency;
//
//import com.google.common.util.concurrent.Striped;
//import com.google.common.util.concurrent.ThreadFactoryBuilder;
//import lombok.Synchronized;
//import org.apache.commons.lang3.ObjectUtils;
//
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.List;
//import java.util.concurrent.Executor;
//import java.util.concurrent.Executors;
//import java.util.concurrent.atomic.AtomicLong;
//import java.util.concurrent.locks.Lock;
//import java.util.function.Consumer;
//
///**
// * Created by klayer3 on 25/05/25.
// */
////spacchettare e pensare a servizio
//public class ConcurrencyUtils {
//
//    private static ConcurrencyUtils instance;
//
//    private Executor currentThreadExecutor = Runnable::run;
//
//    @Synchronized
//    public static ConcurrencyUtils instance(){
//        if(instance == null){
//            instance = new ConcurrencyUtils();
//        }
//        return instance;
//    }
//
//
//    public Executor getExecutor(Integer thread , String name){
//        if(ObjectUtils.firstNonNull(thread,0) > 0){
//            return Executors.newFixedThreadPool(thread, new ThreadFactoryBuilder().setNameFormat(name+"-%d").build());
//        }
//        return currentThreadExecutor;
//    }
//
//
//    public Executor getExecutor(Integer thread ){
//        if(ObjectUtils.firstNonNull(thread,0) > 0){
//            return Executors.newFixedThreadPool(thread);
//        }
//        return currentThreadExecutor;
//    }
//
//    // FIXME K3 passiamo il parametro per inizializzare... e magari gestiamo anche la tipologia di lock
//    private Striped<Lock> stripedLock = Striped.lock(500);
//
//    public Lock getLock(String name){
//        return stripedLock.get(name);
//    }
//
//    public Iterable<Lock> getLocks(Collection<String> names){
//        return stripedLock.bulkGet(names);
//    }
//
//    public <T> ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor){
//        return consume(items, consumer, taskExecutor, new ExecutionCount(), false);
//    }
//
//    public <T> ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor, boolean throwsError){
//        return consume(items, consumer, taskExecutor, new ExecutionCount(), throwsError);
//    }
//
//    public <T> ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor, ExecutionCount executionCount, boolean throwsError){
//        items.stream().forEach(item -> {
//            executionCount.register();
//            taskExecutor.execute(() -> {
//                try{
//                    if( !throwsError || executionCount.error() < 1L) {
//                        consumer.accept(item);
//                    }
//                } catch(Throwable e){
//
//                    executionCount.addError(item, e);
//
//                    if(throwsError ){
//                        //FIXME K3 dovremmo cancellare tutta la coda!!!!
//                        throw new RuntimeException(e);
//                    } else {
//                        e.printStackTrace();
//                    }
//
//
//                } finally {
//                    //FIXME STIAMO DANDO PER Scontato il successo delle transazioni dei vari thread
//                    executionCount.arrive();
//                }
//            });
//
//            if(throwsError && executionCount.getErrors() > 0){
//                throw new RuntimeException(executionCount.errorItems.get(0).cause);
//            }
//        });
//
//        return executionCount;
//    }
//
//    public static class ErrorItem {
//        private Object item;
//        private Throwable cause;
//
//        public ErrorItem(Object item, Throwable cause) {
//            this.item = item;
//            this.cause = cause;
//        }
//
//        public Object getItem() {
//            return item;
//        }
//
//        public void setItem(Object item) {
//            this.item = item;
//        }
//
//        public Throwable getCause() {
//            return cause;
//        }
//
//        public void setCause(Throwable cause) {
//            this.cause = cause;
//        }
//    }
//
//    public static class ExecutionCount {
//
//        private long intervall = 100;
//
//        private final AtomicLong tasks=new AtomicLong(0);
//
//        private final AtomicLong errors=new AtomicLong(0);
//
//        private final AtomicLong executed=new AtomicLong(0);
//
//        private final List<ErrorItem> errorItems = new ArrayList<ErrorItem>();
//
//
//        public ExecutionCount() {
//            super();
//        }
//
//        private ExecutionCount(long intervall) {
//            super();
//            this.intervall = intervall;
//        }
//
//        private Long register(){
//            return tasks.incrementAndGet();
//        }
//
//        private Long error(){
//            return errors.incrementAndGet();
//        }
//
//        private Long arrive(){
//            return executed.incrementAndGet();
//        }
//
//        public void await() throws InterruptedException{
//
//            //voglio controllare lo stato
//
//            while(!getTasks().equals(getExecuted())){
//                Thread.sleep(intervall);
//            }
//        }
//
//        private void addError(Object item, Throwable cause){
//            this.errorItems.add(new ErrorItem(item, cause));
//            this.error();
//        }
//
//        public Long getTasks(){
//            return tasks.get();
//        }
//
//        public Long getErrors(){
//            return errors.get();
//        }
//
//        public Long getExecuted(){
//            return executed.get();
//        }
//
//        public List<ErrorItem> getErrorItems(){
//            return new ArrayList<ErrorItem>(errorItems);
//        }
//
//        @Override
//        public String toString() {
//            return "ExecutionCount{" +
//                    "tasks=" + tasks +
//                    ", errors=" + errors +
//                    ", executed=" + executed +
//                    '}';
//        }
//    }
//}
