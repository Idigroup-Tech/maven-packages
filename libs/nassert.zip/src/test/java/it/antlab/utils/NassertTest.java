/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.utils;


import it.antlab.utils.nassert.NAssert;
import it.antlab.utils.nassert.NAssertException;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class NassertTest {

    @Test
    void testThrowsCodifiedException() {
        assertThrows(NAssertException.class, () -> NAssert.state(false, "fail_code"));
    }

    @Test
    void testNotException() {
        NAssert.state(true, "fail_code");
    }

    @Test
    void mustCatchException() {
        boolean successfulCatch = false;
        try {
            NAssert.state(false, IOException.class);
        } catch (IOException e) {
            successfulCatch = true;
        }
        assertTrue(successfulCatch, "Exception should have been caught");
    }

    @Test
    void testCustomException() {
        assertThrows(IllegalArgumentException.class,
                () -> NAssert.state(false, IllegalArgumentException.class));
    }

    @Test
    void testCodeNeeded() {
        String fake = null;
        assertThrows(NAssertException.class,
                () -> NAssert.state(false, fake));
    }

    @Test
    void testCodeMessage() {
        final String code = "test_code";
        final String message = "test message";
        final Throwable cause = null;

        NAssertException e = assertThrows(NAssertException.class,
                () -> NAssert.state(false, code, message));

        assertEquals(code, e.getCode(), "invalid_code");
        assertEquals(message, e.getMessage(), "invalid_message");
        assertNull(e.getCause(), "invalid_cause");
    }

    @Test
    void testCause() {
        final String code = "test_code";
        final String message = "test message";
        final Throwable cause = new NullPointerException();

        NAssertException e = assertThrows(NAssertException.class,
                () -> NAssert.state(false, code, message, cause));

        assertEquals(code, e.getCode(), "invalid_code");
        assertEquals(message, e.getMessage(), "invalid_message");
        assertEquals(cause, e.getCause(), "invalid_cause");
    }
}