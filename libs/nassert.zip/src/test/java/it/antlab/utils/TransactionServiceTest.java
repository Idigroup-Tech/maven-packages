///*
// *
// *  * Copyright 2023–2025 Riccardo Mohamed
// *  * Email: riccardo.mohamed@gmail.com
// *  *
// *  * Licensed under the Apache License, Version 2.0 (the "License");
// *  * you may not use this file except in compliance with the License.
// *  * You may obtain a copy of the License at
// *  *
// *  *     http://www.apache.org/licenses/LICENSE-2.0
// *  *
// *  * Unless required by applicable law or agreed to in writing, software
// *  * distributed under the License is distributed on an "AS IS" BASIS,
// *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// *  * See the License for the specific language governing permissions and
// *  * limitations under the License.
// *
// */
//
//package io.nettuno.utils;
//
//import io.nettuno.utils.exception.NAssert;
//import io.nettuno.utils.exception.model.CodifiedException;
//import io.nettuno.utils.transaction.TestModel;
//import io.nettuno.utils.transaction.TestModelRepository;
//import io.nettuno.utils.transaction.TransactionService;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.domain.EntityScan;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.test.context.ActiveProfiles;
//
///**
// * Created by klayer3 on 25/05/25.
// */
//@SpringBootTest
//@AutoConfigureMockMvc
//@ComponentScan(basePackages = { "io.nettuno.*",})
//@EntityScan(basePackages = { "io.nettuno.*"})
//@ActiveProfiles("test")
//public class TransactionServiceTest {
//
//    @Autowired
//    private TransactionService transactionService;
//
//    @Autowired
//    private TestModelRepository testModelRepository;
//
//    @Test
//    void testTransactionFail(){
//
//        TestModel test = new TestModel();
//        test.setDescription("test");
//
//        final TestModel result;
//        try{
//        transactionService.execute(() -> {
//            NAssert.state( null ==testModelRepository.save(test), "custom_exception");
//            return null;
//        });
//        }catch (CodifiedException e){
//
//        }
//
//        // la transazione precedente non è stata committata non devo recuperare l'entità
//        NAssert.state(test.getId() != null && testModelRepository.findById(test.getId()).isEmpty(), "must_be_empty");
//    }
//
//    @Test
//    void testTransaction(){
//
//        TestModel test = new TestModel();
//        test.setDescription("test");
//
//        final TestModel result;
//
//        transactionService.execute(() -> testModelRepository.save(test));
//
//        // la transazione precedente non è stata committata non devo recuperare l'entità
//        NAssert.state(test.getId() != null && testModelRepository.findById(test.getId()).isPresent(), "must_be_empty");
//    }
//}
