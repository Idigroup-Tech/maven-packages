///*
// *
// *  * Copyright 2023–2025 Riccardo Mohamed
// *  * Email: riccardo.mohamed@gmail.com
// *  *
// *  * Licensed under the Apache License, Version 2.0 (the "License");
// *  * you may not use this file except in compliance with the License.
// *  * You may obtain a copy of the License at
// *  *
// *  *     http://www.apache.org/licenses/LICENSE-2.0
// *  *
// *  * Unless required by applicable law or agreed to in writing, software
// *  * distributed under the License is distributed on an "AS IS" BASIS,
// *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// *  * See the License for the specific language governing permissions and
// *  * limitations under the License.
// *
// */
//
//package io.nettuno.utils;
//
//import io.nettuno.utils.concurrency.ConcurrencyUtils;
//import io.nettuno.utils.exception.NAssert;
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.autoconfigure.domain.EntityScan;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.test.context.ActiveProfiles;
//
//import java.time.LocalDateTime;
//import java.time.temporal.ChronoUnit;
//import java.time.temporal.TemporalUnit;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Objects;
//import java.util.concurrent.Executor;
//import java.util.concurrent.TimeUnit;
//import java.util.concurrent.locks.Lock;
//import java.util.function.Consumer;
//
///**
// * Created by klayer3 on 25/05/25.
// */
//@SpringBootTest
//@AutoConfigureMockMvc
//@ComponentScan(basePackages = { "io.nettuno.*",})
//@EntityScan(basePackages = { "io.nettuno.*"})
//@ActiveProfiles("test")
//public class ConcurrencyTest {
//
//    @Test
//    void testLockWithMultiThreadExecutor() throws InterruptedException {
//        Executor executor = ConcurrencyUtils.instance().getExecutor(5, "test");
//        List<String> items = Arrays.asList("item_1", "item_2");
//        Consumer<String> consumer = s -> {
//
//            Lock  lock = ConcurrencyUtils.instance().getLock("test_lock");
//            try{
//                NAssert.state(lock.tryLock(100, TimeUnit.MILLISECONDS), "lock_fail");
//                Thread.sleep(500);
//                lock.unlock();
//
//            }catch (InterruptedException interruptedException){}
//        };
//
//       ConcurrencyUtils.ExecutionCount count= ConcurrencyUtils.instance().consume(items, consumer, executor);
//
//       count.await();
//       NAssert.state(count.getErrors() > 0, "must_have_errors");
//        NAssert.state(Objects.equals(count.getErrorItems().get(0).getItem(), "item_2"), "must_be_item_2");
//        //NAssert.state(count.getErrorItems().get(0).);
//
//    }
//
//    @Test
//    void testLockWithSingleThreadxecutor() throws InterruptedException {
//        Executor executor = ConcurrencyUtils.instance().getExecutor(1, "test");
//        List<String> items = Arrays.asList("item_1", "item_2");
//        Consumer<String> consumer = s -> {
//
//            Lock  lock = ConcurrencyUtils.instance().getLock("test_lock");
//            try{
//                NAssert.state(lock.tryLock(100, TimeUnit.MILLISECONDS), "lock_fail");
//                Thread.sleep(500);
//                lock.unlock();
//
//            }catch (InterruptedException interruptedException){}
//        };
//
//        ConcurrencyUtils.ExecutionCount count= ConcurrencyUtils.instance().consume(items, consumer, executor);
//
//        count.await();
//        NAssert.state(count.getErrors() == 0, "must_have_errors");
//
//    }
//
//    @Test
//    void testLockWaitingWithMultiThreadExecutor() throws InterruptedException {
//        Executor executor = ConcurrencyUtils.instance().getExecutor(5, "test");
//        List<String> items = Arrays.asList("item_1", "item_2");
//
//        LocalDateTime startTime = LocalDateTime.now();
//        long millisDif = 600;
//        Consumer<String> consumer = s -> {
//
//            Lock  lock = ConcurrencyUtils.instance().getLock("test_lock");
//
//            try {
//                lock.lock();
//                Thread.sleep(millisDif);
//
//            } catch (InterruptedException interruptedException) {
//                interruptedException.printStackTrace();
//            } finally {
//                lock.unlock();
//            }
//
//
//        };
//
//        ConcurrencyUtils.ExecutionCount count= ConcurrencyUtils.instance().consume(items, consumer, executor);
//
//        count.await();
//        NAssert.state(count.getErrors() == 0, "must_have_errors");
//        NAssert.state(LocalDateTime.now().isAfter(startTime.plus(millisDif * items.size(), ChronoUnit.MILLIS)), "must_wait_execution");
//
//    }
//
//    @Test
//    void testLockNotWaitingWithMultiThreadExecutor() throws InterruptedException {
//        Executor executor = ConcurrencyUtils.instance().getExecutor(5, "test");
//        List<String> items = Arrays.asList("item_1", "item_2");
//
//        LocalDateTime startTime = LocalDateTime.now();
//        long millisDif = 2000;
//        Consumer<String> consumer = s -> {
//
//            Lock  lock = ConcurrencyUtils.instance().getLock(s);
//
//            try {
//                lock.lock();
//                Thread.sleep(millisDif);
//
//            } catch (InterruptedException interruptedException) {
//                interruptedException.printStackTrace();
//            } finally {
//                lock.unlock();
//            }
//
//
//        };
//
//        ConcurrencyUtils.ExecutionCount count= ConcurrencyUtils.instance().consume(items, consumer, executor);
//
//        count.await();
//        NAssert.state(count.getErrors() == 0, "must_have_errors");
//        NAssert.state(LocalDateTime.now().isBefore(startTime.plus(millisDif * items.size(), ChronoUnit.MILLIS)), "must_wait_execution");
//
//    }
//}
