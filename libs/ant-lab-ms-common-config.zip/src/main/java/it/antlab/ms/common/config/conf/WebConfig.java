//package it.antlab.ms.conf;
//
//
//import it.antlab.ms.conf.properties.CorsProperties;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.CorsRegistration;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//import java.util.Optional;
//
///**
// * Created by klayer3 on 13/06/25
// */
//@Configuration
//@ConditionalOnExpression("${application.cors.enabled: true}")
//@Slf4j
//public class WebConfig implements WebMvcConfigurer {
//
//    @Autowired
//    private CorsProperties corsProperties;
//
//    public WebConfig() {
//    }
//
//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//        CorsRegistration config = registry.addMapping("/**");
//        config.allowedOrigins(this.corsProperties.getAllowOrigins());
//        config.allowedOriginPatterns(this.corsProperties.getAllowOriginPatterns());
//        config.allowCredentials(this.corsProperties.isAllowCredentials());
//        config.allowedMethods(this.corsProperties.getAllowMethods());
//        config.exposedHeaders(this.corsProperties.getExposedHeaders());
//        config.allowedHeaders(this.corsProperties.getAllowHeaders());
//        Optional.ofNullable(this.corsProperties.getMaxAge()).filter(l -> l> 0).ifPresent(this.corsProperties::setMaxAge);
//
//        log.info("==>> getAllowOrigins: " + String.join(", ", this.corsProperties.getAllowOrigins()));
//        log.info("==>> getAllowOriginPatterns: " + String.join(", ", this.corsProperties.getAllowOriginPatterns()));
//        log.info("==>> isAllowCredentials: " + this.corsProperties.isAllowCredentials());
//        log.info("==>> getAllowMethods: " + String.join(", ", this.corsProperties.getAllowMethods()));
//        log.info("==>> getExposedHeaders: " + String.join(", ", this.corsProperties.getExposedHeaders()));
//        log.info("==>> getAllowHeaders: " + String.join(", ", this.corsProperties.getAllowHeaders()));
//        log.info("==>> getMaxAge: " + this.corsProperties.getMaxAge());
//    }
//}
