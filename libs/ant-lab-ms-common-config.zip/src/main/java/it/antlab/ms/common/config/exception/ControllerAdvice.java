/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.ms.common.config.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import it.antlab.utils.nassert.NAssertException;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ValidationException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 13/06/25.
 */

@org.springframework.web.bind.annotation.ControllerAdvice
@Order
public class ControllerAdvice extends ResponseEntityExceptionHandler {
    private final Logger log = LoggerFactory.getLogger(ControllerAdvice.class);

    @Autowired
    private ObjectMapper objectMapper;

    private void log(Throwable throwable, boolean simple) {
        if (simple) {
            log.error("Handling {}", throwable.getClass().getSimpleName());
            log.error("Exception message: {} ", StringUtils.defaultIfBlank(throwable.getMessage(), throwable.toString()));
        } else {
            this.log.error("Handling {}", throwable.getClass().getSimpleName());
            this.log.error("Exception message: {} ", throwable.getMessage(), throwable);
        }
    }

    @ExceptionHandler({DataAccessException.class, PersistenceException.class})
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleBadRequestException(Exception e, final HttpServletRequest request) {
        final Throwable routeException = ExceptionUtils.getRootCause(e);
        Throwable cause = e.getCause();
        if (cause != null && org.hibernate.exception.ConstraintViolationException.class.isAssignableFrom(cause.getClass())) {
            return handleConstraintViolationException((org.hibernate.exception.ConstraintViolationException) cause, request);
        }
        HttpStatus httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
        log(e, false);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(routeException.getMessage())
                .code(e.getClass().getSimpleName())
                .status(httpStatus.value())
                .path(request.getServletPath()).build();
        return ResponseEntity.status(httpStatus).body(errorResponse);
    }


    @ExceptionHandler(NAssertException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    @Deprecated
    public ResponseEntity<ErrorResponse> handleBadRequestException(NAssertException e, final HttpServletRequest request) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        log(e, true);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(e.getMessage())
                .code(e.getCode())
                .status(httpStatus.value())
                .path(request.getServletPath()).build();
        return ResponseEntity.status(httpStatus).body(errorResponse);
    }

    @ExceptionHandler({ResponseStatusException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleResponseStatusException(ResponseStatusException e, final HttpServletRequest request) {
        log(e, true);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(e.getReason())
                .code(Objects.toString(e.getRawStatusCode()))
                .status(e.getRawStatusCode())
                .path(request.getServletPath()).build();
        return ResponseEntity.status(e.getStatus()).body(errorResponse);
    }

    @ExceptionHandler({Throwable.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleBadRequestException(Throwable e, final HttpServletRequest request) {
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        log(e, false);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(e.getMessage())
                .code(e.getClass().getSimpleName())
                .status(httpStatus.value())
                .path(request.getServletPath()).build();
        return ResponseEntity.status(httpStatus).body(errorResponse);
    }

    @ExceptionHandler(FeignException.class)
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleFeignStatusException(FeignException e, final HttpServletRequest request) {
        final Throwable routeException = ExceptionUtils.getRootCause(e);
        HttpStatus httpStatus = HttpStatus.resolve(e.status()) != null ? HttpStatus.resolve(e.status()) : HttpStatus.SERVICE_UNAVAILABLE;
        log(e, true);
        ErrorResponse errorResponse = null;
        try {
            // read iam errorResponse
            errorResponse = objectMapper.readValue(e.responseBody().get().array(), ErrorResponse.class);

        } catch (Exception exx) {
            errorResponse = ErrorResponse.builder()
                    .message(routeException.getMessage())
                    .code(e.getClass().getSimpleName())
                    .status(httpStatus.value())
                    .path(request.getServletPath()).build();

        }
        return ResponseEntity.status(httpStatus).body(errorResponse);
    }

    //FIXME K3 da vedere in seguito
    @ExceptionHandler({AuthenticationException.class, AuthenticationServiceException.class})
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ResponseEntity<?> handleAuthenticationException(Exception e, final HttpServletRequest request) {
        log(e, true);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(e.getMessage())
                .code(e.getClass().getSimpleName())
                .status(HttpStatus.UNAUTHORIZED.value())
                .path(request.getServletPath()).build();
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        //ex.getBindingResult().
        log(ex, true);
        status = ObjectUtils.firstNonNull(status, HttpStatus.BAD_REQUEST);

        String message = ex.getMessage();
        String code = ex.getClass().getSimpleName();

        List<ErrorResponse.ErrorDetail> detailList = null;
        if (ex.getBindingResult() != null) {

            code = ex.getObjectName() + "/validation";
            if (!CollectionUtils.isEmpty(ex.getBindingResult().getFieldErrors())) {
                detailList = ex.getBindingResult().getFieldErrors().stream().map(fieldError -> {
                    ErrorResponse.ErrorDetail errorDetail = new ErrorResponse.ErrorDetail();
                    errorDetail.setCode(fieldError.getCode());
                    errorDetail.setMessage(fieldError.getDefaultMessage());
                    errorDetail.setField(fieldError.getField());
                    return errorDetail;
                }).collect(Collectors.toList());
            } else {
                detailList = ex.getBindingResult().getAllErrors().stream().map(fieldError -> {
                    ErrorResponse.ErrorDetail errorDetail = new ErrorResponse.ErrorDetail();
                    errorDetail.setCode(fieldError.getCode());
                    errorDetail.setMessage(fieldError.getDefaultMessage());
                    return errorDetail;
                }).collect(Collectors.toList());
            }

        }
        boolean hasDetails = !CollectionUtils.isEmpty(detailList);

        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(hasDetails ? detailList.get(0).toString() : message)
                .code(hasDetails ? "validation/details" : code)
                .details(detailList)
                .status(status.value())
                .path(request.getContextPath()).build();
        return ResponseEntity.status(status).body(errorResponse);
    }

    @ExceptionHandler({org.hibernate.exception.ConstraintViolationException.class})
    @ResponseBody
    public ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException e, final HttpServletRequest request) {
        log(e, true);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(e.getConstraintName())
                .code("constraint/violation")
                .status(HttpStatus.UNPROCESSABLE_ENTITY.value())
                .path(request.getServletPath()).build();
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(errorResponse);
    }

    @ExceptionHandler({ValidationException.class})
    @ResponseBody
    public ResponseEntity<?> handleValidationException(ValidationException e, final HttpServletRequest request) {
        Throwable cause = e.getCause();
        if (cause != null ) {
            if( NAssertException.class.isAssignableFrom(cause.getClass()) ) {
                return handleBadRequestException((NAssertException) cause, request);
            }
        }
        log(e, true);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(e.getMessage())
                .code(e.getClass().getSimpleName())
                .status(HttpStatus.BAD_REQUEST.value())
                .path(request.getServletPath()).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        final Throwable routeException = ExceptionUtils.getRootCause(ex);
        HttpStatus httpStatus = status;
        log(ex, false);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .message(routeException.getMessage())
                .code(ex.getClass().getSimpleName())
                .status(httpStatus.value())
                .path(request.getContextPath()).build();
        return ResponseEntity.status(httpStatus).body(errorResponse);
    }
}