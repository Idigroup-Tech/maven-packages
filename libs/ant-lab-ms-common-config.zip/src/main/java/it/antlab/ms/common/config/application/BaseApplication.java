/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.ms.common.config.application;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.info.BuildProperties;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;

/**
 * Created by klayer3 on 13/06/25
 */
@Slf4j
@RequiredArgsConstructor
public abstract class BaseApplication {
    protected final Environment environment;

    private final BuildProperties buildProperties;

    @PostConstruct()
    public void postConstruct() {
        log.info("starting {}, version {}", buildProperties.getArtifact(), buildProperties.getVersion());
        log.info("active profiles: {}", environment.getActiveProfiles());
    }

}
