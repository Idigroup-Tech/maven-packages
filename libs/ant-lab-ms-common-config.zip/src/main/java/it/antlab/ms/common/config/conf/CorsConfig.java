/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.ms.common.config.conf;



import it.antlab.ms.common.config.conf.properties.CorsProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.List;
import java.util.Optional;

/**
 * Created by klayer3 on 13/06/25
 */
@Configuration
@Slf4j
@RequiredArgsConstructor
@ConditionalOnExpression("${application.cors.enabled: true}")
public class CorsConfig {

    private final CorsProperties corsProperties;

//    @Bean
//    @Order(Ordered.HIGHEST_PRECEDENCE)
//    public CorsWebFilter corsWebFilter() {
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", corsConfiguration());
//        return new CorsWebFilter(source);
//    }

    @Bean
    public FilterRegistrationBean<CorsFilter> corsFilter() {
        CorsConfiguration config = corsConfiguration();
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);

        FilterRegistrationBean<CorsFilter> bean = new FilterRegistrationBean<>(new CorsFilter(source));
        bean.setOrder(Ordered.HIGHEST_PRECEDENCE); // 🔥 viene eseguito PRIMA dei filtri security
        return bean;
    }

//    @Bean
    public CorsConfiguration corsConfiguration() {
        log.info("==>> getAllowOrigins: " + String.join(", ", this.corsProperties.getAllowOrigins()));
        log.info("==>> getAllowOriginPatterns: " + String.join(", ", this.corsProperties.getAllowOriginPatterns()));
        log.info("==>> isAllowCredentials: " + this.corsProperties.isAllowCredentials());
        log.info("==>> getAllowMethods: " + String.join(", ", this.corsProperties.getAllowMethods()));
        log.info("==>> getExposedHeaders: " + String.join(", ", this.corsProperties.getExposedHeaders()));
        log.info("==>> getAllowHeaders: " + String.join(", ", this.corsProperties.getAllowHeaders()));
        log.info("==>> getMaxAge: " + this.corsProperties.getMaxAge());

        CorsConfiguration corsConfig = new CorsConfiguration();
        Optional.ofNullable(corsProperties.getAllowOrigins()).map(StringUtils::trim).filter(StringUtils::isNotBlank)
                .ifPresent( allow -> corsConfig.setAllowedOrigins(List.of(StringUtils.split(allow, ","))));
        Optional.ofNullable(corsProperties.getAllowMethods()).map(StringUtils::trim).filter(StringUtils::isNotBlank)
                .ifPresent( allow -> List.of(StringUtils.split(allow, ",")).forEach(corsConfig::addAllowedMethod));
        Optional.ofNullable(corsProperties.getAllowHeaders()).map(StringUtils::trim).filter(StringUtils::isNotBlank)
                .ifPresent( allow -> corsConfig.setAllowedHeaders(List.of(StringUtils.split(allow, ","))));
        Optional.ofNullable(corsProperties.getExposedHeaders()).map(StringUtils::trim).filter(StringUtils::isNotBlank)
                .ifPresent( allow -> corsConfig.setExposedHeaders(List.of(StringUtils.split(allow, ","))));
        Optional.ofNullable(corsProperties.getAllowOriginPatterns()).map(StringUtils::trim).filter(StringUtils::isNotBlank)
                .ifPresent( allow -> corsConfig.setAllowedOriginPatterns(List.of(StringUtils.split(allow, ","))));
        Optional.ofNullable(corsProperties.getMaxAge()).filter( l -> l > 0).ifPresent(corsConfig::setMaxAge);

        corsConfig.setAllowCredentials(corsProperties.isAllowCredentials());
        return corsConfig;
    }
}