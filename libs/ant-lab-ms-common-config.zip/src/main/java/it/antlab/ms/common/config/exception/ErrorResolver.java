/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.ms.common.config.exception;

import it.antlab.utils.nassert.NAssertException;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * Created by klayer3 on 13/06/25
 */
public class ErrorResolver {

    private  static final Map<String, NAssertException> errorMap = Map.of(
            "uidx_sample", NAssertException.builder("sample/duplicated-number").message("numero di esempio duplicato").build()
    );

    public static NAssertException resolve(String ref, Exception e) {
        if(StringUtils.isNotBlank(ref) && errorMap.containsKey(ref)){
            return errorMap.get(ref);
        } if (e instanceof NAssertException) {
            return (NAssertException) e;
        }

        return NAssertException.builder(e.getClass().getSimpleName()).message(e.getMessage()).build();
    }
}
