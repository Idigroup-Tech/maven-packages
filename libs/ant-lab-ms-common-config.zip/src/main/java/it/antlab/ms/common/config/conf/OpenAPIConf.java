/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.ms.common.config.conf;



import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import it.antlab.ms.common.config.conf.properties.OpenApiProperties;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Created by klayer3 on 13/06/25
 */
@Configuration
@RequiredArgsConstructor
public class OpenAPIConf {

    private final OpenApiProperties openApiProperties;
    private final BuildProperties buildProperties;
    
    @Bean
    public OpenAPI openAPI() {
        final String jwtAuthToken = "jwt-token-auth";
        return new OpenAPI()
              .info(new Info()
                        .title(StringUtils.defaultIfBlank(openApiProperties.getTitle(), buildProperties.getName()))
                        .description(StringUtils.defaultIfBlank(openApiProperties.getDescription(), buildProperties.getGroup() +"."+buildProperties.getArtifact()))
                        .version(ObjectUtils.firstNonNull(openApiProperties.getVersion(),buildProperties.getVersion(), "latest")))
                .components(
                        new Components()
                                .addSecuritySchemes(jwtAuthToken,
                                        new SecurityScheme()
                                                .type(SecurityScheme.Type.HTTP)
                                                .scheme("bearer")
                                                .bearerFormat("JWT")
                                )
                )
                .security(List.of(new SecurityRequirement().addList(jwtAuthToken)))
                .servers(openApiProperties.getServers());

    }
}
