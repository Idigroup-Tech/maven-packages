//package k3.base.ms.conf;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import feign.codec.Decoder;
//import feign.codec.Encoder;
//import feign.jackson.JacksonDecoder;
//import feign.jackson.JacksonEncoder;
//
///**
// * Created by klayer3 on 13/06/25
// */
////@Configuration
//public class BaseFeignConf {
//    //@Bean
//    Decoder jacksonFeignDecoder(ObjectMapper objectMapper){
//        //return new ResponseEntityDecoder(new JacksonDecoder(objectMapper));
//        return new JacksonDecoder(objectMapper);
//    }
//
//    //@Bean
//    Encoder jacksonFeignEcoder(ObjectMapper objectMapper){
//        return new JacksonEncoder(objectMapper);
//    }
//}
