# simple Queue

gestione code eventi