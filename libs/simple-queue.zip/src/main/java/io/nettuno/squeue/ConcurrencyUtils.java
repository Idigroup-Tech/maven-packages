/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.squeue;

import com.google.common.util.concurrent.Striped;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.apache.commons.lang3.ObjectUtils;

import java.util.Collection;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;
import java.util.function.Consumer;

//FIXME K3 questo deve andare in un jar apposito
public class ConcurrencyUtils {

    private static ConcurrencyUtils instance;

    private Executor currentThreadExecutor = Runnable::run;

    public synchronized static ConcurrencyUtils instance(){
        if(instance == null){
            instance = new ConcurrencyUtils();
        }
        return instance;
    }


    public Executor getExecutor(Integer thread , String name){
        if(ObjectUtils.firstNonNull(thread,0) > 0){
            return Executors.newFixedThreadPool(thread, new ThreadFactoryBuilder().setNameFormat(name+"-%d").build());
        }
        return currentThreadExecutor;
    }


    public Executor getExecutor(Integer thread ){
        if(ObjectUtils.firstNonNull(thread,0) > 0){
            return Executors.newFixedThreadPool(thread);
        }
        return currentThreadExecutor;
    }

    private Striped<Lock> stripedLock = Striped.lock(10000);

    public Lock getLock(String name){
        return stripedLock.get(name);
    }

    public Iterable<Lock> getLocks(Collection<String> names){
        return stripedLock.bulkGet(names);
    }

    // singleton
    private ConcurrencyUtils() {}

    public <T> T tryLock(Collection<String> keys,  Callable<T> callable, Striped<Lock> stripedLock){
        return tryLock( keys, callable,  5000L,  stripedLock);
    }

    public <T> T tryLock(Collection<String> keys,  Callable<T> callable){
        return tryLock( keys, callable,  5000L,  stripedLock);
    }

    public <T> T tryLock(Collection<String> keys, Callable<T> callable, Long millis){
        return tryLock( keys, callable,  millis,  stripedLock);
    }

    public <T> T tryLock(Collection<String> keys,  Callable<T> callable, Long millis, Striped<Lock> stripedLock){
        Iterable<Lock> locks = stripedLock.bulkGet(keys);
        try{

            for(Lock lock : locks){
                lock.tryLock(millis, TimeUnit.MILLISECONDS);
            }

            return callable.call();
        }catch(Throwable t){
            throw new RuntimeException(t);
        } finally {

            locks.forEach(l -> {
                try{
                    l.unlock();
                }catch(Throwable t){

                }
            });
        }
    }

    public <T> CountDownLatch consume2(Collection<T> items, Consumer<T> consumer, Executor taskExecutor){

        CountDownLatch latch = new CountDownLatch(items.size());

        items.stream().forEach(item -> {
            taskExecutor.execute(new Runnable() {
                public void run() {
                    try{
                        consumer.accept(item);
                    }finally {
                        //STIAMO DANDO PER Scontato il successo delle transazioni dei vari thread
                        latch.countDown();
                    }
                }
            });
        });

        try {
            latch.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return latch;
    }

    public <T> ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor, boolean throwsError){
        return consume(items, consumer, taskExecutor, new ExecutionCount(), throwsError);
    }

    public <T> ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor){
        return consume(items, consumer, taskExecutor, new ExecutionCount(), false);
    }

    public <T> ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor, ExecutionCount executionCount, boolean throwsError){
        items.stream().forEach(item -> {
            executionCount.register();
            taskExecutor.execute(() -> {
                try{
                    consumer.accept(item);
                } catch(Throwable e){

                    if(throwsError ){
                        //FIXME K3 dovremmo cancellare tutta la coda!!!!
                        throw new RuntimeException(e);
                    } else {
                        e.printStackTrace();
                    }
                    executionCount.error();
                } finally {
                    //FIXME STIAMO DANDO PER Scontato il successo delle transazioni dei vari thread
                    executionCount.arrive();
                }
            });
        });

        return executionCount;
    }

    public <T> ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor, ExecutionCount executionCount){

        return consume(items, consumer, taskExecutor, executionCount, false);
    }

    public <T> T call(Callable<T> callable, String name){
        return call(callable, 5, 500, name);
    }

    public <T> T call(Callable<T> callable , final int times, final int sleepTimes, String name ){
        int cur_times = 0;
        while(true){
            try{
                return callable.call();
            }catch(Exception ex){
                if(++cur_times >= times)
                    throw new RuntimeException(callable.toString());
                try {
                    //System.out.println("ConcurrencyUtils.call "+name+" times"+cur_times);
                    Thread.sleep(sleepTimes);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static class ExecutionCount {

        private long intervall = 100;

        private final AtomicLong tasks=new AtomicLong(0);

        private final AtomicLong errors=new AtomicLong(0);

        private final AtomicLong executed=new AtomicLong(0);


        public ExecutionCount() {
            super();
        }

        private ExecutionCount(long intervall) {
            super();
            this.intervall = intervall;
        }

        private Long register(){
            return tasks.incrementAndGet();
        }

        private Long error(){
            return errors.incrementAndGet();
        }

        private Long arrive(){
            return executed.incrementAndGet();
        }

        public void await() throws InterruptedException{

            //voglio controllare lo stato

            while(!getTasks().equals(getExecuted())){
                Thread.sleep(intervall);
            }
        }

        public Long getTasks(){
            return tasks.get();
        }

        public Long getErrors(){
            return errors.get();
        }

        public Long getExecuted(){
            return executed.get();
        }

        @Override
        public String toString() {
            return "ExecutionCount{" +
                    "tasks=" + tasks +
                    ", errors=" + errors +
                    ", executed=" + executed +
                    '}';
        }
    }


}


