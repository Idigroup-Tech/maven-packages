/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.squeue.service.impl;

import io.nettuno.squeue.ConcurrencyUtils;
import io.nettuno.squeue.exception.SimpleQEventException;
import io.nettuno.squeue.model.Event;
import io.nettuno.squeue.model.EventStatus;
import io.nettuno.squeue.service.EventGroupProcessor;
import io.nettuno.squeue.service.EventHandler;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Slice;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.concurrent.Semaphore;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 14/08/20.
 */
public abstract class AbstractEventGroupProcessor<T extends Event> implements EventGroupProcessor {

    private final static Logger defaultlog = LoggerFactory.getLogger(EventGroupProcessor.class);

    private Logger log = defaultlog;
    private long queueLimit = 100L;
    private int sleepOnLimit = 500;
    private int pageSize = 50;

    private Executor taskExecutor = ConcurrencyUtils.instance().getExecutor(getExecutorSize(), getExecutorName());
    private int group;
    private boolean enabled = true;
    private boolean running = true;
    private final Semaphore semaphore = new Semaphore(1);
    private ConcurrencyUtils.ExecutionCount executionCount;

    @Autowired
    private ApplicationContext applicationContext;

    protected abstract CrudRepository<T, Serializable> getRepository();

    Consumer<T> consumer = event ->
    {
        try {
            handleEvent(event);
            eventDone(event);
        } catch ( SimpleQEventException simpleQEventException){
            if( Optional.ofNullable(simpleQEventException.getEventStatus()).map(EventStatus::isObsolesce).orElse(false)){
                log.warn("{} event.id {} event.type {} message {} ", simpleQEventException.getEventStatus(), event.getId(), event.getType(), simpleQEventException.getMessage());
                if( simpleQEventException.getCause() != null){
                    log.warn("{} event {} cause {}", simpleQEventException.getEventStatus(), event, ExceptionUtils.getStackTrace(simpleQEventException.getCause()));
                }
            } else {
                log.error("{} event.id {} event.type {} message {} ", simpleQEventException.getEventStatus(), event.getId(), event.getType(), simpleQEventException.getMessage());
                if( simpleQEventException.getCause() != null) {
                    log.error("{} event {} cause {}", simpleQEventException.getEventStatus(), event, ExceptionUtils.getStackTrace(simpleQEventException.getCause()));
                }
            }
            processError(event, simpleQEventException);
        } catch (Exception e) {

            //FIXME GESTIRE CODIFIED EXCEPTION...
            log.error("error {} handle event {} caused by {} ", e.getMessage(), event, ExceptionUtils.getStackTrace(e));
            processError(event, e);
        }
    };

    private void processError(T event, Exception e) {
        if (e.getClass().isAssignableFrom(SimpleQEventException.class)) {
            SimpleQEventException simpleQEventException = (SimpleQEventException) e;
            setStatus(simpleQEventException.getEventStatus(), simpleQEventException.getWaitUntil(), event);
        } else {
            onError(event, e);
        }
    }

    protected abstract void onError(T event, Exception e);

    private void eventDone(T event) {
        event.setObsolete(true);
        setStatus(EventStatus.DONE, null, event);
    }

    protected abstract void onStatusChange(T event, EventStatus status);

    @Deprecated // se utilizzaimo type string
    protected abstract String getTypeName(T event);

    protected abstract int removeDuplicates(Collection<T> events);

    protected abstract Slice<T> getNextPage(T lastEvent);

    protected T save(T e) {
        return this.getRepository().save(e);
    }

    protected boolean canProcess(T inputEvent) {

        // alcuni controlli li facciamo prima del refresh e dopo
        if( inputEvent == null || inputEvent.isObsolete() || inputEvent.getStatus().isObsolesce()) {
            return false;
        }

        if(Objects.equals(EventStatus.PAUSE, inputEvent.getStatus()) && inputEvent.getWaitUntil() == null){
            return false;
        }
        // non è ancora il momento
        if( inputEvent.getWaitUntil() != null && inputEvent.getWaitUntil().isAfter(LocalDateTime.now())){
            return false;
        }



        T event = getRepository().findById(inputEvent.getId()).orElse(null);
        // evento nullo, è cambiata la versione, obsoleto o in stato obsoleto
        if( event == null || !Objects.equals(inputEvent.getVersion(), event.getVersion()) || event.isObsolete() || event.getStatus().isObsolesce()) {
            return false;
        }

        if( EventStatus.RUNNING.equals(event.getStatus())){
            if(!canProcessRunningEvent(event)){
                return false;
            }
        }

        // se è in pausa e non ha una data di fine pausa
        if(Objects.equals(EventStatus.PAUSE, event.getStatus()) && event.getWaitUntil() == null){
            return false;
        }

        if( event.getWaitUntil() != null && event.getWaitUntil().isAfter(LocalDateTime.now())){
            return false;
        }

        return true;
    }

    protected boolean canProcessRunningEvent(T event) {
        return true;
    }

    private void handleEvent(T event) throws Exception {
        //https://stackoverflow.com/questions/40286047/spring-get-all-beans-of-certain-interface-and-type
        String typeName = getTypeName(event);
        EventHandler handler = applicationContext.getBean(typeName + EventHandler.HANDLER_NAME_PATTERN, EventHandler.class);
        log.info("start handle event.id {} by {} ", event.getId(), handler.getClass().getSimpleName());
        setStatus(EventStatus.RUNNING, null, event);
        handler.handle(event);
        log.info("end handle event.id {} by {} ", event.getId(), handler.getClass().getSimpleName());
    }

    protected void setStatus(EventStatus status, LocalDateTime waitUntil, T event) {
        event.setStatus(status);
        event.setObsolete(status.isObsolesce());
        if (waitUntil != null) {
            event.setWaitUntil(waitUntil);
        }
        BeanUtils.copyProperties(save(event), event);
        onStatusChange(event, status);
    }


    public AbstractEventGroupProcessor(int group) {
        this.group = group;
    }

    @Override
    public ConcurrencyUtils.ExecutionCount process() {
        if (!enabled) return null;
        if (semaphore.tryAcquire()) {
            running = true;
            try {
                processEvents();
                return null;
            } catch (Exception t) {
                log.info("error on processEvents {}", ExceptionUtils.getStackTrace(t));
            } finally {
                running = false;
                semaphore.release();
            }
        }
        return null;
    }

    private void processEvents() {

        T lastEvent = null;
        Long lastEventId = Long.MIN_VALUE;
        ConcurrencyUtils.ExecutionCount executionCount = null;

        Slice<T> events = null;
        do {

            events = getNextPage(lastEvent);

            if (!events.isEmpty()) {

                List<T> processableEvents = events.getContent();

                lastEvent = processableEvents.get(processableEvents.size() - 1);

                //FIXME K3 questo potrebbe essere un metodo private per processPage
                log.info("call removeDuplicatedEvents for group {}", group);
                int duplicated = removeDuplicates(processableEvents);
                log.info("removed {} duplicated for group {}", duplicated, group);

               processableEvents = processableEvents.stream().filter(this::canProcess).collect(Collectors.toList());

                if (executionCount == null)
                    executionCount = ConcurrencyUtils.instance().consume(processableEvents, consumer, taskExecutor);
                else
                    executionCount = ConcurrencyUtils.instance().consume(processableEvents, consumer, taskExecutor, executionCount);

                while ((executionCount.getTasks() - executionCount.getExecuted()) >= queueLimit) {
                    try {
                        log.info(" queue size {}, thread sleep {} millis for group {} ", executionCount.getTasks() - executionCount.getExecuted(), sleepOnLimit, group);
                        Thread.sleep(sleepOnLimit);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        } while (events.hasNext());


        //atttendiamo la pagina
        try {
            if (executionCount != null)
                executionCount.await();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        log.info("processEvents ends for group {}, with executionCount {}", getGroup(), executionCount);
    }


    public int getPageSize() {
        return pageSize;
    }

    public int getGroup() {
        return group;
    }

    public int getExecutorSize() {
        return 0;
    }

    public String getExecutorName() {
        return "EventGroup_" + this.group + "_Executor";
    }

    public void setLog(Logger log) {
        this.log = ObjectUtils.firstNonNull(log, defaultlog);
    }

    public Logger getLog() {
        return this.log;
    }
}
