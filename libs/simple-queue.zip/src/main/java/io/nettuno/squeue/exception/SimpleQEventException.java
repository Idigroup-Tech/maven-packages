/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.squeue.exception;

import io.nettuno.squeue.model.EventStatus;

import java.time.LocalDateTime;

/**
 * Created by fsolli on 24/06/2021.
 */
public class SimpleQEventException extends RuntimeException {

    private EventStatus eventStatus;
    private Long delay; //Delay in SECONDI
    private LocalDateTime waitUntil;

    public SimpleQEventException(EventStatus eventStatus, String message) {
        super(message);
        this.eventStatus = eventStatus;
    }

    public SimpleQEventException(EventStatus eventStatus, String message, Throwable cause) {
        super(message, cause);
        this.eventStatus = eventStatus;
    }

    public SimpleQEventException(EventStatus eventStatus, Long delay, String message, Throwable cause) {
        super(message, cause);
        this.eventStatus = eventStatus;
        this.delay = delay;
    }

    public SimpleQEventException(EventStatus eventStatus, LocalDateTime waitUntil, String message, Throwable cause) {
        super(message, cause);
        this.eventStatus = eventStatus;
        this.waitUntil = waitUntil;
    }

    public EventStatus getEventStatus() {
        return eventStatus;
    }

    public void setEventStatus(EventStatus eventStatus) {
        this.eventStatus = eventStatus;
    }

    public Long getDelay() {
        return delay;
    }

    public void setDelay(Long delay) {
        this.delay = delay;
    }

    public LocalDateTime getWaitUntil() {
        if (this.waitUntil == null && this.getDelay() != null) {
            return LocalDateTime.now().plusSeconds(this.getDelay());
        }
        return waitUntil;
    }

    public void setWaitUntil(LocalDateTime waitUntil) {
        this.waitUntil = waitUntil;
    }

    @Override
    public String toString() {
        return "SimpleQEventException{" +
                "eventStatus=" + eventStatus +
                ", delay=" + delay +
                ", waitUntil=" + waitUntil +
                '}';
    }
}
