/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.squeue.service.impl;

import io.nettuno.squeue.model.Event;
import io.nettuno.squeue.service.EventService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.repository.CrudRepository;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Created by klayer3 on 24/08/20.
 */
public abstract class AbstractEventService<T extends Event> implements EventService {

    protected T save(T e){
        return this.getRepository().save(e);
    }

    @Override
    public final void add(String type, int group, Object body, Object attributes, LocalDateTime waitUntil) {
        T event =  getInstance(type, group, body, attributes);
        event.setWaitUntil(waitUntil);
        setHash(event);
        save(event);

    }

    protected abstract T getInstance(String type, int group, Object body, Object attributes);
    @Override
    public T load(Serializable id) {
        return getRepository().findById(id).orElse(null);
    }

    protected abstract CrudRepository<T, Serializable> getRepository();


    protected final void setHash(Event e){
        e.setHash(
                DigestUtils.sha1Hex(
                        StringUtils.join(
                                "type-",
                                StringUtils.trim(e.getType()),
                                "body-",
                                ObjectUtils.firstNonNull(StringUtils.trim(Objects.toString(e.getBody())), "null")
                        )
                )
        );
    }
}
