/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.utils;


import it.antlab.utils.concurrency.ExecutorUtils;
import it.antlab.utils.concurrency.LockUtils;
import it.antlab.utils.nassert.NAssert;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/**
 * Created by klayer3 on 18/06/25.
 */
public class ConcurrencyUtilsTest {

    @Test
    void testLockWithMultiThreadExecutor() throws InterruptedException {
        Executor executor = ExecutorUtils.getInstance().getExecutor(5, "test");
        List<String> items = Arrays.asList("item_1", "item_2");
        Consumer<String> consumer = s -> {

            LockUtils.getInstance().tryLock( () -> {
                        try{
                            //lock on same key fail
                            LockUtils.getInstance().tryLock( ()-> null,  "lock_fail", 100);
                            Thread.sleep(500);

                        }catch (InterruptedException interruptedException){}
                        return  null;
                    },
                    "test_lock",
                    500
            );

        };

       ExecutorUtils.ExecutionCount count= ExecutorUtils.getInstance().consume(items, consumer, executor);

       count.await();
       NAssert.state(count.getErrors() > 0, "must_have_errors");
        NAssert.state(Objects.equals(count.getErrorItems().get(0).getItem(), "item_2"), "must_be_item_2");
        //NAssert.state(count.getErrorItems().get(0).);

    }

    @Test
    void testLockWithSingleThreadExecutor() throws InterruptedException {
        Executor executor = ExecutorUtils.getInstance().getExecutor(1, "test");
        List<String> items = Arrays.asList("item_1", "item_2");
        Consumer<String> consumer = s -> {
            LockUtils.getInstance().tryLock( () -> {
                        try{
                            //lock on same key fail
                            LockUtils.getInstance().tryLock( ()-> null,  "lock_fail", 100);
                            Thread.sleep(500);

                        }catch (InterruptedException interruptedException){}
                        return  null;
                    },
                    "test_lock",
                    500
            );
        };

        ExecutorUtils.ExecutionCount count= ExecutorUtils.getInstance().consume(items, consumer, executor);

        count.await();
        NAssert.state(count.getErrors() == 0, "must_have_errors");

    }

    @Test
    void testLockWaitingWithMultiThreadExecutor() throws InterruptedException {
        Executor executor = ExecutorUtils.getInstance().getExecutor(5, "test");
        List<String> items = Arrays.asList("item_1", "item_2");

        LocalDateTime startTime = LocalDateTime.now();
        long millisDif = 600;
        Consumer<String> consumer = s -> {
            LockUtils.getInstance().lock( () -> {
                        try{
                            Thread.sleep(600);

                        }catch (InterruptedException interruptedException){}
                        return  null;
                    },
                    "test_lock"
            );
        };

        ExecutorUtils.ExecutionCount count= ExecutorUtils.getInstance().consume(items, consumer, executor);

        count.await();
        NAssert.state(count.getErrors() == 0, "must_have_errors");
        NAssert.state(LocalDateTime.now().isAfter(startTime.plus(millisDif * items.size(), ChronoUnit.MILLIS)), "must_wait_execution");

    }

    @Test
    void testLockNotWaitingWithMultiThreadExecutor() throws InterruptedException {
        Executor executor = ExecutorUtils.getInstance().getExecutor(5, "test");
        List<String> items = Arrays.asList("item_1", "item_2");

        LocalDateTime startTime = LocalDateTime.now();
        long millisDif = 2000;
        Consumer<String> consumer = s -> {

            LockUtils.getInstance().lock( () -> {
                        try{
                            Thread.sleep(500);
                        }catch (InterruptedException interruptedException){}
                        return  null;
                    },
                    s
            );

        };

        ExecutorUtils.ExecutionCount count= ExecutorUtils.getInstance().consume(items, consumer, executor);

        count.await();
        NAssert.state(count.getErrors() == 0, "must_have_errors");
        NAssert.state(LocalDateTime.now().isBefore(startTime.plus(millisDif * items.size(), ChronoUnit.MILLIS)), "must_wait_execution");

    }
}
