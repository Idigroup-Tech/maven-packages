/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.utils.concurrency;


import com.google.common.util.concurrent.ThreadFactoryBuilder;
import lombok.Getter;
import org.apache.commons.lang3.ObjectUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

/**
 * Created by klayer3 on 19/06/25
 */
public class ExecutorUtils {
    private ExecutorUtils(){}
    @Getter
    private static ExecutorUtils instance = new ExecutorUtils();
    private Executor currentThreadExecutor = Runnable::run;


    public Executor getExecutor(Integer thread , String name){
        if(ObjectUtils.firstNonNull(thread,0) > 0){
            return Executors.newFixedThreadPool(thread, new ThreadFactoryBuilder().setNameFormat(name+"-%d").build());
        }
        return currentThreadExecutor;
    }


    public Executor getExecutor(Integer thread ){
        if(ObjectUtils.firstNonNull(thread,0) > 0){
            return Executors.newFixedThreadPool(thread);
        }
        return currentThreadExecutor;
    }



    public <T> ExecutorUtils.ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor){
        return consume(items, consumer, taskExecutor, new ExecutorUtils.ExecutionCount(), false);
    }

    public <T> ExecutorUtils.ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor, boolean throwsError){
        return consume(items, consumer, taskExecutor, new ExecutorUtils.ExecutionCount(), throwsError);
    }

    public <T> ExecutorUtils.ExecutionCount consume(Collection<T> items, Consumer<T> consumer, Executor taskExecutor, ExecutorUtils.ExecutionCount executionCount, boolean throwsError){
        items.stream().forEach(item -> {
            executionCount.register();
            taskExecutor.execute(() -> {
                try{
                    if( !throwsError || executionCount.error() < 1L) {
                        consumer.accept(item);
                    }
                } catch(Throwable e){

                    executionCount.addError(item, e);

                    if(throwsError ){
                        //FIXME K3 dovremmo cancellare tutta la coda!!!!
                        throw new RuntimeException(e);
                    } else {
                        e.printStackTrace();
                    }


                } finally {
                    //FIXME STIAMO DANDO PER Scontato il successo delle transazioni dei vari thread
                    executionCount.arrive();
                }
            });

            if(throwsError && executionCount.getErrors() > 0){
                throw new RuntimeException(executionCount.errorItems.get(0).cause);
            }
        });

        return executionCount;
    }

    public static class ErrorItem {
        private Object item;
        private Throwable cause;

        public ErrorItem(Object item, Throwable cause) {
            this.item = item;
            this.cause = cause;
        }

        public Object getItem() {
            return item;
        }

        public void setItem(Object item) {
            this.item = item;
        }

        public Throwable getCause() {
            return cause;
        }

        public void setCause(Throwable cause) {
            this.cause = cause;
        }
    }

    public static class ExecutionCount {

        private long intervall = 100;

        private final AtomicLong tasks=new AtomicLong(0);

        private final AtomicLong errors=new AtomicLong(0);

        private final AtomicLong executed=new AtomicLong(0);

        private final List<ExecutorUtils.ErrorItem> errorItems = new ArrayList<ExecutorUtils.ErrorItem>();


        public ExecutionCount() {
            super();
        }

        private ExecutionCount(long intervall) {
            super();
            this.intervall = intervall;
        }

        private Long register(){
            return tasks.incrementAndGet();
        }

        private Long error(){
            return errors.incrementAndGet();
        }

        private Long arrive(){
            return executed.incrementAndGet();
        }

        @Deprecated
        public void await() throws InterruptedException{

            //non è performante
            //FIXME dividere in current await ed await generale dovremmo gestire un evento con una condition

            while(!getTasks().equals(getExecuted())){
                Thread.sleep(intervall);
            }
        }

        private void addError(Object item, Throwable cause){
            this.errorItems.add(new ExecutorUtils.ErrorItem(item, cause));
            this.error();
        }

        public Long getTasks(){
            return tasks.get();
        }

        public Long getErrors(){
            return errors.get();
        }

        public Long getExecuted(){
            return executed.get();
        }

        public List<ExecutorUtils.ErrorItem> getErrorItems(){
            return new ArrayList<ExecutorUtils.ErrorItem>(errorItems);
        }

        @Override
        public String toString() {
            return "ExecutionCount{" +
                    "tasks=" + tasks +
                    ", errors=" + errors +
                    ", executed=" + executed +
                    '}';
        }
    }
}
