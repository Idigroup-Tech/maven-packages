/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.utils.concurrency;


import com.google.common.util.concurrent.Striped;
import it.antlab.utils.nassert.NAssert;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;


import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.function.Supplier;

/**
 * Created by klayer3 on 19/06/25
 */
@Slf4j
public class LockUtils {
    private LockUtils(){}
    @Getter
    private static LockUtils instance = new LockUtils();

    private static long defaultWaitTimeMillis = 5000;
    private Striped<Lock> stripedLock = Striped.lock(500);

    public <T> T tryLock(Supplier<T> supplier, String lockKey, long millis ) throws LockException {

        NAssert.state(millis > 0, "millis should be greater than 0");
        log.debug("running tryLock {}, millis {}", lockKey, millis);
        Lock lock = stripedLock.get(lockKey);
        try {
            if (lock.tryLock(millis, TimeUnit.MILLISECONDS)) {
                try {
                    T ret = supplier.get();
                    return ret;
                } finally {
                    log.debug("end tryLock {}, millis {}", lockKey, millis);
                    lock.unlock();
                }
            } else {
                log.warn("timeout tryLock {}, millis {}", lockKey, millis);
                throw new LockTimeOutException();
            }
        } catch (InterruptedException interruptedException) {
            log.error("interrupted tryLock {}, millis {}", lockKey, millis);
            throw new LockInterruptedException(interruptedException);
        }
    }

    //non gestiamo veramente il lock eterno
    public  <T> T lock(Supplier<T> supplier, String lockKey) throws LockException {
        return tryLock(supplier, lockKey, defaultWaitTimeMillis);
    }


    public static abstract class LockException extends RuntimeException {
        public LockException() {
            super();
        }
        public LockException(String message) {
            super(message);
        }
        public LockException(String message, Throwable cause) {
            super(message, cause);
        }
        public LockException(Throwable cause) {
            super(cause);
        }
    }


    public static abstract class CheckedLockException extends LockException {
        public CheckedLockException() {
            super();
        }
        public CheckedLockException(String message) {
            super(message);
        }
        public CheckedLockException(String message, Throwable cause) {
            super(message, cause);
        }
        public CheckedLockException(Throwable cause) {
            super(cause);
        }
    }

    public static class UncheckedLockException extends LockException {
        public UncheckedLockException(String message, Throwable cause) {
            super(message, cause);
        }
        public UncheckedLockException(Throwable cause) {
            super(cause.getMessage(), cause);
        }
    }



    public static class LockTimeOutException extends CheckedLockException{}

    public static class LockInterruptedException extends CheckedLockException{
        public LockInterruptedException(InterruptedException interruptedException) {
            super(interruptedException);
        }
    }
}
