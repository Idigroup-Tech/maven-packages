/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.model.dto.search;

import java.util.ArrayList;
import java.util.List;

import io.nettuno.dynacrud.base.SearchRequest;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class SearchDTO implements SearchRequest {
    @Schema(nullable = true, name = "searchFilter")
    @Builder.Default
    private SearchFilterDTO filter = new SearchFilterDTO();
    @Schema(nullable = true, name = "sort")
    @Builder.Default
    private List<SearchSortDTO> sort = new ArrayList<>();
    @Schema(nullable = true, name = "pagination")
    @Builder.Default
    private SearchPaginationDTO pagination = new SearchPaginationDTO();

    @Schema(hidden = true)
    @Builder.Default
    private List<String> dataToReturn = new ArrayList<>();

   public SearchDTO(Integer pageSize, Integer page) {
        this();
        this.getPagination().setSize(pageSize);
        this.getPagination().setPage(page);
    }

    public SearchDTO(String textSearch, Integer pageSize, Integer page) {
        this();
        this.getFilter().setText(textSearch);
        this.getPagination().setSize(pageSize);
        this.getPagination().setPage(page);
    }
    public SearchDTO(String textSearch, Integer pageSize) {
        this();
        this.getFilter().setText(textSearch);
        this.getPagination().setSize(pageSize);
    }

    /* (non-Javadoc)
     * @see it.galactus.core.model.dto.search.SearchRequest#getFilter()
     */
    @Override
    public SearchFilterDTO getFilter() {
        return filter;
    }
    public void setFilter(SearchFilterDTO filter) {
        this.filter = filter;
    }
    /* (non-Javadoc)
     * @see it.galactus.core.model.dto.search.SearchRequest#getSort()
     */
    @Override
    public List<SearchSortDTO> getSort() {
        return sort;
    }
    public void setSort(List<SearchSortDTO> sort) {
        this.sort = sort;
    }
    /* (non-Javadoc)
     * @see it.galactus.core.model.dto.search.SearchRequest#getPagination()
     */
    @Override
    public SearchPaginationDTO getPagination() {
        return pagination;
    }
    public void setPagination(SearchPaginationDTO pagination) {
        this.pagination = pagination;
    }

    @Override
    public List<String> getDataToReturn() { return dataToReturn; }
    public void setDataToReturn(List<String> dataToReturn) {
        this.dataToReturn = dataToReturn;
    }
}


