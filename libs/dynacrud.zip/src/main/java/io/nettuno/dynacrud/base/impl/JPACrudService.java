/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base.impl;

import io.nettuno.dynacrud.base.LeftJoinResolver;
import io.nettuno.dynacrud.base.SearchRequest;
import io.nettuno.dynacrud.base.impl.filter.JPAFilterParser;
import io.nettuno.dynacrud.config.Constants;
import io.nettuno.dynacrud.model.dto.search.Filter;
import io.nettuno.dynacrud.model.dto.search.FilterOperation;
import io.nettuno.dynacrud.model.dto.search.FilterOption;
import io.nettuno.dynacrud.model.dto.search.PaginationType;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.repository.query.QueryUtils;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.lang.reflect.Field;
import java.time.temporal.Temporal;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static io.nettuno.dynacrud.base.utils.RegexPatterns.STANDALONE_NUMERIC;


@Service("defaultCrudService")
@Transactional
public class JPACrudService<T> extends DefaultCrudService<T> {

    @PersistenceContext
    protected EntityManager em;

    private final PaginationType defaultPaginationType = PaginationType.FULL;

    @Override
    public CrudRepository getDefaultRepository() {
        // TODO Auto-generated method stub
        return new SimpleJpaRepository(getType(), em);
    }

    //TODO FS Aggiungere ricerca full text
    @Override
    public Page<T> search(SearchRequest srequest) {

        this.setAttribute("SearchRequest", srequest);

        StringBuilder squery = new StringBuilder(getQuery());

        List<String> resolvedJoins = resolveJoin(Constants.BASE_QUERY_ALIAS.trim(), getType());

        for (String join : resolvedJoins) {
            //FIXME K3 deve evolvere da configurazione  e fetch opzionali solo primo livello?
            if ( /*false && */StringUtils.countMatches(join, ".") == 1) {
                squery.append(Constants.BASE_QUERY_LEFT_JOIN + "FETCH " + join);
            } else {
                squery.append(Constants.BASE_QUERY_LEFT_JOIN + join);
            }
        }

        String condition = "";

        Filter filter = getFilter(srequest);

        JPAFilterParser jpfp = new JPAFilterParser(getType(), filter);

        if (filter != null) {
            condition = jpfp.getCondition();
        }

        String customConditions = getCustomConditions();
        if( StringUtils.isBlank(customConditions)){
            customConditions = "";
        }


        String queryString = squery + customConditions + (StringUtils.isNotEmpty(condition) ? (needWhere() ? " where " : " and ") : "") + condition;

        queryString = setSort(srequest, queryString, jpfp.getPrimaryKeyField().getName());

        Query query = em.createQuery(queryString);


        StringBuilder sCountQuery = new StringBuilder(getCountQuery());
        for (String join : resolvedJoins) {
            sCountQuery.append(Constants.BASE_QUERY_LEFT_JOIN + join);
        }

        String queryCountString = sCountQuery.toString() + customConditions + (StringUtils.isNotEmpty(condition) ? (needWhere() ? " where " : " and ") : "") + condition;

        Query countQuery = em.createQuery(queryCountString);

        setParameters(jpfp, query, countQuery);
        setPagination(srequest, query);

        return getPage(srequest, query, PaginationType.FULL.equals(ObjectUtils.firstNonNull(srequest.getPagination().getPaginationType(), defaultPaginationType)) ? countQuery : null);//,countQuery);
    }

    protected String getCustomConditions() {
        return null;
    }


    @Override
    @Deprecated //NON LO VOGLIAMO?
    public Stream<T> searchAll(SearchRequest searchRequest) {
        this.setAttribute("SearchRequest", searchRequest);

        StringBuilder squery = new StringBuilder(getQuery());

        List<String> resolvedJoins = resolveJoin(Constants.BASE_QUERY_ALIAS.trim(), getType());

        for (String join : resolvedJoins) {
            //FIXME K3 deve evolvere da configurazione  e fetch opzionali solo primo livello?
            if ( /*false && */StringUtils.countMatches(join, ".") == 1) {
                squery.append(Constants.BASE_QUERY_LEFT_JOIN + "FETCH " + join);
            } else {
                squery.append(Constants.BASE_QUERY_LEFT_JOIN + join);
            }
        }

        String condition = "";

        Filter filter = getFilter(searchRequest);

        JPAFilterParser jpfp = new JPAFilterParser(getType(), filter);

        if (filter != null) {
            condition = jpfp.getCondition();
        }


        String queryString = squery + (StringUtils.isNotEmpty(condition) ? (needWhere() ? " where " : " and ") : "") + condition;

        queryString = setSort(searchRequest, queryString, jpfp.getPrimaryKeyField().getName());

        Query query = em.createQuery(queryString);


        StringBuilder sCountQuery = new StringBuilder(getCountQuery());
        for (String join : resolvedJoins) {
            sCountQuery.append(Constants.BASE_QUERY_LEFT_JOIN + join);
        }

        String queryCountString = sCountQuery + (StringUtils.isNotEmpty(condition) ? (needWhere() ? " where " : " and ") : "") + condition;

        Query countQuery = em.createQuery(queryCountString);

        setParameters(jpfp, query, countQuery);
        return query.getResultStream();
    }

    private Page<T> getPage(SearchRequest srequest, Query query, Query countQuery) {
        List<T> resList = query.getResultList();

        long total;

        //Se é la prima pagina e il totale é inferiore al size richiesto non eseguo la count
        //Minore e non minore/uguale perché la query é paginata a monte quindi sarebbe sempre vero
        if (srequest.getPagination().getPage() == 0 && resList.size() < srequest.getPagination().getSize()) {
            total = resList.size();
        } else if(countQuery != null) {
            total = (Long) countQuery.getSingleResult();
        } else {
            //LIGHT_PAGINATION
            total = resList.size();
            resList = resList.size() >  srequest.getPagination().getSize() ? resList.subList(0, srequest.getPagination().getSize()) : resList;
        }

        Page<T> page = new PageImpl<>(
                resList,
                PageRequest.of(srequest.getPagination().getPage(), srequest.getPagination().getSize()),
                total);


        return page;
    }

    private void setPagination(SearchRequest srequest, Query query) {
        query.setFirstResult(srequest.getPagination().getPage() * srequest.getPagination().getSize());
        if (PaginationType.FULL.equals(ObjectUtils.firstNonNull(srequest.getPagination().getPaginationType(), defaultPaginationType))) {
            query.setMaxResults(srequest.getPagination().getSize());
        } else {
            query.setMaxResults(srequest.getPagination().getSize() + 1);
        }
    }

    protected boolean needWhere() {
        return true;
    }

    protected String setSort(SearchRequest srequest, String queryString, String defaultField) {
        //FIXME K3 ordinamento va rivisto e ragionato soprattutto sulle join!!!
        if (srequest.getSort() != null && !srequest.getSort().isEmpty()) {
            List<Order> orders = srequest.getSort().stream().map(sort -> {
                        if (sort.getDirection() != null)
                            return new Order(Direction.fromString(sort.getDirection().toString()), sort.getField());
                        return Order.by(sort.getField());
                    }
            ).collect(Collectors.toList());

            queryString = QueryUtils.applySorting(queryString, Sort.by(orders));
        } else {


            queryString = QueryUtils.applySorting(queryString, Sort.by(new Order(Direction.ASC, defaultField)));
        }
        return queryString;
    }

    protected void setParameters(JPAFilterParser jpfp, Query query, Query countQuery) {
        int param_prog = 0;
        for (Object param : jpfp.getParameters()) {
            query.setParameter("_param_" + (++param_prog), param);
            countQuery.setParameter("_param_" + (param_prog), param);
        }
    }


    protected Filter getFilter(SearchRequest srequest) {
        Filter filter = null;
        Filter defaultFilter = getDefaultFilter();

        //qui popolo il filtro o tramite il filtro impostato dal client o creandolo per le full text
        Filter fullTextFilter = null;
        Filter requestFilter = null;
        if (srequest.getFilter() != null) {

            String text = srequest.getFilter().getText();
            if (StringUtils.isNotEmpty(StringUtils.trim(text))) {
                fullTextFilter = getFullTextFilter(text);
            }

            requestFilter = srequest.getFilter().getFilterBy();

        }

        List<Filter> filters = Stream.of(defaultFilter, requestFilter, fullTextFilter).filter(Objects::nonNull).collect(Collectors.toList());

        if (filters.size() > 1) {
            filter = new Filter();
            filter.setOperation(FilterOperation.AND);
            filter.setFilters(filters);

        } else if (filters.size() == 1) {
            filter = filters.get(0);
        }

        return filter;
    }


    private Filter getFullTextFilter(String textSearch) {
        Assert.isTrue(StringUtils.isNotBlank(textSearch), "textSearch required!");
        Filter fullTextFilter = new Filter();
        fullTextFilter.setOperation(FilterOperation.OR);

        // ricerca anche stringhe intere "cacca pipì"
        List<String> tokens =
                StringUtils.startsWith(textSearch, "\"") && StringUtils.endsWith(textSearch, "\"") ?
                        Arrays.asList(StringUtils.substring(textSearch, 1, -1))
                        :
                        Arrays.asList(textSearch.split(" ")).stream().map(s -> StringUtils.trim(s)).filter(s -> StringUtils.isNotBlank(s)).distinct().collect(Collectors.toList());
        Collection<JPAFilterParser.EntityProperties> entityProperties = new JPAFilterParser(getType(), fullTextFilter).getProperties().values();

        //TODO Valutare se formare la query usando CONCAT invece degli OR, per le prestazioni.
        //TODO È possible ulteriore refactoring per evitare eccessivi loop?

        boolean isMultiple = tokens.size() > 1;

        fullTextFilter.setOperation(isMultiple ? FilterOperation.AND : FilterOperation.OR);

        for (String token : tokens) {
            Filter groupFilter = fullTextFilter;

            if (isMultiple) {
                groupFilter = new Filter();
                groupFilter.setOperation(FilterOperation.OR);

            }
            for (JPAFilterParser.EntityProperties ep : entityProperties) {
                Filter subFilter = null;
                if (!ep.isAutocomplete()) continue;
                if (String.class.isAssignableFrom(ep.getType())) {
                    subFilter = new Filter();
                    subFilter.setField(ep.getPath());
                    subFilter.setOperation(FilterOperation.LIKE);
                    subFilter.getOptions().add(FilterOption.IGNORECASE);
                    subFilter.setValue(token);

                } else if (ep.getType().isEnum()) {
                    subFilter = new Filter();
                    subFilter.setField(ep.getPath());
                    subFilter.setOperation(FilterOperation.LIKE);
                    subFilter.getOptions().add(FilterOption.STRINGIFY);
                    subFilter.getOptions().add(FilterOption.IGNORECASE);
                    subFilter.setValue(token);

                    System.out.println(subFilter);

                } else if (token.matches(STANDALONE_NUMERIC.getValue()) && Number.class.isAssignableFrom(ep.getType())) {
                    subFilter = new Filter();
                    subFilter.setField(ep.getPath());
                    subFilter.setOperation(FilterOperation.LIKE);
                    subFilter.getOptions().add(FilterOption.STRINGIFY);
                    subFilter.setValue(token);
                } else if (StringUtils.remove(token, "-").matches(STANDALONE_NUMERIC.getValue()) && Temporal.class.isAssignableFrom(ep.getType())) {
                    subFilter = new Filter();
                    subFilter.setField(ep.getPath());
                    subFilter.setOperation(FilterOperation.LIKE);
                    subFilter.getOptions().add(FilterOption.STRINGIFY);
                    subFilter.setValue(token);
                }

                if (subFilter != null) {
                    groupFilter.getFilters().add(subFilter);

                }
            }

            if (isMultiple) {
                if (!groupFilter.getFilters().isEmpty()) {
                    fullTextFilter.getFilters().add(groupFilter);
                }
            }

        }


        return fullTextFilter.getFilters().isEmpty() ? null : fullTextFilter;
    }

    protected String getQuery() {

        String baseQuery = Constants.BASE_QUERY_SELECT + getType().getName() + Constants.BASE_QUERY_ALIAS;

        return baseQuery;
    }

    protected String getCountQuery() {

        JPAFilterParser jpfp = new JPAFilterParser(getType(), null);
        String baseQuery = Constants.BASE_QUERY_SELECT_COUNT + getType().getName() + Constants.BASE_QUERY_ALIAS;
        if (jpfp.getPrimaryKeyField() != null) {
            baseQuery = "select count( " + Constants.BASE_QUERY_ALIAS.trim() + "." + jpfp.getPrimaryKeyField().getName() + ") from " + getType().getName() + " " + Constants.BASE_QUERY_ALIAS;
        }

        return baseQuery;
    }

    protected Filter getDefaultFilter() {
       /* Filter filter = new Filter();
        filter.setField("owner");
        filter.setOperation(FilterOperation.EQ);
        filter.setValue(LoggedUserInfoUtil.getLoggedInUser().getUserId());
        return filter;*/
        return null;
    }


    private List<String> resolveJoin(String basePath, Class type) {


        //Constants.BASE_QUERY_ALIAS.trim()

        List<String> result = new ArrayList<>();

        for (Field child : type.getDeclaredFields()) {
            if (!basePath.endsWith("." + child.getName()) && child.getAnnotation(javax.persistence.Transient.class) == null && child.getAnnotation(LeftJoinResolver.class) != null) {

                String subPath = basePath + "." + child.getName();
                List<String> childResult = resolveJoin(subPath, child.getType());
                if (childResult.isEmpty()) {
                    result.add(subPath);
                } else {
                    result.addAll(childResult);
                }
            }
        }


        return result;

    }

}


