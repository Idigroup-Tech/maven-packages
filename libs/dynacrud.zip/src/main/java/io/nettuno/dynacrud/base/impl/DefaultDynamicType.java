/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base.impl;

import io.nettuno.dynacrud.base.DynamicTypeHandler;

import java.lang.reflect.ParameterizedType;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class DefaultDynamicType implements DynamicTypeHandler {
    
    private static String CURRENT_TYPE = "CURRENT_TYPE";
   
    private Attributes attributes = new Attributes();
    
    public Collection<String> getAttributeNames(){
       
        return attributes.getAttributeNames();
    }
    
    public Object getAttribute(String key) {
        return attributes.getAttribute(key);
    }

    public void setAttribute(String key, Object value) {   
        attributes.setAttribute(key, value);
    }

    public void removeAttribute(String key) {
        attributes.removeAttribute(key);
    }
    

    @Override
    public void setType(Class type) {
        attributes.initAttributes(true);
        setAttribute(CURRENT_TYPE, type);
    }

    @Override
    public Class getType() {
        if(getAttribute(CURRENT_TYPE) != null)
            return (Class)getAttribute(CURRENT_TYPE);
        else if (ParameterizedType.class.isAssignableFrom(getClass().getGenericSuperclass().getClass())) {
            Class ret = ((Class) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0]);
            setType(ret);
            return ret;
        }
        
        throw new RuntimeException("no type found!");
        
    }
    
    private static class Attributes {
        private Map<String, Object> instance(){
            initAttributes(false);
            return attributes.get();
        }
        
        private void initAttributes(boolean force){
            if(attributes.get() == null || force) 
                attributes.set(new HashMap<String, Object>());
        }
        
        private ThreadLocal<Map<String, Object>> attributes = new  ThreadLocal<Map<String,Object>>();
        
        private Collection<String> getAttributeNames(){
            
            return instance().keySet();
        }
        
        public Object getAttribute(String key) {
            return instance().get(key);
        }

        public void setAttribute(String key, Object value) {   
            instance().put(key, value);
        }

        public void removeAttribute(String key) {
            instance().remove(key);
        }
        
    }

}
