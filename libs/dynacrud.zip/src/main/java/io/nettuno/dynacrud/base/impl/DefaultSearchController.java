/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base.impl;

import io.nettuno.dynacrud.base.Context;
import io.nettuno.dynacrud.base.CrudController;
import io.nettuno.dynacrud.base.Facade;
import io.nettuno.dynacrud.base.SearchRequest;
import io.nettuno.dynacrud.model.dto.response.ResponseDTO;
import io.nettuno.dynacrud.model.dto.search.SearchDTO;
import io.nettuno.dynacrud.service.SearchRequestParser;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;

/**
 * Created by klayer3 on 07/02/20.
 */
public class DefaultSearchController<T> extends DefaultDynamicType implements CrudController<T> {

    @Autowired
    private SearchRequestParser searchRequestParser;

    @Override
    public Facade<T> getFacade() {
        return Context.instance().getComponent(getType(), Facade.class);
    }

    @GetMapping
    @Operation(
            parameters = {
                    @Parameter(name = "searchRequest", description = "Base64 SearchRequest ", schema = @Schema(implementation = SearchDTO.class)),
                    @Parameter(name = "textSearch", description = "Text search alternative to SearchRequest.filter.text", schema = @Schema(implementation = String.class)),
                    @Parameter(name = "page", description = "page number alternative to SearchRequest.pagination.page", schema = @Schema(implementation = Integer.class)),
                    @Parameter(name = "pageSize", description = "Size of the page alternative to SearchRequest.pagination.size", schema = @Schema(implementation = Integer.class)),
            })
    public ResponseEntity<ResponseDTO<Collection<T>>> search(
            @RequestParam(required = false) String searchRequest,
            @RequestParam(required = false) String textSearch,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer pageSize) throws IOException {

        SearchRequest searchRequestImpl =  searchRequestParser.parseEncode(searchRequest, textSearch, pageSize, page);
        ResponseDTO<Collection<T>> responseDTO = ResponseDTO.createResponseDTO(getFacade().search(searchRequestImpl));
        responseDTO.getMeta().setSort(searchRequestImpl.getSort()); //FIXME Va mappato il sort di Spring invece di usare sta pecionata
        return ResponseEntity.ok(responseDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ResponseDTO<T>> retrieve(@PathVariable Serializable id) {
        ResponseEntity responseEntity = null;
        ResponseDTO responseDTO = ResponseDTO.createResponseDTO(getFacade().read(id));
        if (responseDTO.getData() == null) {
            responseEntity = new ResponseEntity<>(responseDTO, HttpStatus.NOT_FOUND);
        } else {
            responseEntity = new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        return responseEntity;
    }

    @GetMapping("/all")
    @Hidden
    public ResponseEntity<ResponseDTO<Collection<T>>> searchAll(
            @RequestParam(required = false) String searchRequest,
            @RequestParam(required = false) String textSearch,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer pageSize) throws IOException {
        SearchRequest searchRequestImpl =  searchRequestParser.parseEncode(searchRequest, textSearch, pageSize, page);
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(getFacade().searchAll(searchRequestImpl)));
    }
}
