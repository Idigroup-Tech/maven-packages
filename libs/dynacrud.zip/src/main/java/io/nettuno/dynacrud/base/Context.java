/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;


/**
 * 
 * @author Riccardo Mohamed
 *
 */

@Component("dynacrudContext")
@Order(Ordered.HIGHEST_PRECEDENCE)
@Lazy(false)
public class Context implements ApplicationContextAware{

    private ApplicationContext springContext;
    private static Context instance;
    private String applicationName;

    public Context() {
       super();
       //Assert.isTrue(instance == null, "Attenzione Contesto spring è nullo!");
       instance = this;
    }
    
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        springContext = applicationContext;   
        applicationName = springContext.getEnvironment().getProperty("spring.application.name");
    }

    public static Context instance() {
        Assert.isTrue(instance != null, "Attenzione Contesto spring è nullo!");
        return instance;
    }
   
    public <T> T getComponent(String name, Class<T> type){
        return getComponent(name, type, true);
    }
    

    public <T> T getComponent(Class entity, Class<T> type){
        
        T ret = getComponent(entity.getSimpleName()+type.getSimpleName(), type, true);
        
        if( ret != null && DynamicTypeHandler.class.isAssignableFrom(ret.getClass()))
            ((DynamicTypeHandler) ret).setType(entity);
       
        return ret;
        
        
    }
    //FIXME K3 CACHE
    public <T> T getComponent(String name, Class<T> type, boolean searchDefault ){
        T ret = null;
            if( getSpringContext().containsBean(name) ) {
                ret = getSpringContext().getBean(name, type);
            } else if( searchDefault ) {
                
                if( applicationName != null && getSpringContext().containsBean(applicationName+type.getSimpleName())){
                    
                    ret = getSpringContext().getBean(applicationName+type.getSimpleName(), type);
                    
                } else if( getSpringContext().containsBean("default"+type.getSimpleName())) {
                    
                    ret = getSpringContext().getBean("default"+type.getSimpleName(), type);
                    
                }
            }
        
        return ret;
    }
    
    public ApplicationContext getSpringContext(){
        return springContext;
    }
}
