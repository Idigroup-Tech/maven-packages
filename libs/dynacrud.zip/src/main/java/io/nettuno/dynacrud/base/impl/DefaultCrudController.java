/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base.impl;


import io.nettuno.dynacrud.base.Entity;
import io.nettuno.dynacrud.exception.BadRequestException;
import io.nettuno.dynacrud.model.dto.response.ResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.Serializable;


//FIXME K3 per il momento lasciamo aperto il discorso sicurezza
public class DefaultCrudController<T> extends DefaultSearchController<T> {


    @PostMapping
    public ResponseEntity<ResponseDTO<T>> create(@Valid @RequestBody T dto, BindingResult result) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(getFacade().insert(dto)));
    }


    //FIXME Id non-primitive o non-numeriche vengono gestite come una nuova entita' e persistite
    @PutMapping("/{id}")
    public ResponseEntity<ResponseDTO<T>> update(@Valid @RequestBody T dto, @PathVariable Serializable id, BindingResult result) {
        if (dto != null && Entity.class.isAssignableFrom(dto.getClass()) && !id.toString().equals(((Entity) dto).getId().toString())) {throw new BadRequestException("Wrong identifier!");
        }
        ResponseEntity responseEntity = null;
        ResponseDTO responseDTO = ResponseDTO.createResponseDTO(getFacade().update(dto, id));
        if (responseDTO.getData() == null) {
            responseEntity = new ResponseEntity<>(responseDTO, HttpStatus.NOT_FOUND);
        } else {
            responseEntity = new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        return responseEntity;
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<ResponseDTO<T>> delete(@PathVariable Serializable id) {
        ResponseDTO responseDTO = ResponseDTO.createResponseDTO(getFacade().delete(id));
        ResponseEntity responseEntity = new ResponseEntity(responseDTO, HttpStatus.OK);

        return responseEntity;
    }


}
