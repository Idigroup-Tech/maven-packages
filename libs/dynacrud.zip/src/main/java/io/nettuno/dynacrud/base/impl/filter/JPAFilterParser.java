/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base.impl.filter;

import io.nettuno.dynacrud.base.Entity;
import io.nettuno.dynacrud.base.IgnoreSearch;
import io.nettuno.dynacrud.base.IgnoreTextSearch;
import io.nettuno.dynacrud.model.dto.search.Filter;
import io.nettuno.dynacrud.model.dto.search.FilterOperation;
import io.nettuno.dynacrud.model.dto.search.FilterOption;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;


import javax.persistence.Id;
import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class JPAFilterParser {
    private static HashMap<Class, Map<String, EntityProperties>> propertiesCache = new HashMap<>();

    private static HashMap<Class,Field> primaryKeyFieldMap = new HashMap<>();

    private static HashMap<FilterOperation,String > operatorMap = new HashMap<>();
    
    private static HashMap<FilterOperation,String > valueMap = new HashMap<>();
    
    private static HashMap<FilterOption,String > optionMap = new HashMap<>();

    private final static Logger log = LoggerFactory.getLogger(JPAFilterParser.class);
    
    static{
        // configurazione operatori e 
        operatorMap.put(FilterOperation.EQ, "=");
        operatorMap.put(FilterOperation.NEQ, "!=");

        operatorMap.put(FilterOperation.GT, ">");
        operatorMap.put(FilterOperation.LT, "<");
        operatorMap.put(FilterOperation.GTE, ">=");
        operatorMap.put(FilterOperation.LTE, "<=");
        
        optionMap.put(FilterOption.IGNORECASE, "LOWER( %s )");
        optionMap.put(FilterOption.STRINGIFY,"concat( %s ,'' )" );
    }

    private Class type;

    private Filter filter;

    public JPAFilterParser(Class type, Filter filter) {
        super();
        this.type = type;
        this.filter = filter;
        this.getAllFields(type);
    }


    private List parameters = new ArrayList<>();

    //manca cache
    private List<Field> getAllFields(Class klass) {

        List<Field> fields = new ArrayList<Field>();
        fields.addAll(Arrays.asList(klass.getDeclaredFields()).stream().filter( f -> f.getAnnotation(IgnoreSearch.class) == null).collect(Collectors.toList()));
        if (klass.getSuperclass() != null) {
            fields.addAll(getAllFields(klass.getSuperclass()));
        }
        if (primaryKeyFieldMap.get(klass) == null){

            for (Field field : fields) {

                if (Arrays.stream(field.getDeclaredAnnotations()).anyMatch(annotation -> annotation.annotationType().isAssignableFrom(Id.class))){

                    primaryKeyFieldMap.put(klass, field);
                    break;
                }
            }
        }
        return fields;
    }

    private Map<String, EntityProperties> getProperties(String basePath, Class type) {
        return getProperties(basePath, type, true);
    }

    private Map<String, EntityProperties> getProperties(String basePath, Class type, boolean testSearchEnabled) {

        Map<String, EntityProperties> ret = new HashMap();

        getAllFields(type).forEach(field -> {



            if ( field.getAnnotation(javax.persistence.Transient.class) == null ) {

                String fName = basePath + field.getName();
                Class fType = field.getType();

                if (Entity.class.isAssignableFrom(fType)) {
                    final String fieldCheck = field.getName();

                    if( !StringUtils.endsWith(basePath, fieldCheck + ".")){ //not one field loop -> item.father.father.father.
                        int matchCount = StringUtils.countMatches(basePath, "."+fieldCheck+".") ; //not relation loop -> survey.request.order.request.survey.

                        boolean canContinue = matchCount == 0 ;
                        if(matchCount > 0 ){
                            List<String> superChain = Arrays.asList(StringUtils.split(basePath, "." + fieldCheck + "."));  //survey,order,survey
                            canContinue = superChain.size() == superChain.stream().distinct().collect(Collectors.toList()).size();
                        }
                        if( canContinue ){
                            // ToOne ricorsione
                            ret.putAll(getProperties(fName + ".", fType, testSearchEnabled && field.getAnnotation(IgnoreTextSearch.class) == null));
                        }
                    }
                } else if (Collection.class.isAssignableFrom(fType)) {

                    // ToMany or element collection ... gestire

                } else if (Map.class.isAssignableFrom(fType)) {

                    // ToMany or element collection ... gestire

                } if(type.isEnum()) {
                    EntityProperties et = new EntityProperties(fName, fType, testSearchEnabled && field.getAnnotation(IgnoreTextSearch.class) == null);
                    ret.put(fName, et);
                    log.info("enumeration {} for field {} ");
                } else {
                    // put singolo campo base
                    ret.put(fName, new EntityProperties(fName, fType, testSearchEnabled && field.getAnnotation(IgnoreTextSearch.class) == null));

                }
            }
        });

        //propertiesCache.put(type, ret);

        return ret;
    }

    public synchronized Map<String, EntityProperties> getProperties() {
        if (propertiesCache.get(type) == null){
           propertiesCache.put(type, getProperties("", type));
        }
        // FIXME dobbiamo restituire una copia
        return new HashMap<>(propertiesCache.get(type));
    }

    private String getString(Filter filter) {
        StringBuilder condition = new StringBuilder();

        Assert.notNull(filter, "filter obbligatorio!");


        Assert.notNull(filter.getOperation(), "filter.operation required!");
        Assert.isTrue(!filter.getOperation().isLogic() || !filter.getFilters().isEmpty(), "filter.filters required!");
        Assert.isTrue(filter.getOperation().isLogic() || StringUtils.isNotEmpty(filter.getField()), "filter.field required!");
        //FIXME Dividere in due e aggiungere messaggio d'errore quando il campo non appartiene all'entita'?
        //Assert.isTrue(StringUtils.isEmpty(filter.getField()) || getProperties().containsKey(filter.getField()), "invalid field name ("+filter.getField()+")!");

        if (filter.getOperation().isValueRequired()) {
            Assert.notNull(filter.getValue(), "filter.value required!");
            Assert.isTrue(!Collection.class.isAssignableFrom(filter.getValue().getClass()) || !((Collection) filter.getValue()).isEmpty(), "filter.value required!");
            //FIXME K3 il value può essere un array di stringhe o una string o vuoto, non può essere un oggetto generico
        }


        if (filter.getOperation().isLogic()) {
            condition.append("(");

            int size = filter.getFilters().size();

            for (Filter sub : filter.getFilters()) {
                if (sub.getField() != null) sub.setField("entity." + sub.getField());
                log.debug("Current filter field :" + sub.getField());
                condition.append(getString(sub));
                if (size-- > 1) {
                    //AND OR
                    condition.append(" ").append(filter.getOperation().toString()).append(" ");
                }
            }
            condition.append(")");

        } else {
            condition.append(" ").append(getExpression(filter));
        }

        return condition.toString();
    }

    //TODO FS Migliorare gestione degli operatori
    private String getExpression(Filter filter) {

        String operation = "";
        log.info( "getExpression for {}", filter);
        Assert.isTrue(!filter.getOperation().isLogic(), "filter.getExpression not allowed!");
        EntityProperties entityProperties  = getProperties().get(filter.getField().replace("entity.", ""));
        Assert.notNull(entityProperties, "entityProperties not for "+filter.getField() +"!");
        Class type = entityProperties.type;

        String field = filter.getField();

        String value = filter.getOperation().isValueRequired() ? ":_param_" + (parameters.size() + 1) : "";

        if (filter.getOptions() != null) {
            for (FilterOption op : filter.getOptions()) {
                Assert.isTrue(op.canApply(type), op.toString() + " is not applicable to type " + type.getSimpleName());

                field = applyOption(op,field);
                if (filter.getOperation().isValueRequired()) 
                    value = applyOption(op,value);               
            }

        }

        if (!field.contains("entity.")) {

            field = "entity." + field;
        }

        operation = StringUtils.lowerCase(StringUtils.replace(filter.getOperation().toString(), "_", " " ));

        operation = applyOperation(type, filter.getOperation(), operation);
        value = applyValue(type, filter.getOperation(), value);
        addParameter(filter);

        return field + " " + operation + " " + value;
    }

    private String applyValue(Class type2, FilterOperation operation, String value) {
        String opVal = valueMap.get(operation);
        
        if( FilterOperation.LIKE.equals(operation) ){
            value = "concat('%', " + value + " ,'%')";
        } else if(opVal != null)
            value = String.format(opVal, value);
        return value;
    }

    private String applyOperation(Class type2, FilterOperation operation, String value) {
        
        if(FilterOperation.IS_NULL.equals(operation)){
                if (Collection.class.isAssignableFrom(type) || Map.class.isAssignableFrom(type)) {
                    value = "is empty";
                } else {
                    value = "is null";
                }
        } else if (FilterOperation.IS_NOT_NULL.equals(operation)){
            if (Collection.class.isAssignableFrom(type) || Map.class.isAssignableFrom(type)) {
                value = "is not empty";
            } else {
                value = "is not null";
            }
        } else {
            String opVal = operatorMap.get(operation);
            if(opVal != null)
                value = String.format(opVal, value);
            
        }
        
        return value;
    }

    private String applyOption(FilterOption op, String value) {
        
        String opVal = optionMap.get(op);
        if(optionMap.get(op)!= null)
            value = String.format(opVal, value);
        
        return value;
    }

    private void addParameter(Filter filter) {
        if (!filter.getOperation().isValueRequired()) return;

        parameters.add(getValue(filter, filter.getValue()));

    }

    //FIXME FS Aggiungere overload getValue(Filter filter)
    private Object getValue(Filter filter, Object value) {

        if (Collection.class.isAssignableFrom(value.getClass())) {
            return ((Collection) value).stream().map(i -> getValue(filter, i)).collect(Collectors.toList());
        }

        return convert(filter, value);
    }

    //TODO FS Ripensare le conversioni in maniera piú elegante
    public Object convert(Filter filter, Object value) {
        Class type2 = getProperties().get(filter.getField().replace("entity.", "")).type;
        if( type2.isPrimitive()){
            type2 = ClassUtils.primitiveToWrapper(type2);
        }
        try {
            String valueString = value.toString();

            //Fulltext per numeri/date
            if (filter.getOptions() != null && filter.getOptions().contains(FilterOption.STRINGIFY)) {
                return valueString;

            } else if (type2.isAssignableFrom(LocalDate.class)) {
                return LocalDate.parse(valueString, DateTimeFormatter.ISO_LOCAL_DATE);
            } else if (type2.isAssignableFrom(LocalDateTime.class)) {
                return LocalDateTime.parse(valueString, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            } else if (type2.isAssignableFrom(ZonedDateTime.class)) {
                return LocalDateTime.parse(valueString, DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneId.systemDefault());
            }else if ( type2.isEnum()) {
                return  EnumUtils.getEnumList(type2).stream().filter(en -> en.toString().equalsIgnoreCase(valueString)).findFirst().orElse(null);
            } else if (type2.isAssignableFrom(UUID.class)){
              return UUID.fromString(valueString);
            } else {
                try {
                    return type2.getConstructor(value.getClass()).newInstance(value);
                }catch ( NoSuchMethodException e){
                    return type2.getConstructor(valueString.getClass()).newInstance(valueString);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("JPAFilterParser.getValue type =  " + type2 + " value = " + value);
        }
    }

    public String getCondition() {
        return getString(filter);
    }

    public List getParameters() {
        return parameters;
    }


    public class EntityProperties {
        private String path;
        private Class type;
        private boolean autocomplete;

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public Class getType() {
            return type;
        }

        public void setType(Class type) {
            this.type = type;
        }

        public boolean isAutocomplete() {
            return autocomplete;
        }

        public void setAutocomplete(boolean autocomplete) {
            this.autocomplete = autocomplete;
        }

        private EntityProperties() {
            super();
            // TODO Auto-generated constructor stub
        }

        private EntityProperties(String path, Class type, boolean autocomplete) {
            super();
            this.path = path;
            this.type = type;
            this.autocomplete = autocomplete;
        }

        @Override
        public String toString() {
            return "EntityProperties{" +
                    "path='" + path + '\'' +
                    ", type=" + type +
                    ", autocomplete=" + autocomplete +
                    '}';
        }
    }

    public Field getPrimaryKeyField() {
        return primaryKeyFieldMap.get(this.type);
    }


}
