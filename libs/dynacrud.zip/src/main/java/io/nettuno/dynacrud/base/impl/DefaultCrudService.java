/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base.impl;

import io.nettuno.dynacrud.base.Context;
import io.nettuno.dynacrud.base.CrudService;
import io.nettuno.dynacrud.base.SearchRequest;
import io.nettuno.dynacrud.exception.ResourceNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;


@Transactional
public abstract class DefaultCrudService<T> extends DefaultDynamicType implements CrudService<T> {

    private static Map<Class, CrudRepository> repoCache =  Collections.synchronizedMap(new HashMap<Class, CrudRepository> ());
    
    public abstract CrudRepository getDefaultRepository();
    
            
    protected CrudRepository<T,Serializable> getRepository() {
        CrudRepository ret = repoCache.get(getType());
        if( ret == null){            
            ret = Context.instance().getComponent(getType(), CrudRepository.class);
            if ( ret == null){
                ret = getDefaultRepository();
            }
            repoCache.put(getType(), ret);
        }
        return ret;
    }
    
    @Override
    public T insert(T entity) {
        // TODO Auto-generated method stub
        return getRepository().save(entity);
    }
  
    public abstract Page<T> search(SearchRequest srequest);

    @Override
    public T read(Serializable id) {
        Optional<T> ret = getRepository().findById(id);
        return ret.isPresent() ? ret.get() : null;
    }

    @Override
    public T delete(Serializable id) {
        getRepository().deleteById(id);
        return null;
    }

    @Override
    @Deprecated//FIXME non è chiaro rivedere
    public T update(T en, Serializable id) {
        Optional<T> dbHit = getRepository().findById(id);
        //FIXME Aggiungere controllo su ID-rotta = ID-DTO?
        if (dbHit.isPresent()) {
            T dbEntity = en;
            return getRepository().save(dbEntity);
        } else {
            throw new ResourceNotFoundException("Id " + id + "not found!");
        }
    }


    @Transactional
    public T save(T entity){
        return this.insert(entity);
    }
    public abstract Stream<T> searchAll(SearchRequest searchRequest);

}
