/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import java.util.ArrayList;
import java.util.Collection;

public interface Converter<D , E> {
    
    D toDTO(E entity, boolean full);
    default D toDTO(E entity){
        return toDTO(entity, true);
    }

   default Collection<D> toDTOs(Collection<E> entityList){
       if (entityList == null) {
           return null;
       }
       Collection<D> dtoCollection = new ArrayList<>();
       for (E en : entityList) {
           dtoCollection.add(toDTO(en,false));
       }
       return dtoCollection;
   }

    E fromDTO(D dto);

    default Collection<E> fromDTOs(Collection<D> dtoList) {
        if (dtoList == null);
        Collection<E> entityCollection = new ArrayList<>();
        for (D dto : dtoList) {
            entityCollection.add(fromDTO(dto));
        }
        return entityCollection;
    }

    default Page toDTOs(Page page) {
        Page pageDto = new PageImpl(new ArrayList(toDTOs(page.getContent())), page.getPageable(), page.getTotalElements());
        return pageDto;
    }
    
}
