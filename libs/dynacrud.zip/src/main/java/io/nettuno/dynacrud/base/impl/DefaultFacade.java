/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.base.impl;


import io.nettuno.dynacrud.base.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Component("defaultFacade")
public class DefaultFacade<T>  extends DefaultDynamicType implements Facade<T> {
    
    private Serializable getId(Serializable id) {
        if( id != null && String.class.isAssignableFrom(id.getClass()) && StringUtils.isNotEmpty((String)id )){
            try{
                Method m = getServiceType().getMethod("getId");
                if( m != null){
                    if( !m.getReturnType().isAssignableFrom(id.getClass()) ){
                        if(m.getReturnType().isAssignableFrom(UUID.class)){
                            return UUID.fromString(Objects.toString(id));
                        }else {
                            // provo a costruirlo dalla stringa
                            return (Serializable) m.getReturnType().getConstructor(String.class).newInstance((String) id);
                        }
                    }
                }   
            }catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return id;
        
    }

    //FIXME K3 CACHE
    protected Converter<T,Object> getConverter() {
       return Context.instance().getComponent(getType(), Converter.class);
    }

    //FIXME K3 CACHE
    protected CrudService getCrudService() {
        return Context.instance().getComponent(getServiceType(), CrudService.class);
    }
    
    
    //FIXME K3 CACHE
    protected Class getServiceType(){
        if(getType().isAnnotationPresent(TargetType.class)){
            return ((TargetType)getType().getAnnotation(TargetType.class)).value();
        }
        return getType();
    }
    
    
    @Override
    @Transactional//( readOnly = true)
    public T insert(T t) {
        Object en = getConverter().fromDTO(t);
        en = getCrudService().insert(en);
        return getConverter().toDTO(en);
    }

    @Override
    @Transactional//( readOnly = true)
    public T update(T t, Serializable id) {
        Object en = getConverter().fromDTO(t);
        en = getCrudService().update(en, getId(id));
        return getConverter().toDTO(en);
    }

    @Override
    @Transactional
    public T delete(Serializable id) {
        Object en = getCrudService().delete(getId(id));
        return getConverter().toDTO(en);
    }

    @Override
    @Transactional(readOnly = true)
    public T read(Serializable id) {
        Object en = getCrudService().read(getId(id));
        return getConverter().toDTO(en, true);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<T> search(SearchRequest srequest) {
        //FIXME K3 gestiamo elastic search
        //FIXME K3 ordinamento va rivisto e ragionato
        return getConverter().toDTOs(getCrudService().search(srequest));
    }

    @Override
    @Transactional(readOnly = true)
    public Collection<T> searchAll(SearchRequest searchRequest) {
        return getConverter().toDTOs((Collection<Object>) getCrudService().searchAll(searchRequest).collect(Collectors.toList()));
    }
}
