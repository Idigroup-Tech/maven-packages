/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.model.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import org.springframework.data.domain.Page;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseDTO<D> {

    private D data;
    @Builder.Default
    private Collection<ResponseMessageDTO> messages = new ArrayList<>();

    private ResponseMetaDTO meta = new ResponseMetaDTO();

    public static <D> ResponseDTO<Collection<D>> createResponseDTO(Page<D> dto) {
        ResponseDTO<Collection<D>> response = new ResponseDTO<>();
        ResponseMetaDTO meta = new ResponseMetaDTO();

        //Pagination
        ResponsePaginationDTO pagination = new ResponsePaginationDTO();
        pagination.setPageSize(dto.getSize());
        pagination.setPageElements(dto.getNumberOfElements());
        pagination.setCurrentPage(dto.getPageable().getPageNumber());
        pagination.setTotalElements(dto.getTotalElements());
        pagination.setTotalPages(dto.getTotalPages());
        pagination.setFirst(dto.isFirst());
        pagination.setLast(dto.isLast());

        //Meta
        meta.setPagination(pagination);
        response.setMeta(meta);

        //FIXME IMPLEMENTARE??

        //Data
        response.setData(dto.getContent());
        return response;
    }

    public static <D> ResponseDTO<Collection<D>> createResponseDTO(List<D> dto) {
        ResponseDTO<Collection<D>> response = new ResponseDTO<>();
        //Pagination

        //Meta

        //Data
        response.setData(dto);
        return response;
    }

    public static <D> ResponseDTO<D> createResponseDTO(D dto) {
        ResponseDTO<D> response = new ResponseDTO<>();
        //Pagination

        //Meta

        //Data
        response.setData(dto);
        return response;
    }

    /*
    {
        "data": [] || {},
        "meta": {
            "filter":{}, 
            "sort":{},
            "pagination": {
                "total": 22,
                "count": 5,
                "per_page": 5,
                "current_page": 1,
                "total_pages": 5,
            }
        },
        messages: [{
            "code": 1121,
            "message": "Messaggio di qualcosa"
        }],
    }*/

}


