/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.dynacrud.model.dto.search;

import io.swagger.v3.oas.annotations.media.Schema;

//FIXME FS Gestire gli operatori in maniera agnostica (Riccardo chiedi a Remo se non capisci)
public enum FilterOperation {
    @Schema(description = "logical operator require sub filters, null field and null value")
    AND(true,false),
    @Schema(description = "logical operator require sub filters, null field and null value")
    OR(true, false),
    EQ,
    NEQ,
    @Schema(description = "require list value")
    IN,
    @Schema(description = "require list value")
    NOT_IN,
    LIKE,
    GT,
    GTE,
    LT,
    LTE,
    @Schema(description = "require null value")
    IS_NULL(false, false),
    @Schema(description = "require null value")
    IS_NOT_NULL(false, false);
    
    private boolean logic;
    private boolean valueRequired;

    private FilterOperation() {
        this.logic = false;
        this.valueRequired = true;
    }
    
    private FilterOperation(boolean logic, boolean valueRequired) {
        this.logic = logic;
        this.valueRequired = valueRequired;
    }

    public boolean isLogic() {
        return logic;
    }
    
    public boolean isValueRequired() {
        return valueRequired;
    }

}
