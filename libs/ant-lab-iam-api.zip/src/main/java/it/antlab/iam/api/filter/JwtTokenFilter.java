/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.filter;

import it.antlab.iam.core.authentication.TokenAuthentication;
import it.antlab.iam.core.conf.properties.JwtProperties;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by klayer3 on 21/03/22.
 */
@Component
public class JwtTokenFilter extends OncePerRequestFilter {

    @Autowired
    private JwtProperties jwtPropeties;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private HandlerExceptionResolver handlerExceptionResolver;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain)
            throws ServletException, IOException {

        try {
            // Get authorization header and validate
            final String header = request.getHeader(jwtPropeties.getHeader());
            if (StringUtils.isEmpty(header) || (StringUtils.isNoneEmpty(jwtPropeties.getHeaderValuePrefix()) && !header.startsWith(jwtPropeties.getHeaderValuePrefix()))) {
                chain.doFilter(request, response);
                return;
            }
            // Get jwt token and validate
            final String token = StringUtils.substringAfter(header, jwtPropeties.getHeaderValuePrefix());
            Authentication authentication = authenticationManager.authenticate(new TokenAuthentication(token));
            if (authentication != null) {
                SecurityContext context = SecurityContextHolder.createEmptyContext();
                context.setAuthentication(authentication);
                SecurityContextHolder.setContext(context);
                //SecurityContextHolder.getContext().setAuthentication(authentication)
            }

            chain.doFilter(request, response);
        } catch (Exception ex){
            ModelAndView maw = this.handlerExceptionResolver.resolveException(request, response, (Object) null, ex);
            if (maw == null) {
                throw new ServletException(ex.getMessage(), ex);
            }
        }
    }

}
