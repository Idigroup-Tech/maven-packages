/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.controller;

import it.antlab.iam.api.dto.TrxAddBody;
import it.antlab.iam.api.dto.TrxResponse;
import it.antlab.iam.api.facade.UserDTOFacade;
import it.antlab.iam.core.service.SSOService;
import it.antlab.iam.core.service.UserService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Objects;
import java.util.UUID;

/**
 * Created by klayer3 on 09/08/24
 */
@RestController
@RequestMapping("/custom-token")
@Tag(name = "Custom Token")
@Validated
@Slf4j
public class CustomTokenController {
    @Autowired
    private UserService userService;

    @Autowired
    private SSOService ssoService;

    @Autowired
    private UserDTOFacade userDTOFacade;

    @GetMapping("/{userId}")
    @Deprecated//FIXME DEVE DIVENTARE UNA POST più complessa con UnDTO che ci può permettere di Definire n cose ( se aggiungiamo i ruoli, se aggiungiamo i tag( CustomData) , Se ha ruoli custom da aggiungere ( two_factor_auth)...
    public ResponseEntity<String> customToken(@PathVariable UUID userId, @RequestParam(required = false, defaultValue = "firebase") String providerId) {
        return ResponseEntity.ok( userService.getCustomToken(userId, providerId));
    }

    @GetMapping("/sso/transaction/{trxId}")
    public ResponseEntity<String> customTokenByTrx(@PathVariable String trxId, @RequestParam(required = false, defaultValue = "firebase") String providerId, @RequestParam(required = false) UUID checkUserId,  @RequestParam(defaultValue = "true" , required = false) boolean failOnSameUser) {
        UUID userId= ssoService.consumeTransaction(trxId);

        if( failOnSameUser && checkUserId != null ) {
            if (Objects.equals(userId, checkUserId)) {
                    log.debug("trx userId match checkUserId. response is {}", HttpStatus.PRECONDITION_FAILED);
                    //"The user is already authenticated, custom token is not needed. (failOnSameUser = true)"
                    return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).build();
            } else {
                log.warn("checkUserId {} not match trx userId {}", checkUserId, userId);
            }
        }
        return ResponseEntity.ok( userService.getCustomToken(userId, providerId));
    }

    @PostMapping("/sso/transaction")
    //FIXME RIVEDERE
    public ResponseEntity<TrxResponse> createTrx(@Valid @RequestBody TrxAddBody trxAddBody) {
       return ResponseEntity.ok(userDTOFacade.getTrxResponse(trxAddBody));
    }
}
