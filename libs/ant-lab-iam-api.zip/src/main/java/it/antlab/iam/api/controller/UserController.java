/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.controller;

import it.antlab.iam.api.dto.*;
import it.antlab.iam.api.facade.UserDTOFacade;
import it.antlab.iam.core.dto.AddUserByProviderResult;
import it.antlab.iam.core.model.UserToken;
import com.fasterxml.jackson.databind.JsonNode;
import io.nettuno.dynacrud.base.Facade;
import io.nettuno.dynacrud.base.impl.DefaultSearchController;
import io.nettuno.dynacrud.model.dto.response.ResponseDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collection;
import java.util.Map;
import java.util.UUID;

/**
 * Created by klayer3 on 23/03/22.
 */
@RestController
@RequestMapping("/users")
@Tag(name = "Users")
public class UserController extends DefaultSearchController<UserDTO> {

    @Autowired
    private UserDTOFacade facade;

    @Override
    public Facade<UserDTO> getFacade() {
        return facade;
    }

    @PostMapping
    public ResponseEntity<ResponseDTO<UserDTO>> create(@Valid @RequestBody UserAdd dto) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.read(facade.insert(dto))));
    }

    @PostMapping("user-by-provider")
    //FIXME ALTRO CONTROLLER ALTRO FACADE
    public ResponseEntity<ResponseDTO<AddUserByProviderResult>> addUserByProvider(@Valid @RequestBody AddUserByProvider dto) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.insert(dto)));
    }

    @PatchMapping(value = "/{userId}/email-verification-link/{providerId}")
    //FIXME ALTRO CONTROLLER ALTRO FACADE
    public ResponseEntity<ResponseDTO<String>> emailVerificationLink(@PathVariable(required = true) UUID userId, @PathVariable(required = true) String providerId, @RequestParam(value = "callbackUrl", required = false) String callbackUrl) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.getEmailVerificationLink(userId, providerId, callbackUrl)));
    }

    @PatchMapping(value = "/{userId}/reset-password-link/{providerId}")

    public ResponseEntity<ResponseDTO<String>> resetPasswordLink(@PathVariable(required = true) UUID userId, @PathVariable(required = true) String providerId, @RequestParam(value = "callbackUrl", required = false) String callbackUrl) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.getResetPasswordLink(userId, providerId, callbackUrl)));
    }

    @PostMapping("/{userId}/reset-provider-password")
    //FIXME ALTRO CONTROLLER ALTRO FACADE
    public ResponseEntity<ResponseDTO<Boolean>> resetProviderPassword(@PathVariable UUID userId, @Valid @RequestBody ResetProviderPassword resetProviderPassword ){
        facade.resetProviderPassword(userId, resetProviderPassword);
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(true));
    }

    @PatchMapping(value = "/{userId}/password")
    public ResponseEntity<ResponseDTO<UserDTO>> editPassword(@PathVariable(required = true) UUID userId, @Valid @RequestBody UserEditPasswordDTO dto) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.editPassword(userId, dto)));
    }

    @PatchMapping(value = "/{userId}/custom-data")
    @Operation( requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(content = @Content(schema = @Schema(implementation = Map.class))))
    public ResponseEntity<ResponseDTO<UserDTO>> patchCustomData(@PathVariable(required = true) UUID userId, @RequestBody  JsonNode jsonNode) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.patchCustomData(userId, jsonNode)));
    }

    @PutMapping(value = "/{userId}/custom-data")
    public ResponseEntity<ResponseDTO<UserDTO>> editCustomData(@PathVariable(required = true) UUID userId, @RequestBody Map customData) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.saveCustomData(userId, customData)));
    }


    @GetMapping(value = {"/{userId}/tokens"})
    public ResponseEntity<ResponseDTO<Collection<UserToken>>> tokens(@PathVariable(required = true) UUID userId) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.getTokens(userId)));
    }

    @DeleteMapping(value = {"/{userId}/tokens/{tokenId}"})
    public ResponseEntity<ResponseDTO<UserToken>> deleteToken(@PathVariable(required = true) UUID userId, @PathVariable(required = true) UUID tokenId) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.deleteToken(userId, tokenId)));
    }

    @DeleteMapping(value = {"/{userId}"})
    public ResponseEntity<ResponseDTO<UserDTO>> delete(@PathVariable(required = true) UUID userId) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.delete(userId)));
    }

    @PostMapping(value = {"/{userId}/tokens"})
    public ResponseEntity<ResponseDTO<UserTokenCreatedDTO>> createToken(@PathVariable(required = true) UUID userId, @RequestParam(required = false) Long durationSeconds) {
        return ResponseEntity.ok(ResponseDTO.createResponseDTO(facade.generateToken(userId, durationSeconds)));
    }
}
