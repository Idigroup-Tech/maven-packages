/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.converter;

import it.antlab.iam.api.dto.UserDTO;
import it.antlab.iam.api.dto.UserProviderDTO;
import it.antlab.iam.api.mapper.UserDTOMapper;
import it.antlab.iam.core.model.Role;
import it.antlab.iam.core.model.User;
import it.antlab.iam.core.model.UserProvider;
import it.antlab.iam.core.service.UserProviderService;
import it.antlab.iam.core.service.UserService;
import io.nettuno.dynacrud.base.Converter;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

/**
 * Created by klayer3 on 24/03/22.
 */
@Component("UserDTOConverter")
public class UserDTOConverter implements Converter<UserDTO, User> {

    @Autowired
    private UserDTOMapper userDTOMapper;

    @Autowired
    private UserProviderService userProviderService;
    @Autowired
    private UserService userService;


    @Override
    public UserDTO toDTO(User entity, boolean full) {
        UserDTO ret= null;
        if( entity != null ){
            ret= userDTOMapper.toDTO(entity, full);
            if( full) {
              ret.setRoles(entity.getRoles().stream().map(Role::getId).collect(Collectors.toList()));
              ret.setProviders(userProviderService.getProvidersForUser(entity.getId()).stream().map(this::userProviderDTO).collect(Collectors.toList()));
              ret.setCustomData(userService.getCustomData(entity.getId()));
            }

        }
        return ret;
    }

    private UserProviderDTO userProviderDTO(UserProvider userProvider){
        UserProviderDTO ret = new UserProviderDTO();
        if( userProvider!= null){
            BeanUtils.copyProperties(userProvider, ret);
            return ret;
        }
        return null;
    }

    @Override
    public User fromDTO(UserDTO dto) {
        return userDTOMapper.fromDTO(dto);
    }


}
