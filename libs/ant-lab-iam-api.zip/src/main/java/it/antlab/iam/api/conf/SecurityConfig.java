/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.conf;

import com.fasterxml.jackson.databind.ObjectMapper;
import it.antlab.iam.api.filter.JwtTokenFilter;
import it.antlab.iam.core.authentication.providers.FirebaseAuthenticationProvider;
import it.antlab.iam.core.authentication.providers.TokenAuthenticationProvider;
import it.antlab.iam.core.enums.IAMRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * Created by klayer3 on 20/03/22.
 */
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
//@EnableConfigurationProperties(FirebaseProperties.class)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private static final String[] AUTH_WHITELIST = {
            // -- Swagger UI v2
            "/v2/api-docs",
            "/swagger-resources",
            "/swagger-resources/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui.html",
            "/webjars/**",
            // -- Swagger UI v3 (OpenAPI)
            "/v3/api-docs/**",
            "/swagger-ui/**"
            // other public endpoints of your API may be appended to this array
    };

    @Autowired(required = false)
    @Lazy
    private FirebaseAuthenticationProvider firebaseAuthenticationProvider;
    @Autowired(required = false)
    @Lazy
    private TokenAuthenticationProvider tokenAuthenticationProvider;

    @Autowired(required = false)
    @Lazy
    private JwtTokenFilter jwtTokenFilter;

    @Autowired
    private UserDetailsService userDetailsService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {

        auth.authenticationProvider(firebaseAuthenticationProvider);
        auth.authenticationProvider(tokenAuthenticationProvider);
        auth.userDetailsService( userDetailsService );


    }

    @Bean(name = BeanIds.AUTHENTICATION_MANAGER)
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // Enable CORS and disable CSRF
        //http = http.cors().and().csrf().disable();
        http = http.csrf().disable();

        // Set session management to stateless
        http = http
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and();

        // Set unauthorized requests exception handler
        http = http
                .exceptionHandling()
                .authenticationEntryPoint(
                        (request, response, ex) -> getErrorResponse(HttpStatus.UNAUTHORIZED, request, response)
                ).accessDeniedHandler(
                        (request, response, ex) -> getErrorResponse(HttpStatus.FORBIDDEN, request, response)
                ).and();

        // Set permissions on endpoints
        http.authorizeRequests()
                .antMatchers(AUTH_WHITELIST).permitAll()
                .antMatchers(HttpMethod.OPTIONS).permitAll()
                .antMatchers("/login" , "/token/login" ).permitAll()


                // Our public endpoints
                /*.antMatchers("/api/public/**").permitAll()
                .antMatchers(HttpMethod.GET, "/api/author/**").permitAll()
                .antMatchers(HttpMethod.POST, "/api/author/search").permitAll()
                .antMatchers(HttpMethod.GET, "/api/book/**").permitAll()
                .antMatchers(HttpMethod.POST, "/api/book/search").permitAll()*/
                // Our private endpoints
                .antMatchers("/users").hasAuthority(IAMRoles.IAM_ADMIN.name())
                .anyRequest().authenticated();

        // Add JWT token filter
        http.addFilterBefore(
                jwtTokenFilter,
                UsernamePasswordAuthenticationFilter.class
        );
    }


    private void getErrorResponse(HttpStatus status, HttpServletRequest request, HttpServletResponse response) throws IOException {
        Map errorResponse = Map.of("message", status.getReasonPhrase(), "status", status.value(), "path", request.getServletPath(), "code", status.value());
        ObjectMapper om = new ObjectMapper();
        om.writeValueAsString(errorResponse);
        response.setContentType("application/json");
        response.setStatus(status.value());
        response.getWriter().write(om.writeValueAsString(errorResponse));
        response.flushBuffer();
    }

    @Bean //FIXME MEGLIO DA APPLICAZIONE ESTERNA
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
