/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.facade;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonpatch.JsonPatchException;
import com.github.fge.jsonpatch.mergepatch.JsonMergePatch;
import io.nettuno.dynacrud.base.impl.DefaultFacade;
import it.antlab.iam.api.dto.*;
import it.antlab.iam.core.conf.CacheConfig;
import it.antlab.iam.core.dto.AddUserByProviderResult;
import it.antlab.iam.core.enums.IAMUserType;
import it.antlab.iam.core.model.*;
import it.antlab.iam.core.repository.RoleRepository;
import it.antlab.iam.core.service.SSOService;
import it.antlab.iam.core.service.UserRoleService;
import it.antlab.iam.core.service.UserService;
import it.antlab.iam.core.service.UserTokenService;
import it.antlab.utils.nassert.NAssert;
import it.antlab.utils.nassert.NAssertException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.*;

/**
 * Created by klayer3 on 23/03/22.
 */
@Service
@Slf4j
public class UserDTOFacade extends DefaultFacade<UserDTO> {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    @Cacheable(CacheConfig.Caches.User)
    public UserDTO read(Serializable id) {
        return super.read(id);
    }
    @Autowired
    @Lazy
    private PasswordEncoder passwordEncoder;
    @Autowired
    private UserRoleService userRoleService;
    @Autowired
    private UserTokenService userTokenService;
    @Autowired
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private SSOService ssoService;

    @Transactional
    public UUID insert(UserAdd dto) {
        UserDTO userDTO = new UserDTO();
        BeanUtils.copyProperties(dto,  userDTO); // FIXME PASSARE PER CONVERTEER
        if( dto.getUserType() != null){
            NAssert.state(!IAMUserType.PROVIDER.equals(dto.getUserType()), "userType PROVIDER not allowed");

        }
        if( dto.getPassword() != null){
            NAssert.state(!IAMUserType.APPLICATION.equals(dto.getUserType()), "password not allowed for userType APPLICATION");
            userDTO.setPassword(passwordEncoder.encode(checkPassword(dto.getPassword())));
            //is only BASIC enabled...
            userDTO.setUserType(ObjectUtils.defaultIfNull(dto.getUserType(), IAMUserType.BASIC));
        }

        User newUser = (User) getConverter().fromDTO(userDTO);
        newUser.setSecret(userDTO.getPassword());

        UUID userID = ((User) getCrudService().insert(newUser)).getId();

        if(!CollectionUtils.isEmpty( dto.getRoles())){
            insertRoles( dto.getRoles(), userID);
        }

        userService.saveCustomData(newUser.getId(), dto.getCustomData());
        return userID;

    }

    private String checkPassword(String password) {
        NAssert.state(StringUtils.isNotEmpty(StringUtils.trim(password)), "iam/invalid_password");
        //FIXME K3 aggiungere check in base alla configurazione -> magari con un componente password Validator...
        return password;
    }
    @Transactional
    public UserDTO editPassword(UUID userId, UserEditPasswordDTO dto) {
        User user = (User)getCrudService().read(userId);
        NAssert.state(
                user != null && passwordEncoder.matches( dto.getCurrentPassword(), user.getSecret()),
                "iam/invalid_current_password");

        user.setSecret(dto.getNewPassword() != null ? passwordEncoder.encode(checkPassword(dto.getNewPassword())) : null);

        return getConverter().toDTO(getCrudService().update(user, userId)) ;

    }

    @Transactional
    public List<UserToken> getTokens(UUID userId) {
        return userTokenService.getTokens(userId);
    }

    @Transactional
    public UserToken deleteToken(UUID userId, UUID tokenId) {
        return userTokenService.deleteToken(userId, tokenId);
    }
    @Transactional
    public UserTokenCreatedDTO generateToken(UUID userId, Long durationSeconds) {
        UserToken created = userTokenService.generateToken(userId, durationSeconds);
        return UserTokenCreatedDTO.builder()
                .details(created)
                .token(created.getToken())
                .build();
    }

    @Transactional
    @CacheEvict(cacheNames = CacheConfig.Caches.User, allEntries = true)  //FIXME--verifica //perchè tutte
    //@CacheEvict(cacheNames = {CacheConfig.Caches.User, CacheConfig.Caches.TokenLogin}, allEntries = true)  //FIXME--verifica //perchè tutte vedi TrackingAuthorizationStatusFacade -> PassiveExpiringMap
    public UserDTO patchCustomData(UUID userId, JsonNode jsonNode) {
        try {
            Map<String, ?> customData = ObjectUtils.firstNonNull(userService.getCustomData(userId), new HashMap<>());
            NAssert.state(jsonNode.size() != 0, "INVALID_JSON");

            final JsonMergePatch patch = JsonMergePatch.fromJson(jsonNode);
            // orig is also a JsonNode
            final JsonNode patched = patch.apply(objectMapper.convertValue(customData, JsonNode.class));
            // applico
            Map newData = objectMapper.convertValue(patched, Map.class);
            return saveCustomData(userId, newData);


        }catch (JsonPatchException e){
            throw NAssertException.builder("INVALID_JSON").message(e.getMessage()).cause(e).build();
        }
    }
    @Transactional
    @CacheEvict(cacheNames = CacheConfig.Caches.User, allEntries = true)  //FIXME--verifica //perchè tutte
    //@CacheEvict(cacheNames = {CacheConfig.Caches.User, CacheConfig.Caches.TokenLogin}, allEntries = true)  //FIXME--verifica //perchè tutte vedi TrackingAuthorizationStatusFacade -> PassiveExpiringMap
    public UserDTO saveCustomData(UUID userId, Map customData) {
        NAssert.state(userService.read(userId) != null, new ResponseStatusException(HttpStatus.NOT_FOUND));
        userService.saveCustomData(userId, customData);
        return read(userId);
    }



    @Transactional
    public AddUserByProviderResult insert(AddUserByProvider userByProvider) {
        UserProvider userProvider = new UserProvider();
        userProvider.setProviderId(userByProvider.getProviderId());
        userProvider.setEmail(userByProvider.getEmail());
        userProvider.setDisplayName(userByProvider.getDisplayName());
        final AddUserByProviderResult userByProviderResult = userService.insert(userProvider, userByProvider.getCallbackUrl(), userByProvider.isNeedPwdReset(), userByProvider.isNeedEmailVerification(), userByProvider.getPassword() );
        if(!CollectionUtils.isEmpty(userByProvider.getRoles())){
            insertRoles(userByProvider.getRoles(), userByProviderResult.getUserId());
        }

        if( !CollectionUtils.isEmpty(userByProvider.getCustomData())){
            final Map<String,Object> customData = Optional.ofNullable(userService.getCustomData(userByProviderResult.getUserId())).orElse(new HashMap<>());
            userByProvider.getCustomData().forEach( (k, v) -> {
                    if(v != null){
                        customData.put(k, v);
                    }
            });
            userService.saveCustomData(userByProviderResult.getUserId(), customData);
        }


        return userByProviderResult;
    }

    private void insertRoles(List<String> roles, UUID userId){
      roles.stream()
                .filter( r -> StringUtils.isNotEmpty(StringUtils.trim(r)))
                .map( r -> {
                    Role role =  roleRepository.findById(r).orElseThrow( () -> NAssertException.builder("roles/role-not-found-by-id").message(String.format("%s role not found", r)).build());
                    NAssert.state(role.isNotObsolete(), "roles/role-is-obsolete");
                    return role;
                })
                .map(r -> {
                    UserRole userRole = new UserRole();
                    userRole.setRoleId(r.getId());
                    userRole.setUserId(userId);
                    return userRole;
                }).forEach( userRole -> userRoleService.insert(userRole));
    }

    @Transactional
    public String getEmailVerificationLink(UUID userId, String providerId, String callbackUrl) {
        UserDTO userDTO = Optional.ofNullable(read(userId)).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        checkProvider(providerId, userDTO);

        return userService.getEmailVerificationLink(userId, providerId, callbackUrl);

    }

    private static void checkProvider(String providerId, UserDTO userDTO) {
        log.info("userProviders size: {}", userDTO.getProviders().size());
        boolean existsProvider = userDTO.getProviders().stream().anyMatch(up ->Objects.equals(up.getProviderId(), providerId));
        log.info("{} provider exists {}", providerId, existsProvider );
        if(!existsProvider) {
            userDTO.getProviders().forEach(up -> log.info("{} not found: providers {} ", providerId,  up.getProviderId()));
            throw  NAssertException.builder("iam/invalid-provider-for-user").build();
        }
    }

    @Transactional
    public String getResetPasswordLink(UUID userId, String providerId, String callbackUrl) {
        UserDTO userDTO = Optional.ofNullable(read(userId)).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

       checkProvider(providerId, userDTO);

        return userService.getResetPasswordLink(userId, providerId, callbackUrl);

    }


    @Transactional
    @CacheEvict(cacheNames = CacheConfig.Caches.User, allEntries = true) //perchè tutte
    public UserDTO delete(UUID id) {
        User en = userService.delete(id);
        return this.getConverter().toDTO(en);
    }

    @Override
    @Transactional
    public UserDTO delete(Serializable id) {
        return this.delete((UUID)id);
    }

    @Transactional
    public TrxResponse getTrxResponse(@Valid TrxAddBody trxAddBody) {
        TrxResponse trxResponse = new TrxResponse();
        trxResponse.setTrxId(ssoService.createTransaction(trxAddBody.getUserId()));
        if( trxAddBody.isNeedUser()){
            trxResponse.setUser(read(trxAddBody.getUserId()));
        }
        return trxResponse;
    }

    @Transactional
    public void resetProviderPassword(UUID userId, @Valid ResetProviderPassword resetProviderPassword) {
        userService.resetProviderPassword(userId, resetProviderPassword.getProviderId(), resetProviderPassword.getPassword());
    }
}
