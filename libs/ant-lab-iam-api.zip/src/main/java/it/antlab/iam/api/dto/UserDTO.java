/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.nettuno.dynacrud.base.TargetType;
import io.swagger.v3.oas.annotations.Hidden;
import it.antlab.iam.core.enums.IAMUserType;
import it.antlab.iam.core.model.User;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by klayer3 on 23/03/22.
 */
@TargetType(User.class)
@Getter
@Setter
@EqualsAndHashCode(of="id")
public class UserDTO {
    private UUID id;
    private String username;
    private boolean obsolete= false;
    private boolean enabled = true;
    private boolean locked = false;
    private IAMUserType userType;
    @Hidden
    @JsonIgnore()
    private String password;
    private boolean hasPassword;
    private Map<String,?> customData;
    private List<String> roles = new ArrayList<>();
    private List<UserProviderDTO> providers = new ArrayList<>();

}
