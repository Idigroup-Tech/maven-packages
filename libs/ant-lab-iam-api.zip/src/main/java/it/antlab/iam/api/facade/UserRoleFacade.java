/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.facade;

import io.nettuno.dynacrud.base.impl.DefaultFacade;
import it.antlab.iam.api.dto.UserRoles;
import it.antlab.iam.core.conf.CacheConfig;
import it.antlab.iam.core.model.UserRole;
import it.antlab.iam.core.service.UserRoleService;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 23/03/22.
 */
@Service("UserRoleFacade")
@RequiredArgsConstructor
public class UserRoleFacade extends DefaultFacade<UserRole> {
    private final UserRoleService userRoleService;
    @Override
    @CacheEvict(cacheNames = CacheConfig.Caches.User, allEntries = true)
    public UserRole insert(UserRole userRole) {
        return super.insert(userRole);
    }

    @Override
    @CacheEvict(cacheNames = CacheConfig.Caches.User, allEntries = true)
    public UserRole update(UserRole userRole, Serializable id) {
        return super.update(userRole, id);
    }

    @Override
    //FIXME  peccato, sono costretto a pulire tutta la cache... magari faccio un metodo apposito
    @CacheEvict(cacheNames = CacheConfig.Caches.User, allEntries = true)
    public UserRole delete(Serializable id) {
        return super.delete(id);
    }

    @CacheEvict(cacheNames = CacheConfig.Caches.User, allEntries = true)
    @Transactional
    public UserRoles updateMultiple(UUID userId, UserRoles roles) {
          return UserRoles.builder().roles(userRoleService.updateMultiple(userId, roles.getRoles()).stream().map(UserRole::getRoleId).collect(Collectors.toSet())).build();
    }
}
