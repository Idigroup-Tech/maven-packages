/*
 * Copyright 2025 Ant Lab S.R.L.
 * Author: Riccardo Mohamed
 * Email: riccardo.mohamed@gmail.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package it.antlab.iam.api.mapper;

import it.antlab.iam.api.dto.UserDTO;
import it.antlab.iam.core.model.Role;
import it.antlab.iam.core.model.User;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 24/03/22.
 */
@Mapper(componentModel = "spring")
public interface UserDTOMapper {
    @Mapping( source ="entity.secret", target="hasPassword")
    @Mapping( source ="entity.secret", target="password")
    UserDTO toDTO(User entity, boolean full);

    @Mapping(ignore = true, target = "roles")
    User fromDTO(UserDTO dto);

    default boolean secretToHasPassword(String secret) {
        return StringUtils.isNotEmpty(StringUtils.trim(secret));
    }

    default List<String> map(List<Role> role){
        return role.stream().filter(Objects::nonNull).filter(r -> !r.isObsolete()).map(this::roleToString).collect(Collectors.toList());
    }

    default String roleToString( Role role){
        if( role != null) {
            return role.getId();
        }
        return null;
    }
}
