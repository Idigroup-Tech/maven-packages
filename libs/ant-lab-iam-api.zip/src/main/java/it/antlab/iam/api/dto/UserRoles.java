package it.antlab.iam.api.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.util.Set;

/**
 * Created by klayer3 on 19/07/25
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserRoles {
    @NotEmpty
    private Set<String> roles;
}
