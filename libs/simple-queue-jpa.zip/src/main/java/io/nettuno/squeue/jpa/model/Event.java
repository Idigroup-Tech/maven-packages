/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.squeue.jpa.model;


import io.nettuno.squeue.model.EventStatus;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "event", indexes = {
        @Index(name = "idx_event_obsolete", columnList = "obsolete"),
        @Index(name = "idx_event_type", columnList = "event_type"),
        @Index(name = "idx_event_group", columnList = "event_group"),
        @Index(name = "idx_event_hash", columnList = "hash")
}
)
@EntityListeners(AuditingEntityListener.class)
public class Event implements io.nettuno.squeue.model.Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "event_type", updatable = false, insertable = true, length = 40)
    private String type;

    @Column(name = "event_group", nullable = false, updatable = false)
    private int group;

    //@Id
    @Column(name = "obsolete", nullable = false)
    private boolean obsolete = false;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private EventStatus status = EventStatus.NEW;

    @Lob
    @Column(name = "body", nullable = false, updatable = false)
    private String body;

    @Column(name = "hash", nullable = false, updatable = false, length = 40)
    private String hash;

    @Column(name = "wait_until")
    private LocalDateTime waitUntil;

    @Column(name = "date_created", nullable = true, updatable = false)
    @CreatedDate
    private LocalDateTime dateCreated;

    @Column(name = "modified_date")
    @LastModifiedDate
    private LocalDateTime modifiedDate;

    @Column(name = "created_by", nullable = true, updatable = false)
    @CreatedBy
    private String createdBy = "system";

    @Column(name = "execution_counter")
    private int executionCounter = 0;

    @Version
    @Column(name = "version")
    private Long version;

	/*@Lob
	@Column(name = "attributes", nullable = true, updatable = false)
	private String attributes;

	FIXME K3 ragioniamo bene sugli attributi: se li passiamo dovremmo conservare il più aggiornato a parità di hash non fare il contrario come avviene adesso
	 */

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
    }

    @Override
    public boolean isObsolete() {
        return obsolete;
    }

    public void setObsolete(boolean obsolete) {
        this.obsolete = obsolete;
    }

    @Override
    public EventStatus getStatus() {
        return status;
    }

    public void setStatus(EventStatus status) {
        this.status = status;
    }

    @Override
    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    @Override
    public String getHash() {
        return hash;
    }

    @Override
    public void setHash(String hash) {
        this.hash = hash;
    }

    @Override
    public LocalDateTime getWaitUntil() {
        return waitUntil;
    }

    @Override
    public void setWaitUntil(LocalDateTime waitUntil) {
        this.waitUntil = waitUntil;
    }

    public LocalDateTime getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(LocalDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }

    public LocalDateTime getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(LocalDateTime modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public int getExecutionCounter() {
        return executionCounter;
    }

    public void setExecutionCounter(int executionCounter) {
        this.executionCounter = executionCounter;
    }

	/*
	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}
	*/

    @Override
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Event event = (Event) o;

        return id != null ? id.equals(event.id) : event.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Event{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", group=" + group +
                ", obsolete=" + obsolete +
                ", status=" + status +
                ", body='" + body + '\'' +
                ", hash='" + hash + '\'' +
                ", waitUntil=" + waitUntil +
                ", executionCounter=" + executionCounter +
                '}';
    }
}

