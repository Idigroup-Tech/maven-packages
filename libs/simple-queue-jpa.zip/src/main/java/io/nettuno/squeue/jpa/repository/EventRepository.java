/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.squeue.jpa.repository;

import io.nettuno.squeue.jpa.model.Event;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Repository
@ConditionalOnProperty(
		value="io.nettuno.squeue.jpa.EventRepository.enabled",
		havingValue = "true",
		matchIfMissing = true)
public interface EventRepository extends JpaRepository<Event, Long> {
	@Query(
		"select ev from Event ev " +
		"where ev.obsolete = false " +
		"and ev.group = :group " +
		"and ev.id > :last_id " +
		"order by ev.id asc ")
	Slice<Event> getForProcess(@Param("group") int group, @Param("last_id") Long lastId, Pageable pageable);

//	@Query(
//			"select ev from Event ev " +
//					"where ev.obsolete = false " +
//					"and ev.group = :group " +
//					"and ev.id > :last_id " +
//					"and ev.waitUntil is null " +
//					"order by ev.id asc " +
//					"union " +
//					"select ev from Event ev " +
//					"where ev.obsolete = false " +
//					"and ev.group = :group " +
//					"and ev.id > :last_id " +
//					"and ev.waitUntil < :processableFrom " +
//					"order by ev.id asc " )
	@Query(
			"select ev from Event ev " +
					"where ev.obsolete = false " +
					"and ev.group = :group " +
					"and ev.id > :last_id " +
					"and coalesce(ev.waitUntil, :processableFrom) <= :processableFrom " +
					"order by ev.id asc ")
	Slice<Event> getForProcess(@Param("group") int group, @Param("last_id") Long lastId, LocalDateTime processableFrom, Pageable pageable);

	/*@Transactional
	@Modifying
	@Query("update Event ev set ev.obsolete = true, ev.status = :ev_status, ev.modifiedDate = CURRENT_TIMESTAMP, ev.executionCounter = ev.executionCounter +1  where ev.id = :event_id and ev.obsolete = false ")
	int setStatusAndObsolete(@Param("event_id") Long eventId, @Param("ev_status") EventStatus status );*/

	@Modifying
	@Transactional
	//FIXME test performance
	@Query(value =
			"update event oe " +
			"set oe.obsolete = 1 " +
			"where oe.obsolete = 0 " +
			"and oe.event_group = :group_id " +
			"and exists ( select 1 from event e where e.obsolete = 0 and e.event_group = oe.event_group and e.hash = oe.hash and e.id < oe.id and e.id in :ids ) "	,
	nativeQuery = true)
	/*@Query(value =
			" update event e " +
					" join event ee on (ee.obsolete = 0 and e.event_group = ee.event_group  and e.hash = ee.hash ) " +
					" set ee.obsolete = 1 " +
					" where e.obsolete = 0 " +
					"  and e.event_group = :group_id " +
					"  and e.id < ee.id " +
					" and e.id in (:ids) ", nativeQuery = true)*/
	int removeDuplicatedEvents(@Param("ids") List<Long> ids , @Param("group_id") int group_id);

	@Modifying
	@Transactional
	@Query(value =
			"update Event oe " +
					"set oe.obsolete = true, oe.modifiedDate = :updateDateTime " + //FIXME POTREMMO METTERE LO STATO?
					"where oe.obsolete = false " +
					"and oe.group = :group_id " +
					"and exists ( select e.id from Event e where e.obsolete = false and e.group = oe.group and e.hash = oe.hash and e.id < oe.id and e.id in :ids ) "
			)
	int removeDuplicatedEvents(@Param("ids") List<Long> ids , @Param("group_id") int group_id, LocalDateTime updateDateTime);
}
