/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.squeue.jpa.service;

import io.nettuno.squeue.jpa.model.Event;
import io.nettuno.squeue.jpa.repository.EventRepository;
import io.nettuno.squeue.model.EventStatus;
import io.nettuno.squeue.service.impl.AbstractEventGroupProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.data.repository.CrudRepository;

import javax.persistence.OptimisticLockException;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.stream.Collectors;

/**
 * Created by klayer3 on 24/08/20.
 */
public class JPAEventGroupProcessor extends AbstractEventGroupProcessor<Event> {

    @Autowired
    private EventRepository eventRepository;


    public JPAEventGroupProcessor(int group) {
        super(group);
    }

    @Override
    protected CrudRepository<Event, Serializable> getRepository() {
        return (CrudRepository) eventRepository;
    }

    @Override
    protected void onError(Event event, Exception e) {
        if(OptimisticLockException.class.isAssignableFrom(e.getClass())){
            getLog().info("{}: event {} was modified by another thread", e, event );
            return;
        }

        setStatus(EventStatus.ERROR, null,  event);
    }

    @Override
    protected void onStatusChange(Event event, EventStatus status) {
        if(!EventStatus.RUNNING.equals(status)) {
            incrementCounter(event);
        }
    }

    protected void incrementCounter(Event event) {
        event.setExecutionCounter(event.getExecutionCounter() + 1);
        save(event);
    }

    @Override
    @Deprecated
    protected String getTypeName(Event event) {
        return event.getType();
    }


    @Override
    protected int removeDuplicates(Collection<Event> events) {
        return eventRepository.removeDuplicatedEvents(events.stream().map(Event::getId).collect(Collectors.toList()) , this.getGroup(),  LocalDateTime.now());
    }

    @Override
    protected Slice<Event> getNextPage(Event lastEvent) {
        return eventRepository.getForProcess(this.getGroup(),  lastEvent !=null && lastEvent.getId() != null ? lastEvent.getId() : Long.MIN_VALUE, LocalDateTime.now(),  PageRequest.of(0 , getPageSize()));
    }

    @Override
    protected boolean canProcessRunningEvent(Event event) {
        if( EventStatus.RUNNING.equals(event.getStatus())) {
            if( !event.getModifiedDate().isBefore(LocalDateTime.now().minusSeconds(getRunningEventMaxSeconds()))){
                getLog().info("event {} is already running, process skipped ", event );
                return false;
            }
        }
        return true;
    }

    private long getRunningEventMaxSeconds() {
        return 600;
    }
}
