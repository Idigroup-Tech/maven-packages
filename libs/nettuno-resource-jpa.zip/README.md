# nettuno-resource-jpa

Modulo resource 