/*
 *
 *  * Copyright 2023–2025 Riccardo Mohamed
 *  * Email: riccardo.mohamed@gmail.com
 *  *
 *  * Licensed under the Apache License, Version 2.0 (the "License");
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  *
 *  *     http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  * Unless required by applicable law or agreed to in writing, software
 *  * distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package io.nettuno.resource.jpa.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.nettuno.resource.exception.InvalidContextException;
import io.nettuno.resource.jpa.model.JpaBucket;
import io.nettuno.resource.jpa.model.JpaResource;
import io.nettuno.resource.jpa.model.JpaResourceId;
import io.nettuno.resource.jpa.model.JpaResourceTag;
import io.nettuno.resource.jpa.repository.JpaBucketRepository;
import io.nettuno.resource.jpa.repository.JpaResourceRepository;
import io.nettuno.resource.jpa.repository.JpaTagRepository;
import io.nettuno.resource.model.*;
import io.nettuno.resource.service.ResourceService;

import it.antlab.utils.nassert.NAssert;
import it.antlab.utils.nassert.NAssertException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Created by klayer3 on 25/05/21.
 */
@Service
public class JpaResourceService implements ResourceService {

    @Autowired
    private Environment environment;

    @Autowired
    private JpaResourceRepository jpaResourceRepository;

    @Autowired
    private JpaBucketRepository jpaBucketRepository;

    @Autowired
    private JpaTagRepository jpaTagRepository;

    @Autowired
    private ObjectMapper mapper;

    @PersistenceContext
    private EntityManager entityManager;

    private Set<String> allowedContexts= new HashSet<>();



    @PostConstruct
    private void init(){
        //potremmo farlo diretto alla creazione del mongo client
        allowedContexts.addAll(Arrays.asList(StringUtils.split(environment.getProperty("nettuno.resource.contexts", getDefaultContext()))));
    }

    @Override
    public Resource get(ResourceId inputResourceId) {
        NAssert.state(ObjectUtils.isNotEmpty(inputResourceId) && StringUtils.isNotEmpty(inputResourceId.getId()), "resource_id_required", "ResourceId.id required in get operation");
        final ResourceId resourceId = getResourceId(inputResourceId);
        Optional<JpaResource> jpaResource =  jpaResourceRepository.findById(new JpaResourceId(resourceId.getContext(), resourceId.getEntity(), resourceId.getId()));
        if(jpaResource.isPresent()){
            return  getBasicResource(inputResourceId, jpaResource.get());
        }
        return  null;
    }

    @Override
    public InputStream getContent(ResourceId inputResourceId) {
        NAssert.state(ObjectUtils.isNotEmpty(inputResourceId) && StringUtils.isNotEmpty(inputResourceId.getId()), "resource_id_required", "ResourceId.id required in get operation");
        final ResourceId resourceId = getResourceId(inputResourceId);
        Optional<JpaResource> jpaResource =  jpaResourceRepository.findById(new JpaResourceId(resourceId.getContext(), resourceId.getEntity(), resourceId.getId()));
        if(jpaResource.isPresent() && jpaResource.get().getBucketId() != null){
            Optional<JpaBucket> jpaBucketOptional = jpaBucketRepository.findById(jpaResource.get().getBucketId());
            NAssert.state(jpaBucketOptional.isPresent(), "cannot_found_bucket");

            // FIXME K3 deve essere già un inputStream
            try {
                return jpaBucketOptional.get().getData().getBinaryStream();
            } catch (SQLException e) {
                throw NAssertException.builder("error-reading-content").message(e.getMessage()).build();
            }
        }
        return null;
    }


    //FIXME pensare a modifica dei soli meta! senza impattare sul file
    @Override
    @Transactional
    public ResourceId save(ResourceSave resourceSave) {
        NAssert.state(ObjectUtils.isNotEmpty(resourceSave.getResource()) , "resource_required", "ResourceSave required in save operation");

        Resource resource = resourceSave.getResource();
        ResourceId inputResourceId = resource.getResourceId() != null ? resource.getResourceId() : ResourceId.builder().build();
        final ResourceId resourceId = getResourceId(inputResourceId);

        JpaResource jpaResource = new JpaResource();

        //modifica o creazione
        jpaResource = jpaResourceRepository.findById(new JpaResourceId(resourceId.getContext(), resourceId.getEntity(), resourceId.getId())).orElse(jpaResource);
        if (!resourceSave.isOnlyMeta()) {
            UUID oldBucketId = jpaResource.getBucketId();
            if (oldBucketId != null) {
                jpaBucketRepository.deleteById(oldBucketId);
                jpaResource.setBucketId(null);
            }
        }
        if(jpaResource.getTagsRef()!=null)
        {
            jpaTagRepository.deleteAllByTagsRef(jpaResource.getTagsRef());
            jpaResource.setTagsRef(null);
        }


        jpaResource.setContext(resourceId.getContext());
        jpaResource.setEntity(resourceId.getEntity());
        jpaResource.setOrder(resource.getOrder());
        if(StringUtils.isEmpty(jpaResource.getId())){
            //imposto id s
            jpaResource.setId(ObjectUtils.firstNonNull(resourceId.getId(),UUID.randomUUID().toString()));
        }
        if(resource.getMeta()!= null){
            try {
                jpaResource.setMeta(mapper.writeValueAsString(resource.getMeta()));
            } catch (JsonProcessingException e) {
                throw  NAssertException.builder("invalid_meta_serialization").message(e.getMessage()).cause(e).build();
            }
        } else {
            jpaResource.setMeta(null);
        }
        jpaResource.setContentType(getContentType(resourceSave));
        if(!resourceSave.isOnlyMeta()) {
            jpaResource.setBucketId(createBucket(resourceSave));
            jpaResource.setContentLength(resourceSave.getResource().getContentLength());
        }

        if(!CollectionUtils.isEmpty(resource.getTags())){

            final Collection<String> inputTags = resource.getTags();
            //salvataggio tags
            saveTags(jpaResource, inputTags);
        }


        return ResourceId.builder().context(resourceId.getContext()).entity(resourceId.getEntity()).id(jpaResourceRepository.save(jpaResource).getId()).build();
    }

    private void saveTags(JpaResource jpaResource, Collection<String> inputTags) {
        Set<String> tags = new LinkedHashSet<>(inputTags.stream().filter(t -> StringUtils.isNotEmpty(StringUtils.trim(t))).collect(Collectors.toList())) ;
        if( !CollectionUtils.isEmpty(tags)){
            UUID tagsRef = UUID.randomUUID();
            jpaResource.setTagsRef(tagsRef);
            jpaTagRepository.saveAll(tags.stream().map( t -> {
                JpaResourceTag resourceTag = new JpaResourceTag();
                resourceTag.setTag(t);
                resourceTag.setTagsRef(tagsRef);
                return  resourceTag;
            }).collect(Collectors.toList()));
        }
    }

    @Override
    @Transactional
    public void remove(ResourceId inputResourceId) {
        NAssert.state(ObjectUtils.isNotEmpty(inputResourceId) && StringUtils.isNotEmpty(inputResourceId.getId()), "resource_id_required", "ResourceId.id required in remove operation");
        final ResourceId resourceId = getResourceId(inputResourceId);
        JpaResourceId jpaResourceId =  new JpaResourceId(resourceId.getContext(), resourceId.getEntity(), resourceId.getId());
        Optional<JpaResource> optionalJpaResource= jpaResourceRepository.findById(jpaResourceId);
        if(optionalJpaResource.isPresent()){
            JpaResource jpaResource = optionalJpaResource.get();
            if(jpaResource.getBucketId() != null) {
                jpaBucketRepository.deleteById(jpaResource.getBucketId());
            }
            jpaResourceRepository.deleteById(jpaResourceId);
        }

    }

    @Override
    public Collection<Resource> search(ResourceSearch resourceSearch) {
        final ResourceId inputResourceId = resourceSearch.getResourceId() != null ? resourceSearch.getResourceId() : ResourceId.builder().build();
        final ResourceId resourceId = getResourceId(inputResourceId);

        if(StringUtils.isNotEmpty(resourceId.getId())){
            Optional<JpaResource> jpaResourceOp = jpaResourceRepository.findById(new JpaResourceId(resourceId.getContext(), resourceId.getEntity(), resourceId.getId()));
            if( jpaResourceOp.isPresent()) {
                return Collections.singletonList(getBasicResource(inputResourceId, jpaResourceOp.get()));
            }
            return null;
        } else {
            Pageable pageable = PageRequest.of(resourceSearch.getPageNumber(), resourceSearch.getPageSize(), Sort.by(resourceSearch.isAscending() ? Sort.Direction.ASC : Sort.Direction.DESC, "order","lastUpdateTime" ));

            if(!CollectionUtils.isEmpty(resourceSearch.getTags())) {
                Set<String> tags = resourceSearch.getTags().stream().filter( t -> StringUtils.isNotEmpty(StringUtils.trim(t))).collect(Collectors.toSet()) ;

                return jpaResourceRepository.searchByTags(resourceId.getContext(), resourceId.getEntity(), tags, pageable).stream().map(r -> getBasicResource(ResourceId.builder().id(r.getId()).entity(r.getEntity()).context(r.getContext()).build(), r)).collect(Collectors.toList());
            } else {
                return jpaResourceRepository.searchByContextAndEntity(resourceId.getContext(), resourceId.getEntity(),  pageable).stream().map(r -> getBasicResource(ResourceId.builder().id(r.getId()).entity(r.getEntity()).context(r.getContext()).build(), r)).collect(Collectors.toList());
            }
        }



    }

    @Override
    @Transactional
    public void addTags(ResourceId inputResourceId, List<String> inputTags) {
        NAssert.state(ObjectUtils.isNotEmpty(inputResourceId) && StringUtils.isNotEmpty(inputResourceId.getId()), "resource_id_required", "ResourceId.id required in remove operation");
        NAssert.state(!CollectionUtils.isEmpty(inputTags), "tags-required");
        final ResourceId resourceId = getResourceId(inputResourceId);
        JpaResourceId jpaResourceId =  new JpaResourceId(resourceId.getContext(), resourceId.getEntity(), resourceId.getId());
        JpaResource jpaResource= jpaResourceRepository.findById(jpaResourceId).orElseThrow( () -> NAssertException.builder("resource-be-existing-resource").build());

        List<String> allTags = new ArrayList<>();

        if( jpaResource.getTagsRef() != null){
            allTags.addAll(jpaTagRepository.getAllByTagsRef(jpaResource.getTagsRef()).stream().map( JpaResourceTag::getTag).collect(Collectors.toList()));
            jpaTagRepository.deleteAllByTagsRef(jpaResource.getTagsRef());
            jpaResource.setTagsRef(null);
        }
        allTags.addAll(inputTags);
        saveTags(jpaResource, allTags);
    }

    @Override
    @Transactional
    public void removeTags(ResourceId inputResourceId, List<String> inputTags) {
        NAssert.state(ObjectUtils.isNotEmpty(inputResourceId) && StringUtils.isNotEmpty(inputResourceId.getId()), "resource_id_required", "ResourceId.id required in remove operation");
        NAssert.state(!CollectionUtils.isEmpty(inputTags), "tags-required");
        final ResourceId resourceId = getResourceId(inputResourceId);
        JpaResourceId jpaResourceId =  new JpaResourceId(resourceId.getContext(), resourceId.getEntity(), resourceId.getId());
        JpaResource jpaResource= jpaResourceRepository.findById(jpaResourceId).orElseThrow( () -> NAssertException.builder("resource-be-existing-resource").build());

        List<String> allTags = new ArrayList<>();

        if( jpaResource.getTagsRef() != null){
            allTags.addAll(jpaTagRepository.getAllByTagsRef(jpaResource.getTagsRef()).stream().map( JpaResourceTag::getTag).collect(Collectors.toList()));
            jpaTagRepository.deleteAllByTagsRef(jpaResource.getTagsRef());
            jpaResource.setTagsRef(null);
        }
        allTags.removeAll(inputTags);
        saveTags(jpaResource, allTags);
    }

    private ResourceId getResourceId(ResourceId inputResourceId) {
        if( inputResourceId == null) inputResourceId = ResourceId.builder().build();
        ResourceId ret = ResourceId.builder()
                .context(StringUtils.isNotEmpty(inputResourceId.getContext()) ? inputResourceId.getContext() : getDefaultContext())
                .entity(StringUtils.isNotEmpty(inputResourceId.getEntity()) ? inputResourceId.getEntity() : environment.getProperty("nettuno.resource.defaultEntity", "defaultEntity"))
                .id(inputResourceId.getId()).build();

        NAssert.state(allowedContexts.contains(ret.getContext()), new InvalidContextException(ret.getContext()));

        return ret;
    }

    private String getDefaultContext() {
        return environment.getProperty("nettuno.resource.defaultContext","defaultContext");
    }

    private BasicResource getBasicResource(ResourceId resourceId, JpaResource jpaResource) {
        BasicResource.BasicResourceBuilder builder = BasicResource.builder()
                .resourceId(resourceId)
                .order(jpaResource.getOrder())
                .lastUpdate(jpaResource.getLastUpdateTime())
                .contentLength(jpaResource.getContentLength())
                //.meta(jpaResource.getMeta())
                .contentType(jpaResource.getContentType());

        if(jpaResource.getTagsRef()!= null){
            builder.tags(jpaTagRepository.getAllByTagsRef(jpaResource.getTagsRef()).stream().map(JpaResourceTag::getTag).collect(Collectors.toList()));
        }

        if( StringUtils.isNotEmpty(jpaResource.getMeta())){
            try {
                builder.meta(mapper.readValue(jpaResource.getMeta(), new TypeReference<Map<String, Object>>() {}));
            } catch (JsonProcessingException e) {
                throw  NAssertException.builder("invalid_meta_parse").message(jpaResource.getMeta()).cause(e).build();
            }
        }
        return builder.build();
    }

    private String getContentType(ResourceSave resourceSave){

        if(resourceSave.getInputStream() == null) return null;

        String filename = resourceSave.getFilename();

        if( StringUtils.isNotEmpty(resourceSave.getResource().getContentType() ) ){
            return resourceSave.getResource().getContentType();
        }

        String contentType = URLConnection.guessContentTypeFromName(filename);
        try {

            String scontentType = URLConnection.guessContentTypeFromStream(resourceSave.getInputStream());
            if(StringUtils.isNotEmpty(scontentType)){
                contentType = scontentType;
            }
        } catch (IOException e) {
            throw NAssertException.builder("invalid_input_stream").cause(e).message(e.getMessage()).build();
        }
        return  contentType;
    }

    private UUID createBucket(ResourceSave resourceSave) {
        //Fixme filename andrebbe aggiunto alla risorsa?
        if(resourceSave.getInputStream() != null) {
            JpaBucket jpaBucket = new JpaBucket();
            try {
                if( false) {
                    // ho un problema con la lettura per class jdk.proxy3.$Proxy106 cannot be cast to class org.hibernate.engine.spi.SessionImplementor (jdk.proxy3.$Proxy106 is in module jdk.proxy3 of loader 'app'; org.hibernate.engine.spi.SessionImplementor is in unnamed module of loader 'app')
                    NAssert.state(resourceSave.getResource().getContentLength() != null, "content-length-required");

                    Session session = entityManager.unwrap(Session.class);
                    Blob blob = Hibernate.getLobCreator(session).createBlob(resourceSave.getInputStream(), resourceSave.getResource().getContentLength());
                    jpaBucket.setData(blob);

                } else {
                    if(resourceSave.getResource().getContentLength() != null) {
                        jpaBucket.setBytesData(IOUtils.toByteArray(resourceSave.getInputStream(), resourceSave.getResource().getContentLength()));
                    } else {
                        jpaBucket.setBytesData(IOUtils.toByteArray(resourceSave.getInputStream()));
                    }
                }

            } catch (Exception e) {
               throw NAssertException.builder("invalid_input_stream").message( e.getMessage()).cause(e).build();
            }
            return jpaBucketRepository.save(jpaBucket).getId();
        }
        return null;
    }
}
