package io.nettuno.resource.jpa;

import io.nettuno.resource.exception.InvalidContextException;
import io.nettuno.resource.model.BasicResource;
import io.nettuno.resource.model.ResourceId;
import io.nettuno.resource.model.ResourceSave;
import io.nettuno.resource.model.ResourceSearch;
import io.nettuno.resource.service.ResourceService;
import lombok.SneakyThrows;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.util.Assert;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Created by klayer3 on 07/05/21.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ComponentScan(basePackages = { "io.nettuno.*",})
@EntityScan(basePackages = { "io.nettuno.*"})
@EnableTransactionManagement
@ActiveProfiles("test")
/*@DataMongoTest
@ExtendWith(SpringExtension.class)*/
public class ResourceJPATest {

    @Autowired
    private ResourceService resourceService;

    @Autowired
    private ResourceLoader resourceLoader;

    @Test
    @SneakyThrows
    void createWithTagsAndMeta() {
        testWithId(null);
    }

    @Test
    @SneakyThrows
    void createWithCustomId() {

        ResourceId postId = ResourceId.builder().id("test_id").build();

        testWithId(postId);
    }

    @Test
    @SneakyThrows
    void createWithEntity() {

        ResourceId postId = ResourceId.builder().entity("test_entity").id("test_id").build();

        testWithId(postId);
    }

    @Test
    @SneakyThrows
    void createWithWrongContext() {
        assertThrows(InvalidContextException.class, () ->{
                ResourceId postId = ResourceId.builder().context("wrong").entity("test_entity").id("test_id").build();
                testWithId(postId);
        });

    }

    @Test
    @SneakyThrows
    void createWithContext() {

        ResourceId postId = ResourceId.builder().context("context1").entity("test_entity").id("test_id").build();

        testWithId(postId);
    }

    private void testWithId(ResourceId postId) throws IOException {
        Resource fileResource = resourceLoader.getResource("classpath:data/piano_terra.png");

        int order = Long.bitCount(System.currentTimeMillis());

        Map<String,Object> meta = new HashMap<>();
        meta.put("test", "test meta");
        meta.put("data", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        io.nettuno.resource.model.Resource postResource = BasicResource.builder().tags(Arrays.asList("test1","test2")).contentLength(fileResource.contentLength()).meta(meta).resourceId(postId).order(order).build();

        InputStream is = fileResource.getInputStream();
        ResourceId resourceId = resourceService.save(ResourceSave.builder()
                .resource(postResource)
                .filename(fileResource.getFilename())

                .inputStream(is).build());

        is.close();
        io.nettuno.resource.model.Resource responseResource =  resourceService.get(resourceId);

        if(postResource.getResourceId() != null && postResource.getResourceId().getId() != null){
            Assert.isTrue(
                    Objects.equals(ObjectUtils.firstNonNull(postResource.getResourceId().getContext(), responseResource.getResourceId().getContext()), responseResource.getResourceId().getContext())
                    &&
                            Objects.equals(ObjectUtils.firstNonNull(postResource.getResourceId().getEntity(), responseResource.getResourceId().getEntity()), responseResource.getResourceId().getEntity())
                    &&
                            Objects.equals(ObjectUtils.firstNonNull(postResource.getResourceId().getId(), responseResource.getResourceId().getId()), responseResource.getResourceId().getId())
                , "postResource.getResourceId and responseResource.getResourceId must be equals");
        }
        Assert.isTrue(CollectionUtils.containsAll(responseResource.getTags(),postResource.getTags() ), "postResource.getTags and responseResource.getTags must be equals");
        Assert.isTrue(Objects.equals(postResource.getMeta(), responseResource.getMeta()), "postResource.getMeta and responseResource.getMeta must be equals");
        Assert.isTrue(Objects.equals(postResource.getOrder(), responseResource.getOrder()), "postResource.getOrder and responseResource.getOrder must be equals");

        Assert.isTrue(IOUtils.contentEquals( resourceService.getContent(resourceId), fileResource.getInputStream() ), "content is not equal!");
        is.close();
    }

    @Test
    @SneakyThrows
    void searchByTag() {
        createWithTagsAndMeta();
        Assert.isTrue(CollectionUtils.isNotEmpty(resourceService.search(ResourceSearch.builder().tags(List.of("test2")).build())), "wrong search size!");
    }

    @Test
    @SneakyThrows
    void searchByMultipleTag() {
        createWithTagsAndMeta();
        Assert.isTrue(CollectionUtils.isNotEmpty(resourceService.search(ResourceSearch.builder().tags(List.of("test2","test1")).build())), "wrong search size!");
    }

    @Test
    @SneakyThrows
    void searchByMultipleTagFail() {
        createWithTagsAndMeta();
        Assert.isTrue(CollectionUtils.isEmpty(resourceService.search(ResourceSearch.builder().tags(List.of("test2","test3")).build())), "wrong search size!");
    }

    @Test
    @SneakyThrows
    void searchById() {
        createWithCustomId();
        Assert.isTrue(resourceService.search(ResourceSearch.builder().resourceId(ResourceId.builder().id("test_id").build()).build()).size() == 1, "wrong search size!");
    }

    @Test
    @SneakyThrows
    void invalidSearch(){
        //assertThrows(CodifiedException.class, () -> resourceService.search(ResourceSearch.builder().build()));
    }

    @Test
    @SneakyThrows
    void createWithoutContent() {
        int order = Long.bitCount(System.currentTimeMillis());

        Map<String,Object> meta = new HashMap<>();
        meta.put("test", "test meta");
        meta.put("data", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));

        io.nettuno.resource.model.Resource postResource = BasicResource.builder().tags(Arrays.asList("test1","test2")).meta(meta).order(order).build();
        ResourceId resourceId = resourceService.save(ResourceSave.builder()
                .resource(postResource)
                .build());

        io.nettuno.resource.model.Resource responseResource =  resourceService.get(resourceId);

        if(postResource.getResourceId() != null && postResource.getResourceId().getId() != null){
            Assert.isTrue(Objects.equals(postResource.getResourceId(), responseResource.getResourceId()), "postResource.getResourceId and responseResource.getResourceId must be equals");
        }
        Assert.isTrue(CollectionUtils.containsAll(responseResource.getTags(),postResource.getTags() ), "postResource.getTags and responseResource.getTags must be equals");
        Assert.isTrue(Objects.equals(postResource.getMeta(), responseResource.getMeta()), "postResource.getMeta and responseResource.getMeta must be equals");
        Assert.isTrue(Objects.equals(postResource.getOrder(), responseResource.getOrder()), "postResource.getOrder and responseResource.getOrder must be equals");

        Assert.isTrue(Objects.equals( resourceService.getContent(resourceId), null ), "content is not equal!");
    }


}
