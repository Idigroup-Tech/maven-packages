package io.nettuno.resource.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.autoconfigure.data.mongo.AutoConfigureDataMongo;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ActiveProfiles;

/**
 * Created by klayer3 on 07/05/21.
 */
@SpringBootApplication
@ActiveProfiles("test")
@AutoConfigureDataMongo
@EnableJpaRepositories
public class ResourceJPATestAPP {

    public static void main(String[] args) {
        SpringApplication.run(ResourceJPATestAPP.class, args);
    }

}


